{**
 * For the full copyright and license information, please view the
 * LICENSE.md file that was distributed with this source code.
 *}
{$componentName = 'page-title-section'}

{block name='page_title_section'}
  <h1 class="{$componentName}">{$title}</h1>
{/block}
