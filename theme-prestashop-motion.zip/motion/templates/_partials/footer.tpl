{**
 * MOTION THEME - footer of the content column (column 3) : displayFooterBefore, at the bottom of the page.
 * displayFooter (main footer) lives in column 1 and displayFooterAfter + copyright in column 2
 * (see _partials/header.tpl).
 *}
{capture name="footer_before"}{hook h='displayFooterBefore'}{/capture}
{include file='_partials/motion-debug.tpl' zone='displayFooterBefore' html=$smarty.capture.footer_before}
{if $smarty.capture.footer_before|trim !== ''}
  {block name='footer_before'}
    <div class="footer motion-footer-before">
      <div class="container-fluid">
        {$smarty.capture.footer_before nofilter}
      </div>
    </div>
  {/block}
{/if}
