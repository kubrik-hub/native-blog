{**
 * For the full copyright and license information, please view the
 * LICENSE.md file that was distributed with this source code.
 *}
{$componentName = 'breadcrumb'}

<nav data-depth="{$breadcrumb.count}" class="{$componentName}__wrapper" aria-label="{$componentName}">
  <div class="container">
    {block name='breadcrumb_list'}
      <ol class="{$componentName}">
        {block name='breadcrumb_items'}
          {foreach from=$breadcrumb.links item=path name=breadcrumb}
            {block name='breadcrumb_item'}
              <li class="{$componentName}-item">
                {if not $smarty.foreach.breadcrumb.last}
                  <a href="{$path.url}" class="{$componentName}-link">{$path.title}</a>
                {else}
                  {$path.title}
                {/if}
              </li>
            {/block}
          {/foreach}
        {/block}
      </ol>
    {/block}
  </div>
</nav>
