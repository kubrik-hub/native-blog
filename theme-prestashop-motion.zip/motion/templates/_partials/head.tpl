{**
 * For the full copyright and license information, please view the
 * LICENSE.md file that was distributed with this source code.
 *}
{block name='head_charset'}
  <meta charset="utf-8">
{/block}

{block name='head_ie_compatibility'}
  <meta http-equiv="x-ua-compatible" content="ie=edge">
{/block}

{block name='head_seo'}
  {block name='head_preload'}
    {include file='_partials/preload.tpl'}
  {/block}

  <title>{block name='head_seo_title'}{$page.meta.title}{/block}</title>

  {block name='hook_after_title_tag'}
    {hook h='displayAfterTitleTag'}
  {/block}

  <meta name="description" content="{block name='head_seo_description'}{$page.meta.description}{/block}">

  {if $page.meta.robots !== 'index'}
    <meta name="robots" content="{$page.meta.robots}">
  {/if}

  {if $page.canonical}
    <link rel="canonical" href="{$page.canonical}">
  {/if}

  {block name='head_hreflang'}
    {foreach from=$urls.alternative_langs item=pageUrl key=code}
      <link rel="alternate" href="{$pageUrl}" hreflang="{$code}">
    {/foreach}
  {/block}

  {** Render structured data from the core. Available since PrestaShop 9.2 **}
  {if !empty($structured_data)}
    {foreach from=$structured_data item="element"}
      {** 320 in the method parameter means JSON_UNESCAPED_SLASHES (64) + JSON_UNESCAPED_UNICODE (256) **}
    <script type="application/ld+json">{$element|@json_encode:320 nofilter}</script>
    {/foreach}

  {** Or render them in a legacy, manual way. This will be removed in future versions of this theme. **}
  {else}
    {block name='head_microdata'}
      {include file='_partials/microdata/head-jsonld.tpl'}
    {/block}
    {block name='head_microdata_special'}{/block}
  {/if}

  {block name='head_pagination_seo'}
    {include file='_partials/pagination-seo.tpl'}
  {/block}

  {block name='head_open_graph'}
    <meta property="og:title" content="{$page.meta.title}">
    <meta property="og:description" content="{$page.meta.description}">
    <meta property="og:url" content="{$urls.current_url}">
    <meta property="og:site_name" content="{$shop.name}">
    {if !isset($product) && $page.page_name != 'product'}<meta property="og:type" content="website">{/if}
  {/block}
{/block}

{block name='head_viewport'}
  <meta name="viewport" content="width=device-width, initial-scale=1">
{/block}

{block name='head_icons'}
  <link rel="icon" type="image/vnd.microsoft.icon" href="{$shop.favicon}?{$shop.favicon_update_time}">
  <link rel="shortcut icon" type="image/x-icon" href="{$shop.favicon}?{$shop.favicon_update_time}">
{/block}

{block name='stylesheets'}
  {include file='_partials/stylesheets.tpl' stylesheets=$stylesheets}
{/block}

{block name='javascript_head'}
  {include file='_partials/javascript.tpl' javascript=$javascript.head vars=$js_custom_vars}
{/block}

{block name='hook_header'}
  {$HOOK_HEADER nofilter}
{/block}

{block name='hook_extra'}{/block}
