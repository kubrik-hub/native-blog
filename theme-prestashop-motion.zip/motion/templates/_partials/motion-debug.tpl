{**
 * MOTION THEME - debug of hook zones.
 * Visible only when the cookie motion_debug=1 is set (or ?motion_debug=1 on pages without canonical redirect).
 * For each zone : modules found in the hook output (from the "begin module" comments of PrestaShop dev mode),
 * real HTML size (comments removed), beginning of that HTML and visibility of the first element after the label.
 * Usage : {include file='_partials/motion-debug.tpl' zone='displayNav1' html=$smarty.capture.xxx}
 *}
{if isset($smarty.cookies.motion_debug) || isset($smarty.get.motion_debug)}
  <div class="motion-debug-label" data-zone="{$zone|escape:'html':'UTF-8'}" style="background:#fde68a;color:#000;font:12px/1.4 monospace;padding:4px 6px;margin:2px 0;text-align:left;text-transform:none;position:relative;z-index:9999;word-break:break-all;white-space:normal;">
    <strong>{$zone|escape:'html':'UTF-8'}</strong> : <span class="motion-debug-state">…</span>
    <textarea hidden class="motion-debug-raw">{$html|escape:'html':'UTF-8'}</textarea>
  </div>
  {literal}
  <script>
    (function () {
    var me = document.currentScript;
    document.addEventListener('DOMContentLoaded', function () {
      var label = me ? me.previousElementSibling : null;
      if (!label) { return; }
      var out = label.querySelector('.motion-debug-state');
      var raw = label.querySelector('.motion-debug-raw').value || '';
      var mods = [], m, re = /begin module:([^\s>]+)/g;
      while ((m = re.exec(raw)) !== null) {
        var name = m[1].split('/')[0];
        if (mods.indexOf(name) === -1) { mods.push(name); }
      }
      var clean = raw.replace(/<!--[\s\S]*?-->/g, '').replace(/\s+/g, ' ').trim();
      var html = '';
      html += '<strong style="color:' + (clean.length ? '#166534' : '#b91c1c') + '">' + (clean.length ? clean.length + ' car. de HTML réel' : 'AUCUN HTML réel') + '</strong>';
      html += ' | modules : ' + (mods.length ? mods.join(', ') : 'aucun');
      if (!clean.length && mods.length) {
        html += '<br><strong style="color:#b91c1c">→ le module est bien greffé mais son template n\'affiche rien sur ce hook (contenu non configuré pour ce hook ?)</strong>';
      }
      if (clean.length) {
        var el = label.nextElementSibling;
        while (el && (el.tagName === 'SCRIPT' || el.classList.contains('motion-debug-label'))) { el = el.nextElementSibling; }
        if (el) {
          var r = el.getBoundingClientRect(), hiddenBy = null, p = el;
          while (p && p !== document.body) {
            var s = getComputedStyle(p);
            if (s.display === 'none') { hiddenBy = p.id ? '#' + p.id : p.className; break; }
            if (s.visibility === 'hidden') { hiddenBy = 'visibility:hidden sur ' + (p.id ? '#' + p.id : p.className); break; }
            p = p.parentElement;
          }
          var tag = el.tagName.toLowerCase() + (el.id ? '#' + el.id : '');
          html += '<br>→ ' + tag + ' : ' + (hiddenBy ? 'MASQUÉ par ' + hiddenBy : (r.height < 2 ? 'hauteur 0' : 'visible ' + Math.round(r.width) + '×' + Math.round(r.height) + 'px'));
        }
        var txt = document.createElement('div');
        txt.style.cssText = 'opacity:.75;margin-top:2px;';
        txt.textContent = clean.substring(0, 300);
        out.innerHTML = html;
        out.appendChild(txt);
      } else {
        out.innerHTML = html;
      }
    });
    })();
  </script>
  {/literal}
{/if}
