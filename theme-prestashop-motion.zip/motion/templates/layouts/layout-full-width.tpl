{**
 * For the full copyright and license information, please view the
 * LICENSE.md file that was distributed with this source code.
 *}
{* Motion theme: every layout uses the same 3-column structure (fixed column 1 + fixed column 2 + content).
   Right column hooks are rendered in column 2, under displayTop (see _partials/header.tpl). *}
{extends file='layouts/layout-both-columns.tpl'}
