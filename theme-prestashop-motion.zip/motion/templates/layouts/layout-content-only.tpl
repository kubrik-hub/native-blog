{**
 * For the full copyright and license information, please view the
 * LICENSE.md file that was distributed with this source code.
 *}
{extends file='layouts/layout-both-columns.tpl'}

{block name='header'}{/block}

{block name='breadcrumb'}{/block}

{block name='motion_nav_2'}{/block}

{block name='content_columns'}
  <div id="center-column" class="center-column page page--content-only">
    {hook h='displayContentWrapperTop'}
    {block name='content'}
      <p>Hello world! This is HTML5 Boilerplate.</p>
    {/block}
    {hook h='displayContentWrapperBottom'}
  </div>
{/block}

{block name='footer'}{/block}
