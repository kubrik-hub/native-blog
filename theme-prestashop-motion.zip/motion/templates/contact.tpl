{**
 * For the full copyright and license information, please view the
 * LICENSE.md file that was distributed with this source code.
 *}
{extends file='page.tpl'}

{block name='page_header_container'}{/block}

{block name='page_content'}
  {hook h='displayContactContent'}
{/block}
