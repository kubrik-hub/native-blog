{**
 * For the full copyright and license information, please view the
 * LICENSE.md file that was distributed with this source code.
 *}
{block name='customer_form'}
  {block name='customer_form_errors'}
    {include file='_partials/form-errors.tpl' errors=$errors['']}
  {/block}

<form 
  action="{block name='customer_form_actionurl'}{$action}{/block}" 
  class="js-customer-form" 
  id="customer-form" 
  method="post" 
  data-ps-action="form-validation"
  aria-label="{l s='Your personal information' d='Shop.Theme.Customeraccount'}"
>
  <section>
    {block "form_fields"}
      {foreach from=$formFields item="field"}
        {block "form_field"}
          {if $field.name === "new_password" && $page.page_name == "identity"}
            <div data-ps-ref="password-field">
              {form_field field=$field}
            </div>
          {elseif $field.type === "password" && $page.page_name != "identity"}
            <div data-ps-ref="password-field">
              {form_field field=$field}
            </div>
          {else}
            {form_field field=$field}
          {/if}
        {/block}
      {/foreach}
      {$hook_create_account_form nofilter}
    {/block}
  </section>

  {block name='customer_form_footer'}
    <input type="hidden" name="submitCreate" value="1">

    <footer class="buttons-wrapper buttons-wrapper--end">
      {block "form_buttons"}
        <button class="btn btn-primary form-control-submit" data-link-action="save-customer" type="submit" data-ps-action="form-validation-submit">
        {if isset($mode) && $mode === "register"}
          {l s='Create account' d='Shop.Theme.Actions'}
        {else}
          {l s='Save' d='Shop.Theme.Actions'}
        {/if}
        </button>
      {/block}
    </footer>
  {/block}
</form>
{/block}
