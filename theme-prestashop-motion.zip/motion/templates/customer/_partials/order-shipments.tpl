{**
 * For the full copyright and license information, please view the
 * LICENSE.md file that was distributed with this source code.
 *}
<section class="order-carriers">
  <h2 id="order_carriers_heading">{l s='Shipment tracking details' d='Shop.Theme.Customeraccount'}</h2>

  <div class="grid-table" role="table" aria-label="{l s='Order tracking' d='Shop.Theme.Customeraccount'}">
    <div class="grid-table__inner grid-table__inner--5" role="rowgroup">
      <div class="grid-table__header" role="row">
        <span class="grid-table__cell" role="columnheader">{l s='Date' d='Shop.Theme.Global'}</span>
        <span class="grid-table__cell" role="columnheader">{l s='Carrier' d='Shop.Theme.Checkout'}</span>
        <span class="grid-table__cell" role="columnheader">{l s='Weight' d='Shop.Theme.Checkout'}</span>
        <span class="grid-table__cell" role="columnheader">{l s='Tracking number' d='Shop.Theme.Checkout'}</span>
      </div>

      {foreach from=$order.shipping item=line}
        <div class="grid-table__row" role="row">
          <span class="grid-table__cell" role="cell" data-ps-label="{l s='Date' d='Shop.Theme.Global'}">
            {$line.date_add}
          </span>
          <span class="grid-table__cell" role="cell" data-ps-label="{l s='Carrier' d='Shop.Theme.Checkout'}">
            {$line.carrier_name}
          </span>
          <span class="grid-table__cell" role="cell" data-ps-label="{l s='Weight' d='Shop.Theme.Checkout'}">
            {$line.package_weight}
          </span>
          <span class="grid-table__cell" role="cell" data-ps-label="{l s='Tracking number' d='Shop.Theme.Checkout'}">
            {if $line.carrier_tracking_url}
              <a href="{$line.carrier_tracking_url}" target="_blank">{$line.tracking_number}</a>
            {elseif $line.tracking_number}
              {$line.tracking_number}
            {else}
              -
            {/if}
          </span>
        </div>
      {/foreach}
    </div>
  </div>
</section>
