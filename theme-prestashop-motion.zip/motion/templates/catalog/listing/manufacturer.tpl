{**
 * For the full copyright and license information, please view the
 * LICENSE.md file that was distributed with this source code.
 *}
{extends file='catalog/listing/product-list.tpl'}

{block name='product_list_header'}
  {include file='components/page-title-section.tpl' title={l s='List of products by brand %brand_name%' sprintf=['%brand_name%' => $manufacturer.name] d='Shop.Theme.Catalog'}}

  {if $manufacturer.short_description}
    <div class="rich-text">{$manufacturer.short_description nofilter}</div>
  {/if}

  {if $manufacturer.description}
    <div class="rich-text">{$manufacturer.description nofilter}</div>
  {/if}
{/block}
