// ===================================================
// FLY TO CART (PRESTASHOP 1.4 LECACY)+ CART ACCORDION
// ===================================================
document.addEventListener('DOMContentLoaded', function() {

    let collapse = document.getElementById(
        'cart-summary-product-list'
    );
    let button = document.querySelector(
        '.accordion-button[data-bs-target="#cart-summary-product-list"]'
    );

    if (collapse && button) {
        collapse.classList.remove('show');
        button.classList.add('collapsed');
        button.setAttribute(
            'aria-expanded',
            'false'
        );
    }
});

// ===================================================
// MOTION : ouverture du panier de la colonne gauche
// reste ouvert jusqu'à ce que le client le ferme.
// ===================================================
window.MOTION_CART_AUTOCLOSE_MS = 0;

window.motionOpenCart = function() {
    var panel = document.getElementById('motion-cart-panel');
    var btn = document.querySelector('.motion-icon--cart');
    if (!panel) {
        return;
    }

    if (!panel.classList.contains('show') && !panel.classList.contains('collapsing')) {
        if (btn) {
            // on passe par le bouton : le Collapse Bootstrap du thème gère l'animation
            // et referme tout seul la recherche / le compte (data-bs-parent="#motion-top")
            btn.click();
        }
        // filet de sécurité si le Collapse du thème n'a pas réagi
        setTimeout(function() {
            if (!panel.classList.contains('show') && !panel.classList.contains('collapsing')) {
                Array.prototype.forEach.call(
                    document.querySelectorAll('#motion-top .motion-collapse.show'),
                    function(other) {
                        other.classList.remove('show');
                    }
                );
                panel.classList.add('show');
                if (btn) {
                    btn.setAttribute('aria-expanded', 'true');
                }
            }
        }, 400);
    }

    // affiche aussi la liste des produits (accordéon interne natif)
    var list = document.getElementById('cart-summary-product-list');
    var listBtn = document.querySelector('.accordion-button[data-bs-target="#cart-summary-product-list"]');
    if (list && listBtn) {
        list.classList.add('show');
        listBtn.classList.remove('collapsed');
        listBtn.setAttribute('aria-expanded', 'true');
    }

    // remet le panier dans la zone visible de la colonne
    setTimeout(function() {
        if (panel.scrollIntoView) {
            panel.scrollIntoView({
                block: 'nearest',
                behavior: 'smooth'
            });
        }
    }, 450);

    if (window.MOTION_CART_AUTOCLOSE_MS > 0) {
        clearTimeout(window.motionCartTimer);
        window.motionCartTimer = setTimeout(function() {
            if (panel.classList.contains('show') && btn) {
                btn.click();
            }
        }, window.MOTION_CART_AUTOCLOSE_MS);
    }
};

// Détection de l'ajout au panier : on surveille le compteur du panier (data-cart-count) qui est
// re-rendu par ps_shoppingcart.js après chaque mise à jour. Indépendant de la forme des évènements.
(function() {
    var last = null;

    function currentCount() {
        var el = document.querySelector('.blockcart');
        return el ? (parseInt(el.getAttribute('data-cart-count'), 10) || 0) : 0;
    }

    function onCartDom() {
        var now = currentCount();
        if (last === null) {
            last = now;
            return;
        }
        var increased = now > last;
        last = now;
        if (!increased) {
            return;
        }
        var page = document.body.id;
        if (page === 'cart' || page === 'checkout' || page === 'order-confirmation') {
            return;
        }
        window.motionOpenCart();
    }

    document.addEventListener('DOMContentLoaded', function() {
        var top = document.getElementById('motion-top');
        if (!top || !window.MutationObserver) {
            return;
        }
        last = currentCount();
        new MutationObserver(onCartDom).observe(top, {
            childList: true,
            subtree: true
        });
    });
})();

document.addEventListener('DOMContentLoaded', function() {
    var flyStart = null;

    // 1. Capture du bouton cliqué AVANT AJAX
    jQuery(document).on(
        'mousedown',
        'button[data-button-action="add-to-cart"]',
        function() {
            var buttonRect = this.getBoundingClientRect();
            flyStart = {
                left: buttonRect.left + (buttonRect.width / 2),
                top: buttonRect.top + (buttonRect.height / 2)
            };
        }
    );

    if (typeof prestashop !== 'undefined') {

        // 2. Mise à jour panier + Fly To Cart
        prestashop.on('updateCart', function() {
            console.log('MOTION updateCart détecté');
            var $cart = jQuery('.motion-icon--cart').first();
            if (!$cart.length) {
                $cart = jQuery(
                    '.blockcart, #_desktop_cart, .header-cart, .shopping_cart, #_desktop_ps_shoppingcart'
                ).first();
            }
            if (!$cart.length || !flyStart) {
                return;
            }

            var cartRect = $cart[0].getBoundingClientRect();

            var $clone = jQuery('<div>', {
                class: 'fly-to-cart'
            }).css({
                position: 'fixed',
                top: flyStart.top + 'px',
                left: flyStart.left + 'px',
                zIndex: 99999,
                pointerEvents: 'none'
            }).appendTo('body');

            // Force le navigateur à appliquer la position de départ
            $clone[0].offsetHeight;

            // Animation vers le centre du bouton panier Motion
            $clone.css({
                top: (cartRect.top + (cartRect.height / 2) - 15) + 'px',
                left: (cartRect.left + (cartRect.width / 2) - 15) + 'px',
                width: '30px',
                height: '30px'
            });

            setTimeout(function() {
                $clone.remove();
                flyStart = null;
            }, 1550);
        });

        // 3. MOTION : l'ouverture du panier est gérée par l'observateur de compteur (voir motionOpenCart)
    }
});


// =====================================================
// ADD HOVER THUMBAIL PRODUCT LIST TO DISPLAY ALL IMAGES
// =====================================================

document.addEventListener('DOMContentLoaded', function() {

    document.querySelectorAll('.js-product-miniature').forEach(product => {

        const gallery = product.querySelector('.product-hover-gallery');
        if (!gallery) {
            return;
        }


        const images = gallery.querySelectorAll('.product-hover-slide');
        if (images.length <= 1) {
            return;
        }

        let current = 0;
        let timer = null;
        let firstTimer = null;

        product.addEventListener('mouseenter', function() {
            firstTimer = setTimeout(function() {
                images[current].classList.remove('active');
                current++;
                if (current >= images.length) {
                    current = 0;
                }
                images[current].classList.add('active');
                timer = setInterval(function() {
                    images[current].classList.remove('active');
                    current++;

                    if (current >= images.length) {
                        current = 0;
                    }
                    images[current].classList.add('active');
                }, 1200);
            }, 500);
        });



        product.addEventListener('mouseleave', function() {
            clearTimeout(firstTimer);
            clearInterval(timer);
            images[current].classList.remove('active');
            current = 0;
            images[current].classList.add('active');
        });
    });
});


// ===================================================
// DELETE A PRODUCT FROM THE ACCORDION TOP CART
// ===================================================
// 1. instant feedback : the line disappears, the badge is decremented and, when the cart becomes
//    empty, the icon goes back to its normal state (.header-block--active -> .inactive)
// 2. real deletion through ajax (same call as the native theme : POST ajax=1&action=update, JSON answer,
//    no full cart page rendered) then ps_shoppingcart.js refreshes .blockcart with the real cart state
function motionCartInstantUpdate(removedQty) {
    var cart = document.querySelector('.blockcart');
    if (!cart) {
        return;
    }

    var count = parseInt(cart.getAttribute('data-cart-count'), 10) || 0;
    var next = Math.max(0, count - (removedQty || 1));
    cart.setAttribute('data-cart-count', next);

    var badge = cart.querySelector('.motion-icon__badge');
    var header = cart.querySelector('#cart-summary__products-accordion .accordion-header h4');

    if (next > 0) {
        cart.classList.add('header-block--active');
        cart.classList.remove('inactive');
        if (badge) {
            badge.textContent = next;
        }
        if (header) {
            // "3 products - 45,00 €" : only the number is updated, the total is refreshed by the server
            header.textContent = header.textContent.replace(/\d+/, next);
        }
        return;
    }

    // empty cart
    cart.classList.remove('header-block--active');
    cart.classList.add('inactive');
    if (badge && badge.parentNode) {
        badge.parentNode.removeChild(badge);
    }
    var accordion = cart.querySelector('#cart-summary__products-accordion');
    var panel = cart.querySelector('#motion-cart-panel');
    if (accordion && accordion.parentNode) {
        accordion.parentNode.removeChild(accordion);
    }
    if (panel && !panel.querySelector('.motion-collapse__empty')) {
        var empty = document.createElement('p');
        empty.className = 'motion-collapse__empty';
        empty.textContent = (window.prestashop && prestashop.motionEmptyCartLabel) ||
            panel.getAttribute('data-empty-label') || '';
        panel.appendChild(empty);
    }
}

document.addEventListener('click', function(e) {
    var remove = e.target.closest('.cart-summary-product__remove');

    if (!remove) {
        return;
    }

    e.preventDefault();

    if (remove.getAttribute('data-motion-removing')) {
        return; // already being removed (double click)
    }
    remove.setAttribute('data-motion-removing', '1');

    var line = remove.closest('.cart-summary-product');
    var qtyEl = line ? line.querySelector('.cart-summary-product__quantity .value') : null;
    var qty = qtyEl ? (parseInt(qtyEl.textContent.replace(/\D/g, ''), 10) || 1) : 1;

    // 1. instant UI
    motionCartInstantUpdate(qty);
    if (line && line.parentNode) {
        line.parentNode.removeChild(line);
    }

    // 2. real deletion, then authoritative refresh (also when the request fails, so that the UI
    //    never stays out of sync with the real cart)
    var refresh = function() {
        prestashop.emit('updateCart', {
            reason: {
                linkAction: 'delete-from-cart'
            }
        });
    };
    var data = new FormData();
    data.append('ajax', '1');
    data.append('action', 'update');

    fetch(remove.href, {
        method: 'POST',
        body: data,
        credentials: 'same-origin'
    }).then(refresh, refresh);
});

// =====================================================
// MOTION THEME : black panel + left column behaviour
// =====================================================
(function() {
    'use strict';

    var body = document.body;
    var mq = window.matchMedia('(max-width: 991.98px)');

    // ---------- 1. Black panel (menu) ----------
    function setPanel(open) {
        var panel = document.getElementById('motion-panel');
        if (!panel) {
            return;
        }
        body.classList.toggle('motion-panel-open', open);
        panel.setAttribute('aria-hidden', open ? 'false' : 'true');
        document.querySelectorAll('.motion-icon--menu').forEach(function(btn) {
            btn.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
        if (open) {
            panel.focus({
                preventScroll: true
            });
        }
    }

    document.addEventListener('click', function(e) {
        if (e.target.closest('.js-motion-panel-toggle')) {
            e.preventDefault();
            setPanel(!body.classList.contains('motion-panel-open'));
            return;
        }
        if (e.target.closest('.js-motion-overlay')) {
            setPanel(false);
        }
    });

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && body.classList.contains('motion-panel-open')) {
            setPanel(false);
            var btn = document.querySelector('.motion-icon--menu');
            if (btn) {
                btn.focus();
            }
        }
    });

    // ---------- 2. Modules hooked on displayTop AND displayRightColumn -> accordion (title / content) ----------
    // Each module (direct child of the zone) that has a title becomes an accordion : the title is the
    // button, everything else of the module is the collapsible content. Modules without any title are left
    // untouched. In each zone only one accordion is open at a time (data-bs-parent = the zone).
    var TITLE_SELECTOR = 'h1, h2, h3, h4, h5, h6, .h1, .h2, .h3, .h4, .h5, .h6, [class*="__title"], [class*="-title"], .title';

    function buildAccordion(el, id, parentSelector) {
        var title = el.querySelector(TITLE_SELECTOR);
        if (!title || !title.textContent.trim()) {
            return;
        }
        var label = title.textContent.trim();

        var wrapper = document.createElement('div');
        wrapper.className = 'motion-acc accordion accordion-flush';

        var header = document.createElement('div');
        header.className = 'accordion-header';
        var button = document.createElement('button');
        button.type = 'button';
        button.className = 'accordion-button collapsed';
        button.setAttribute('data-bs-toggle', 'collapse');
        button.setAttribute('data-bs-target', '#' + id);
        button.setAttribute('aria-expanded', 'false');
        button.setAttribute('aria-controls', id);
        button.textContent = label;
        header.appendChild(button);

        var collapse = document.createElement('div');
        collapse.id = id;
        collapse.className = 'accordion-collapse collapse';
        collapse.setAttribute('data-bs-parent', parentSelector);
        var inner = document.createElement('div');
        inner.className = 'motion-acc__body';

        // the title is replaced by the accordion button, everything else goes into the collapse
        title.style.display = 'none';
        while (el.firstChild) {
            inner.appendChild(el.firstChild);
        }
        collapse.appendChild(inner);
        wrapper.appendChild(header);
        wrapper.appendChild(collapse);
        el.appendChild(wrapper);
        el.setAttribute('data-motion-acc', '1');
        el.classList.add('motion-acc-host');
    }

    function buildAccordionsIn(zoneId, idPrefix) {
        var zone = document.getElementById(zoneId);
        if (!zone) {
            return;
        }
        var i = 0;
        Array.prototype.forEach.call(zone.children, function(el) {
            if (
                el.hasAttribute('data-motion-native') ||
                el.hasAttribute('data-motion-acc') ||
                el.classList.contains('motion-icon') ||
                el.classList.contains('collapse') ||
                el.tagName === 'TEMPLATE' ||
                el.tagName === 'SCRIPT' ||
                el.tagName === 'STYLE'
            ) {
                return;
            }
            el.setAttribute('data-motion-acc-source', '1');
            buildAccordion(el, idPrefix + (i++), '#' + zoneId);
        });
    }

    function buildTopAccordions() {
        buildAccordionsIn('motion-top', 'motion-acc-');
    }

    function buildRightColumnAccordions() {
        buildAccordionsIn('motion-right-column', 'motion-racc-');
    }

    // ---------- 3. Small screens : main menu, displayTop modules and displayRightColumn go in the black panel,
    //                displayFooterAfter + copyright go after the content ----------
    // Each moved node leaves a comment marker at its original place so that it can be put back exactly there
    // when the screen becomes large again (desktop layout).
    var moved = [];

    function relocate(node, target) {
        if (!node || !target || node.parentNode === target) {
            return;
        }
        var marker = document.createComment('motion-placeholder');
        node.parentNode.insertBefore(marker, node);
        moved.push({
            node: node,
            marker: marker
        });
        target.appendChild(node);
    }

    function restoreAll() {
        moved.forEach(function(item) {
            if (item.marker.parentNode) {
                item.marker.parentNode.replaceChild(item.node, item.marker);
            }
        });
        moved = [];
        var holder = document.getElementById('motion-panel-mobile');
        if (holder && holder.parentNode) {
            holder.parentNode.removeChild(holder);
        }
    }

    function moveToMobile() {
        if (moved.length) {
            return; // already in the mobile layout
        }
        var panelBody = document.querySelector('#motion-panel .motion-panel__body');
        var content = document.getElementById('motion-content');
        var top = document.getElementById('motion-top');

        if (panelBody) {
            // holder at the very top of the panel, above the footer / nav1 blocks
            var holder = document.createElement('div');
            holder.id = 'motion-panel-mobile';
            holder.className = 'motion-panel__mobile';
            panelBody.insertBefore(holder, panelBody.firstChild);

            // 1. main menu (first, it is the main purpose of the panel)
            relocate(document.getElementById('motion_ps_mainmenu'), holder);

            // 2. every other module hooked on displayTop (built as accordions by buildTopAccordions)
            if (top) {
                Array.prototype.slice.call(top.children).forEach(function(el) {
                    if (el.hasAttribute('data-motion-acc') || el.hasAttribute('data-motion-acc-source')) {
                        relocate(el, holder);
                    }
                });
            }

            // 3. displayRightColumn
            relocate(document.getElementById('motion-right-column'), holder);
        }

        // displayFooterAfter + copyright : at the end of the content column
        relocate(document.querySelector('.motion-sidebar__bottom'), content);
    }

    function responsive() {
        if (mq.matches) {
            // Mobile / tablet : off-canvas panel closed by default, blocks moved out of the top bar
            setPanel(false);
            moveToMobile();
            return;
        }

        // Desktop : everything back in the left column
        restoreAll();
    }

    document.addEventListener('DOMContentLoaded', function() {
        buildTopAccordions();
        buildRightColumnAccordions();
        responsive();

        // focus the search input when the search accordion opens
        var searchPanel = document.getElementById('motion-search-panel');
        if (searchPanel) {
            searchPanel.addEventListener('shown.bs.collapse', function() {
                var input = document.getElementById('ps_searchbar_input');
                if (input) {
                    input.focus();
                }
            });
        }
    });

    if (mq.addEventListener) {
        mq.addEventListener('change', responsive);
    } else if (mq.addListener) {
        mq.addListener(responsive);
    }
})();
// ===================================================
// MOTION ACCESSIBILITY LAYER (PrestaShop 9.1)
// ===================================================
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[aria-live]').forEach(function (item) {
      item.setAttribute('aria-atomic', 'true');
    });

    document.querySelectorAll('[data-bs-toggle="offcanvas"], [data-bs-toggle="collapse"]').forEach(function (button) {
      button.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
          button.focus();
        }
      });
    });
  });
})();
