{**
 * For the full copyright and license information, please view the
 * LICENSE.md file that was distributed with this source code.
 *}

<div id="_desktop_ps_currencyselector" class="d-flex">
  <div class="ps-currencyselector">
    <select class="form-select js-currency-selector" aria-label="{if $currency.name !== $currency.iso_code} {$currency.name}{/if}">
      {foreach from=$currencies item=currency}
        <option value="{$currency.url}"{if $currency.current} selected="selected"{/if}>
        {if $currency.name !== $currency.iso_code} {$currency.name|truncate:6:''}{/if}</option>
      {/foreach}
    </select>
  </div>
</div>

