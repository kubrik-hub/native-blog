{**
 * For the full copyright and license information, please view the
 * LICENSE.md file that was distributed with this source code.
 *}

{extends file="components/module-products.tpl"}

{block name='module_products_name'}ps-crossselling{/block}

{block name='module_products_title'}
  {include file='components/section-title.tpl' title={l s='Clients also bought' d='Shop.Theme.Catalog'}}
{/block}
