{**
 * For the full copyright and license information, please view the
 * LICENSE.md file that was distributed with this source code.
 *
 * MOTION THEME : main menu displayed as a native Bootstrap accordion in the left column.
 * Each item with children unrolls its sub-menu (recursive, one open branch per level).
 *}
{function name="motionMenu" nodes=[] level=1 parentId="motion-menu"}
  {if $nodes|count}
    <ul class="motion-menu__list motion-menu__list--level-{$level}">
      {foreach from=$nodes item=node}
        {assign var=_uid value=$parentId|cat:'-'|cat:$node@index}
        <li class="motion-menu__item type-{$node.type}{if $node.current} current{/if}{if $node.children|count} motion-menu__item--has-children{/if}" data-id="{$node.page_identifier}">
          <div class="motion-menu__row">
            {if $node.children|count}
              {* The whole button unrolls the accordion (no separate icon) *}
              <button
                class="accordion-button collapsed motion-menu__link motion-menu__toggle"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#{$_uid}"
                aria-expanded="false"
                aria-controls="{$_uid}"
              >{if $level === 1 && $node.url == $urls.base_url}{l s='products' d='Shop.Theme.Menu'}{else}{$node.label}{/if}</button>
            {else}
              <a
                class="motion-menu__link"
                href="{$node.url}"
                data-depth="{$level}"
                {if $node.current}aria-current="page"{/if}
                {if $node.open_in_new_window}target="_blank" rel="noopener noreferrer"{/if}
              >{if $level === 1 && $node.url == $urls.base_url}{l s='products' d='Shop.Theme.Menu'}{else}{$node.label}{/if}</a>
            {/if}
          </div>
          {if $node.children|count}
            <div class="collapse motion-menu__collapse" id="{$_uid}" data-bs-parent="#{$parentId}">
              {* The parent page stays reachable, since its own label now only unrolls the accordion *}
              {motionMenu nodes=$node.children level=$level+1 parentId=$_uid}
            </div>
          {/if}
        </li>
      {/foreach}
    </ul>
  {/if}
{/function}

<div id="motion_ps_mainmenu" class="ps-mainmenu motion-mod motion-mod--menu" data-motion-native>
  <nav id="motion-menu" class="motion-menu accordion accordion-flush" aria-label="{l s='Main navigation' d='Shop.Theme.Menu'}">
    {motionMenu nodes=$menu.children level=1 parentId="motion-menu"}
  </nav>
</div>
