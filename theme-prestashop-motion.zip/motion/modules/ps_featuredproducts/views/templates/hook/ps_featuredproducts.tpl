{**
 * For the full copyright and license information, please view the
 * LICENSE.md file that was distributed with this source code.
 *}

{extends file="components/module-products.tpl"}

{block name='module_products_name'}ps-featuredproducts{/block}

{block name='module_products_title'}
  {include file='components/section-title.tpl' title={l s='Featured products' d='Shop.Theme.Catalog'}}
{/block}

{block name='module_products_footer'}
  <a href="{$allProductsLink}">
    <i class="material-icons" aria-hidden="true">&#xE315;</i>
    {l s='All featured products' d='Shop.Theme.Catalog'}
  </a>
{/block}
