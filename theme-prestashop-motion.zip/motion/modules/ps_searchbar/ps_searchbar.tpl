{**
 * For the full copyright and license information, please view the
 * LICENSE.md file that was distributed with this source code.
 *
 * MOTION THEME : search icon (left column) that unrolls the native search form (Bootstrap collapse).
 *}
<div id="motion_ps_searchbar" class="motion-mod motion-mod--search" data-motion-native>
  <button
    type="button"
    class="motion-icon motion-icon--search header-block__action-btn"
    data-bs-toggle="collapse"
    data-bs-target="#motion-search-panel"
    aria-expanded="false"
    aria-controls="motion-search-panel"
    aria-label="{l s='Show search bar' d='Shop.Theme.Global'}"
  >
    <i class="material-icons header-block__icon" aria-hidden="true">&#xE8B6;</i>
  </button>

  <div class="collapse motion-collapse motion-collapse--search" id="motion-search-panel" data-bs-parent="#motion-top">
    <div id="ps_searchbar" class="ps-searchbar js-search-widget" data-search-controller-url="{$search_controller_url}">
      <form class="ps-searchbar__form" method="get" action="{$search_controller_url}" role="search">
        <input type="hidden" name="controller" value="search">
        <label for="ps_searchbar_input" class="visually-hidden">{l s='Search' d='Shop.Theme.Catalog'}</label>
        <input
          class="js-search-input form-control ps-searchbar__input"
          type="text"
          name="s"
          value="{$search_string}"
          placeholder="{l s='Search products...' d='Shop.Theme.Catalog'}"
          id="ps_searchbar_input"
          autocomplete="off"
          role="combobox"
          aria-haspopup="listbox"
          aria-autocomplete="list"
          aria-controls="ps_searchbar_results"
          aria-expanded="false"
        >
        <i class="material-icons ps-searchbar__magnifier js-search-icon" aria-hidden="true">&#xE8B6;</i>
        <button type="button" class="ps-searchbar__clear js-search-clear btn outline outline--rounded d-none" aria-label="{l s='Clear search' d='Shop.Theme.Catalog'}">
          <i class="material-icons" aria-hidden="true">&#xE14C;</i>
        </button>
      </form>

      <div
        class="ps-searchbar__dropdown js-search-dropdown d-none"
        id="ps_searchbar_dropdown"
        aria-label="{l s='Search results' d='Shop.Theme.Catalog'}"
        tabindex="-1"
      >
        <div class="ps-searchbar__results js-search-results" id="ps_searchbar_results" role="listbox" tabindex="-1"></div>
      </div>
    </div>
  </div>
</div>

<template id="ps_searchbar_result" class="js-search-template">
  <a data-ps-ref="searchbar-result-link" class="ps-searchbar__result-link" id="" href="">
    <img src="" alt="" class="ps-searchbar__result-image">
    <p class="ps-searchbar__result-name"></p>
  </a>
</template>
