{**
 * For the full copyright and license information, please view the
 * LICENSE.md file that was distributed with this source code.
 *}


<div id="_desktop_ps_searchbar" class="ms-auto col-auto d-none d-md-flex align-items-center">
  <div id="ps_searchbar" class="ps-searchbar js-search-widget" data-search-controller-url="{$search_controller_url}">

    <input type="checkbox" id="toggle-searchbar" class="hidden-checkbox">
    <label for="toggle-searchbar" class="btn-click">
      <i class="material-icons ps-searchbar__magnifier js-search-icon" aria-hidden="true">&#xe8b6;</i>
    </label>

    <form class="ps-searchbar__form box-to-show" method="get" action="{$search_controller_url}" role="search">
      <input type="hidden" name="controller" value="search">
      <label for="ps_searchbar_input" class="visually-hidden">{l s='Search' d='Shop.Theme.Catalog'}</label>
      <input
        class="js-search-input form-control ps-searchbar__input"
        type="text"
        name="s"
        value="{$search_string}"
        placeholder="{l s='Search products...' d='Shop.Theme.Catalog'}"
        id="ps_searchbar_input"
        autocomplete="off"
        role="combobox"
        aria-haspopup="listbox"
        aria-autocomplete="list"
        aria-controls="ps_searchbar_results"
        aria-expanded="false"
      >
      <i class="material-icons ps-searchbar__magnifier js-search-icon" aria-hidden="true">&#xE8B6;</i>
      <button type="button" class="ps-searchbar__clear js-search-clear btn outline outline--rounded d-none" aria-label="{l s='Clear search' d='Shop.Theme.Catalog'}">
        <i class="material-icons" aria-hidden="true">&#xE14C;</i>
      </button>
    </form>

    <div
      class="ps-searchbar__dropdown js-search-dropdown d-none"
      id="ps_searchbar_dropdown"
      aria-label="{l s='Search results' d='Shop.Theme.Catalog'}"
      tabindex="-1"
    >
      <div class="ps-searchbar__results js-search-results" id="ps_searchbar_results" role="listbox" tabindex="-1"></div>
    </div>
  </div>
</div>

<template id="ps_searchbar_result" class="js-search-template">
  <a data-ps-ref="searchbar-result-link" class="ps-searchbar__result-link" id="" href="">
    <img src="" alt="" class="ps-searchbar__result-image">
    <p class="ps-searchbar__result-name"></p>
  </a>
</template>

{* MOBILE SEARCH BAR *}
<div class="ps-searchbar--mobile d-md-none d-flex col-auto">
  <div class="header-block d-flex align-items-center">
    <a class="header-block__action-btn" href="#" role="button" data-bs-toggle="offcanvas" data-bs-target="#searchCanvas" aria-controls="searchCanvas" aria-label="{l s='Show search bar' d='Shop.Theme.Global'}">
      <span class="material-icons header-block__icon" aria-hidden="true">&#xE8B6;</span>
    </a>
  </div>

  <div class="ps-searchbar__offcanvas js-search-offcanvas offcanvas offcanvas-top h-auto" tabindex="-1" id="searchCanvas" aria-labelledby="offcanvasTopLabel">
    <div class="offcanvas-header">
      <div id="_mobile_ps_searchbar" class="ps-searchbar__container"></div>
      <button type="button" class="btn btn-link" data-bs-dismiss="offcanvas" aria-label="{l s='Close search' d='Shop.Theme.Global'}">{l s='Cancel' d='Shop.Theme.Global'}</button>
    </div>
  </div>
</div>
