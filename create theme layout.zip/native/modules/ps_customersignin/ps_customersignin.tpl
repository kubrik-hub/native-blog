{**
 * For the full copyright and license information, please view the
 * LICENSE.md file that was distributed with this source code.
 *}

<div id="_desktop_ps_customersignin" class="{if $customer.is_logged}is_logged{else}is_notlogged{/if}">
  <div class="ps-customersignin">
    {if $customer.is_logged}
      <div class="dropdown header-block">
        <button
          class="dropdown-toggle header-block__action-btn border-0 bg-transparent"
          id="userMenuButton"
          data-bs-toggle="dropdown"
          aria-haspopup="true"
          aria-expanded="false"
          aria-label="{l s='(%customerName%)' sprintf=['%customerName%' => $customerName] d='Shop.Theme.Customeraccount'}"
        >
          <i class="material-icons header-block__icon customer_is_logged" aria-hidden="true">&#xe7fd;</i>
          <span class="header-block__title d-none d-md-block d-lg-none">
            {$customer.firstname|capitalize|truncate:1:".":true}{$customer.lastname|capitalize|truncate:2:".":true}
          </span>
          <span class="header-block__title d-lg-inline d-none">
            {$customer.firstname|capitalize|truncate:1:"":true}.{$customer.lastname|capitalize|truncate:2:" ":true}
          </span>
        </button>

        <div class="dropdown-menu dropdown-menu-start" aria-labelledby="userMenuButton">
          <a
            href="{$urls.pages.my_account}"
            class="dropdown-item"
            rel="nofollow"
            {if $urls.current_url == $urls.pages.my_account}aria-current="page"{/if}
          >
            <i class="material-icons me-2" aria-hidden="true">&#xF02E;</i>
            {l s='Your account' d='Shop.Theme.Customeraccount'}
          </a>

          <div class="dropdown-divider"></div>

          <a
            href="{$urls.pages.identity}"
            class="dropdown-item"
            rel="nofollow"
            {if $urls.current_url == $urls.pages.identity}aria-current="page"{/if}
          >
            <i class="material-icons me-2" aria-hidden="true">&#xE853;</i>
            {l s='Information' d='Shop.Theme.Customeraccount'}
          </a>

          {if $customer.addresses|count}
            <a
              href="{$urls.pages.addresses}"
              class="dropdown-item"
              rel="nofollow"
              {if $urls.current_url == $urls.pages.addresses}aria-current="page"{/if}
            >
              <i class="material-icons me-2" aria-hidden="true">&#xF00F;</i>
              {l s='Addresses' d='Shop.Theme.Customeraccount'}
            </a>
          {else}
            <a
              href="{$urls.pages.address}"
              class="dropdown-item"
              rel="nofollow"
              {if $urls.current_url == $urls.pages.address}aria-current="page"{/if}
            >
              <i class="material-icons me-2" aria-hidden="true">&#xEF3A;</i>
              {l s='Add first address' d='Shop.Theme.Customeraccount'}
            </a>
          {/if}

          {if !$configuration.is_catalog}
            <a
              href="{$urls.pages.history}"
              class="dropdown-item"
              rel="nofollow"
              {if $urls.current_url == $urls.pages.history}aria-current="page"{/if}
            >
              <i class="material-icons me-2" aria-hidden="true">&#xE916;</i>
              {l s='Orders' d='Shop.Theme.Customeraccount'}
            </a>
          {/if}

          {if !$configuration.is_catalog}
            <a
              href="{$urls.pages.order_slip}"
              class="dropdown-item"
              rel="nofollow"
              {if $urls.current_url == $urls.pages.order_slip}aria-current="page"{/if}
            >
              <i class="material-icons me-2" aria-hidden="true">&#xE8B0;</i>
              {l s='Credit slips' d='Shop.Theme.Customeraccount'}
            </a>
          {/if}

          {if $configuration.voucher_enabled && !$configuration.is_catalog}
            <a
              href="{$urls.pages.discount}"
              class="dropdown-item"
              rel="nofollow"
              {if $urls.current_url == $urls.pages.discount}aria-current="page"{/if}
            >
              <i class="material-icons me-2" aria-hidden="true">&#xE54E;</i>
              {l s='Vouchers' d='Shop.Theme.Customeraccount'}
            </a>
          {/if}

          {if $configuration.return_enabled && !$configuration.is_catalog}
            <a
              href="{$urls.pages.order_follow}"
              class="dropdown-item"
              rel="nofollow"
              {if $urls.current_url == $urls.pages.order_follow}aria-current="page"{/if}
            >
              <i class="material-icons me-2" aria-hidden="true">&#xE860;</i>
              {l s='Merchandise returns' d='Shop.Theme.Customeraccount'}
            </a>
          {/if}

          <div class="dropdown-divider"></div>

          <a
            href="{$logout_url}"
            class="dropdown-item"
            rel="nofollow"
          >
            <i class="material-icons me-2" aria-hidden="true">&#xE14C;</i>
            {l s='Sign out' d='Shop.Theme.Actions'}
          </a>
        </div>
      </div>
    {else}
      <div class="header-block">
        <a
          {if $page.page_name == 'authentication'}
            href="{$urls.pages.authentication}?back={$urls.pages.my_account|urlencode}"
          {else}
            href="{$urls.pages.authentication}?back={$urls.current_url|urlencode}"
          {/if}
          class="header-block__action-btn"
          rel="nofollow"
          aria-label="{l s='' d='Shop.Theme.Actions'}"
        >
          <i class="material-icons header-block__icon" aria-hidden="true">&#xe7fd;</i>
          <span class="d-none d-md-inline header-block__title">
            {l s='' d='Shop.Theme.Actions'}
          </span>
        </a>
      </div>
    {/if}
  </div>
</div>
