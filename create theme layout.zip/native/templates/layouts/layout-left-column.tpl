{**
 * For the full copyright and license information, please view the
 * LICENSE.md file that was distributed with this source code.
 *}
{extends file='layouts/layout-both-columns.tpl'}

{block name='content_columns'}
  <div class="{block name='container_class'}columns-container container{/block}">
    <div class="row">
      {block name='left_column'}{/block}

      {block name='content_wrapper'}
        <div id="center-column" class="center-column page col-md-8 {if $page.page_name === 'contact'}col-lg-9 {else}col-lg-12 {/if}">
          {hook h='displayContentWrapperTop'}
          {block name='content'}
            <p>Hello world! This is HTML5 Boilerplate.</p>
          {/block}
          {hook h='displayContentWrapperBottom'}
        </div>
      {/block}

      {block name='right_column'}
        <div id="right-column" class="right-column col-md-4 col-lg-3">
          {if $page.page_name == 'product'}
            {hook h='displayRightColumnProduct'}
          {else}
            {hook h='displayRightColumn'}
          {/if}
        </div>
      {/block}
    </div>
  </div>
{/block}