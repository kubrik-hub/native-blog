{**
 * For the full copyright and license information, please view the
 * LICENSE.md file that was distributed with this source code.
 *}
{extends file='layouts/layout-both-columns.tpl'}

{block name="content_columns"}
  <div class="{block name="container_class"}columns-container container{/block}">
    <div class="row">
      {* block name="left_column"}
        <div id="left-column" class="left-column col-md-4 col-lg-3">
          {if $page.page_name == 'product'}
            {hook h='displayLeftColumnProduct'}
          {else}
            {hook h='displayLeftColumn'}
          {/if}
        </div>
      {/block
      *}

      {block name="content_wrapper"}
        <div id="center-column" class="center-column page col-md-12 col-lg-12">
          {hook h='displayContentWrapperTop'}
          {block name="content"}
            <p>Hello world! This is HTML5 Boilerplate.</p>
          {/block}
          {hook h='displayContentWrapperBottom'}
        </div>
      {/block}

      {block name='right_column'}{/block}
    </div>
  </div>
{/block}
