(function () {
  function refreshPreview(tools) {
    var typeSelect = tools.querySelector('.nbps-hook-type');
    var selectedOption = typeSelect.options[typeSelect.selectedIndex];
    var type = typeSelect.value;
    var isProduct = type === 'product';
    var productSelect = tools.querySelector('.nbps-hook-product');
    var productId = parseInt(productSelect.value, 10) || 0;

    productSelect.style.display = isProduct ? '' : 'none';
    tools.querySelector('.nbps-hook-limit-label').style.display = isProduct ? 'none' : '';
    tools.querySelector('.nbps-hook-explanation').textContent = selectedOption.dataset.explanation || '';

    var marker = '';
    if (isProduct && productId > 0) {
      marker = '[nbps:product id="' + productId + '"]';
    } else if (!isProduct) {
      var limit = Math.max(1, Math.min(6, parseInt(tools.querySelector('.nbps-hook-limit').value, 10) || 6));
      marker = '[nbps:products type="' + type + '" limit="' + limit + '"]';
    }
    tools.querySelector('.nbps-hook-code').textContent = marker;
  }

  document.addEventListener('change', function (event) {
    if (!event.target.matches('.nbps-hook-type, .nbps-hook-limit, .nbps-hook-product')) {
      return;
    }

    var tools = event.target.closest('.nbps-editor-tools');
    refreshPreview(tools);
  });

  document.querySelectorAll('.nbps-editor-tools').forEach(refreshPreview);
}());
