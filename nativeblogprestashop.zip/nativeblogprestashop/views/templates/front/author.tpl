{*
 * Native PrestaShop Blog author archive
 * @author Kamel Kelkoul
 * @license OSL-3.0
 *}
{extends file='layouts/layout-full-width.tpl'}

{block name='breadcrumb'}
  {include file='_partials/breadcrumb.tpl'}
{/block}

{block name='content'}
<div class="nativeblogprestashop page page--full-width" id="nativeblogprestashop-author">
  <header class="page-header">
    <h1 class="page-title-section">{$nativeblogprestashop_author.display_name|escape:'htmlall':'UTF-8'}</h1>
    {if $nativeblogprestashop_author.avatar_url}<img class="rounded-circle" src="{$nativeblogprestashop_author.avatar_url|escape:'htmlall':'UTF-8'}" alt="{$nativeblogprestashop_author.display_name|escape:'htmlall':'UTF-8'}">{/if}
    {if $nativeblogprestashop_author.hobbies}<p class="page-header__description">{$nativeblogprestashop_author.hobbies|escape:'htmlall':'UTF-8'}</p>{/if}
  </header>
  <section id="content" class="page-content page-content--general">
    {if $nativeblogprestashop_articles}
      <div class="products nativeblogprestashop-list">
        {foreach from=$nativeblogprestashop_articles item=article}
          <article class="product-miniature js-product-miniature product-miniature__item nativeblogprestashop-list__item">
            <div class="product-miniature__inner">
              {if $article.cover_url}<div class="product-miniature__top"><div class="product-miniature__image-container thumbnail-container"><a class="product-miniature__image-link" href="{$article.link|escape:'htmlall':'UTF-8'}"><img class="product-miniature__image img-fluid" src="{$article.cover_url|escape:'htmlall':'UTF-8'}" loading="lazy" alt="{$article.title|escape:'htmlall':'UTF-8'}"></a></div></div>{/if}
              <div class="product-miniature__bottom"><div class="product-miniature__infos">
                <h2 class="product-miniature__title"><a href="{$article.link|escape:'htmlall':'UTF-8'}">{$article.title|escape:'htmlall':'UTF-8'}</a></h2>
                {if $article.excerpt}<p class="product-miniature__description">{$article.excerpt|escape:'htmlall':'UTF-8'}</p>{/if}
                <div class="product-miniature__meta">
                  <time datetime="{$article.publication_date|escape:'htmlall':'UTF-8'}">{$article.publication_date|escape:'htmlall':'UTF-8'}</time>
                  {if $article.category_name}{if $article.category_url}<a href="{$article.category_url|escape:'htmlall':'UTF-8'}">{$article.category_name|escape:'htmlall':'UTF-8'}</a>{else}<span>{$article.category_name|escape:'htmlall':'UTF-8'}</span>{/if}{/if}
                </div>
                {if $nativeblogprestashop_comments_enabled}<div class="product-miniature__reviews" aria-label="{l s='Rated' d='Modules.Nativeblogprestashop.Shop'} {$article.average_grade|escape:'htmlall':'UTF-8'} {l s='out of 5 stars' d='Modules.Nativeblogprestashop.Shop'}"><span class="grade-stars small-stars" data-ps-ref="grade-stars" data-grade="{$article.average_grade|escape:'htmlall':'UTF-8'}"></span><span>({$article.comment_count|intval})</span></div>{/if}
              </div></div>
            </div>
          </article>
        {/foreach}
      </div>
      {if $nativeblogprestashop_pagination.total_pages > 1}
        <nav class="nativeblogprestashop-pagination" aria-label="{l s='Blog pagination' d='Modules.Nativeblogprestashop.Shop'}">
          {if $nativeblogprestashop_pagination.has_previous}
            <a class="btn btn-outline-primary" href="{$nativeblogprestashop_pagination.previous_url|escape:'htmlall':'UTF-8'}">{l s='Previous' d='Modules.Nativeblogprestashop.Shop'}</a>
          {/if}
          <span class="nativeblogprestashop-pagination__status">
            {l s='Page' d='Modules.Nativeblogprestashop.Shop'} {$nativeblogprestashop_pagination.current_page|intval} / {$nativeblogprestashop_pagination.total_pages|intval}
          </span>
          {if $nativeblogprestashop_pagination.has_next}
            <a class="btn btn-outline-primary" href="{$nativeblogprestashop_pagination.next_url|escape:'htmlall':'UTF-8'}">{l s='Next' d='Modules.Nativeblogprestashop.Shop'}</a>
          {/if}
        </nav>
      {/if}
    {else}<div class="alert alert-info" role="status">{l s='No published articles by this author yet.' d='Modules.Nativeblogprestashop.Shop'}</div>{/if}
  </section>
</div>
{/block}
