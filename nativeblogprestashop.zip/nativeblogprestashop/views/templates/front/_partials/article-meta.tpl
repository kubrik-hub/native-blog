{*
 * Shared article author, category, and publication metadata.
 *}
<div class="nativeblogprestashop-article__meta">
  <div class="nativeblogprestashop-article__meta-avatar">
    {if $meta_author_avatar_url}
      {if $meta_author_url}
        <a href="{$meta_author_url|escape:'htmlall':'UTF-8'}">
          <img class="rounded-circle" src="{$meta_author_avatar_url|escape:'htmlall':'UTF-8'}" alt="{$meta_author|escape:'htmlall':'UTF-8'}" width="40" height="40" loading="lazy">
        </a>
      {else}
        <img class="rounded-circle" src="{$meta_author_avatar_url|escape:'htmlall':'UTF-8'}" alt="{$meta_author|escape:'htmlall':'UTF-8'}" width="40" height="40" loading="lazy">
      {/if}
    {/if}
  </div>
  <div class="nativeblogprestashop-article__meta-details">
    {if $meta_author}
      <div class="nativeblogprestashop-article__meta-line" {if $meta_schema|default:false}itemprop="author" itemscope itemtype="https://schema.org/Person"{/if}>
        <span class="nativeblogprestashop-article__meta-label">{if isset($language.iso_code) && $language.iso_code == 'fr'}Par{else}{l s='By' d='Modules.Nativeblogprestashop.Shop'}{/if}:</span>
        {if $meta_author_url}
          <a href="{$meta_author_url|escape:'htmlall':'UTF-8'}" {if $meta_schema|default:false}itemprop="name"{/if}>{$meta_author|escape:'htmlall':'UTF-8'}</a>
        {else}
          <span {if $meta_schema|default:false}itemprop="name"{/if}>{$meta_author|escape:'htmlall':'UTF-8'}</span>
        {/if}
      </div>
    {/if}
    {if $meta_category_name}
      <div class="nativeblogprestashop-article__meta-line">
        <span class="nativeblogprestashop-article__meta-label">{if isset($language.iso_code) && $language.iso_code == 'fr'}Dans{else}{l s='In' d='Modules.Nativeblogprestashop.Shop'}{/if}:</span>
        {if $meta_category_url}
          <a href="{$meta_category_url|escape:'htmlall':'UTF-8'}">{$meta_category_name|escape:'htmlall':'UTF-8'}</a>
        {else}
          <span>{$meta_category_name|escape:'htmlall':'UTF-8'}</span>
        {/if}
      </div>
    {/if}
    {if $meta_publication_date}
      <div class="nativeblogprestashop-article__meta-line">
        <span class="nativeblogprestashop-article__meta-label">{if isset($language.iso_code) && $language.iso_code == 'fr'}Le{else}{l s='On' d='Modules.Nativeblogprestashop.Shop'}{/if}:</span>
        <time datetime="{$meta_publication_date|escape:'htmlall':'UTF-8'}" {if $meta_schema|default:false}itemprop="datePublished"{/if}>{$meta_publication_date|escape:'htmlall':'UTF-8'}</time>
      </div>
    {/if}
    {if $nativeblogprestashop_comments_enabled|default:false && isset($meta_average_grade) && isset($meta_comment_count)}
      <div class="product-miniature__reviews" aria-label="{l s='Rated' d='Modules.Nativeblogprestashop.Shop'} {$meta_average_grade|escape:'htmlall':'UTF-8'} {l s='out of 5 stars' d='Modules.Nativeblogprestashop.Shop'}">
        <span class="grade-stars small-stars" data-ps-ref="grade-stars" data-grade="{$meta_average_grade|escape:'htmlall':'UTF-8'}"></span>
        <span class="product-miniature__review-count">({$meta_comment_count|intval})</span>
      </div>
    {/if}
  </div>
</div>
