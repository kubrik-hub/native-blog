{*
 * Native PrestaShop Blog — comments & note block.
 * Markup mirrors PrestaShop's native `productcomments` module so that the
 * theme's theme.css handles all of the front styling without any CSS
 * shipped by this module.
 * @author Kamel Kelkoul
 * @license OSL-3.0
 *}
<section class="product-comments-wrapper nativeblogprestashop-comments" aria-labelledby="nativeblog-comments-title" id="nativeblog-comments-title">
  <div id="product-comments-list-header">
    <h2 class="section-title" id="product-comments-list-title">
      {l s='Comments' d='Modules.Nativeblogprestashop.Shop'} ({$nativeblogprestashop_article.comment_count|intval})
    </h2>
    <div class="comments-note">
      <div class="grade-stars" data-ps-ref="grade-stars" data-grade="{$nativeblogprestashop_average_grade|escape:'htmlall':'UTF-8'}" aria-label="{l s='Rated' d='Modules.Nativeblogprestashop.Shop'} {$nativeblogprestashop_average_grade|escape:'htmlall':'UTF-8'} {l s='out of 5 stars' d='Modules.Nativeblogprestashop.Shop'}"></div>
      <span class="comments-note__value">{$nativeblogprestashop_average_grade|escape:'htmlall':'UTF-8'} / 5</span>
    </div>
  </div>

  {if $nativeblogprestashop_comment_error}<p class="alert alert-danger" role="alert">{$nativeblogprestashop_comment_error|escape:'htmlall':'UTF-8'}</p>{/if}
  {if $nativeblogprestashop_comment_success}<p class="alert alert-success" role="status">{$nativeblogprestashop_comment_success|escape:'htmlall':'UTF-8'}</p>{/if}

  {if $nativeblogprestashop_comments}
    <div id="product-comments-list" class="has-comments" data-ps-ref="product-comments-list" data-current-page="{$nativeblogprestashop_comment_pagination.current_page|intval}" data-total-pages="{$nativeblogprestashop_comment_pagination.total_pages|intval}" aria-live="polite">
      {foreach from=$nativeblogprestashop_comments item=comment}
        <article class="product-comment-list-item comment" data-ps-ref="product-comment-item" data-product-comment-id="{$comment.id_nativeblogprestashop_comment|intval}" data-product-id="{$nativeblogprestashop_article.id_nativeblogprestashop_article|intval}" itemprop="review" itemscope itemtype="https://schema.org/Review">
          <div class="comment__top">
            <span class="comment__author" itemprop="author">{$comment.author_name|escape:'htmlall':'UTF-8'}</span>
            <time class="comment__date" itemprop="datePublished" datetime="{$comment.date_add|date_format:'%Y-%m-%d'}">{$comment.date_add|escape:'htmlall':'UTF-8'}</time>
            <div class="grade-stars" data-ps-ref="grade-stars" data-grade="{$comment.grade|intval}" itemprop="reviewRating" itemscope itemtype="https://schema.org/Rating" aria-label="{l s='Rated' d='Modules.Nativeblogprestashop.Shop'} {$comment.grade|intval} {l s='out of 5 stars' d='Modules.Nativeblogprestashop.Shop'}">
              <meta itemprop="worstRating" content="1">
              <meta itemprop="ratingValue" content="{$comment.grade|intval}">
              <meta itemprop="bestRating" content="5">
            </div>
          </div>
          <div class="comment__content">
            <h3 class="comment__title" itemprop="name">{$comment.title|escape:'htmlall':'UTF-8'}</h3>
            <p class="comment__text" itemprop="reviewBody">{$comment.content|escape:'htmlall':'UTF-8'|nl2br}</p>
          </div>
        </article>
      {/foreach}
    </div>
    {if $nativeblogprestashop_comment_pagination.total_pages > 1}
      <nav class="nativeblogprestashop-comments__pagination" aria-label="{l s='Comments pagination' d='Modules.Nativeblogprestashop.Shop'}">
        {if $nativeblogprestashop_comment_pagination.has_previous}
          <a class="btn btn-outline-primary" href="{$nativeblogprestashop_comment_pagination.previous_url|escape:'htmlall':'UTF-8'}">{l s='Previous' d='Modules.Nativeblogprestashop.Shop'}</a>
        {/if}
        <span class="nativeblogprestashop-pagination__status">
          {l s='Page' d='Modules.Nativeblogprestashop.Shop'} {$nativeblogprestashop_comment_pagination.current_page|intval} / {$nativeblogprestashop_comment_pagination.total_pages|intval}
        </span>
        {if $nativeblogprestashop_comment_pagination.has_next}
          <a class="btn btn-outline-primary" href="{$nativeblogprestashop_comment_pagination.next_url|escape:'htmlall':'UTF-8'}">{l s='Next' d='Modules.Nativeblogprestashop.Shop'}</a>
        {/if}
      </nav>
    {/if}
  {else}
    <div id="empty-product-comment" data-ps-ref="empty-product-comment" class="product-comment-list-item py-3">
      {l s='No customer reviews for the moment.' d='Modules.Nativeblogprestashop.Shop'}
    </div>
  {/if}

  <button class="w-100 w-sm-auto btn btn-outline-primary post-product-comment" id="product-comments-list-review-button" type="button" data-bs-toggle="modal" data-bs-target="#post-product-comment-modal" data-ps-ref="product-post-review-button">
    {l s='Write your review' d='Modules.Nativeblogprestashop.Shop'}
  </button>

  <div id="post-product-comment-modal" class="modal fade product-comment-modal" tabindex="-1" aria-labelledby="product-post-review-modal-title" aria-hidden="true" data-ps-ref="product-post-review-modal">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
      <form class="modal-content nativeblogprestashop-comment-form" id="post-product-comment-form" method="post" action="{$nativeblogprestashop_article.canonical_url|escape:'htmlall':'UTF-8'}#nativeblog-comments-title" data-ps-ref="product-post-review-form">
        <div class="modal-header">
          <p class="h2 modal-title" id="product-post-review-modal-title">{l s='Write your review' d='Modules.Nativeblogprestashop.Shop'}</p>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="{l s='Close' d='Modules.Nativeblogprestashop.Shop'}"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="nativeblog_comment_token" value="{$nativeblogprestashop_comment_token|escape:'htmlall':'UTF-8'}">
          <input type="hidden" name="submitNativeBlogComment" value="1">
          <input type="hidden" name="slug" value="{$nativeblogprestashop_article.slug|escape:'htmlall':'UTF-8'}">
          <div class="nativeblogprestashop-hp" aria-hidden="true" style="position:absolute;left:-9999px;top:-9999px;">
            <label for="nativeblog_website">Website</label>
            <input type="text" id="nativeblog_website" name="nativeblog_website" tabindex="-1" autocomplete="off">
          </div>
          <div class="mb-3">
            <label class="form-label required" for="customer_name">{l s='Your name' d='Modules.Nativeblogprestashop.Shop'}</label>
            <input class="form-control" id="customer_name" name="customer_name" maxlength="64" required>
          </div>
          <div class="mb-3">
            <label class="form-label required" for="customer_email">{l s='Your email' d='Modules.Nativeblogprestashop.Shop'}</label>
            <input class="form-control" id="customer_email" name="customer_email" type="email" required>
          </div>
          <div class="mb-3">
            <label class="form-label required" for="comment_title">{l s='Title of your review' d='Modules.Nativeblogprestashop.Shop'}</label>
            <input class="form-control" id="comment_title" name="comment_title" maxlength="64" required>
          </div>
          <div class="mb-3">
            <label class="form-label required" for="comment_content">{l s='Your review' d='Modules.Nativeblogprestashop.Shop'}</label>
            <textarea class="form-control" id="comment_content" name="comment_content" maxlength="5000" required></textarea>
          </div>
          <fieldset class="star-rating-group">
            <legend class="form-label required" id="nativeblog-rating-label">{l s='Rating' d='Modules.Nativeblogprestashop.Shop'}</legend>
            <div class="stars-selector" aria-labelledby="nativeblog-rating-label">
              {for $i=1 to 5}
                <input class="stars-selector__input visually-hidden" id="nativeblog-star-{$i}" type="radio" name="criterion" value="{$i}" aria-label="{$i} {if $i == 1}{l s='star' d='Modules.Nativeblogprestashop.Shop'}{else}{l s='stars' d='Modules.Nativeblogprestashop.Shop'}{/if} {l s='out of 5' d='Modules.Nativeblogprestashop.Shop'}" required>
                <label class="stars-selector__input-label" for="nativeblog-star-{$i}" aria-hidden="true"></label>
              {/for}
            </div>
          </fieldset>
          <p class="required"><sup>*</sup> {l s='Required fields' d='Modules.Nativeblogprestashop.Shop'}</p>
        </div>
        <div class="modal-footer">
          <button class="btn btn-outline-primary" type="button" data-bs-dismiss="modal">{l s='Cancel' d='Modules.Nativeblogprestashop.Shop'}</button>
          <button class="btn btn-primary" type="submit" data-ps-action="form-validation-submit">{l s='Send' d='Modules.Nativeblogprestashop.Shop'}</button>
        </div>
      </form>
    </div>
  </div>
</section>
