{if $nativeblogprestashop_product_block_title}
  <h2 class="nativeblogprestashop-product-block__title">{$nativeblogprestashop_product_block_title|escape:'htmlall':'UTF-8'}</h2>
{/if}
<div class="products nativeblogprestashop-product-block">
  {foreach from=$nativeblogprestashop_products item=product}
    {include file='catalog/_partials/miniatures/product.tpl' product=$product}
  {/foreach}
</div>
