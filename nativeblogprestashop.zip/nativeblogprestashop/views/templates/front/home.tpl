{*
 * Native PrestaShop Blog
 * @author Kamel Kelkoul
 * @license OSL-3.0
 *}
{extends file='layouts/layout-full-width.tpl'}

{block name='breadcrumb'}
  {include file='_partials/breadcrumb.tpl'}
{/block}

{block name='content'}
<div class="nativeblogprestashop page page--full-width" id="{$nativeblogprestashop_page_id|escape:'htmlall':'UTF-8'}">
  <div class="page-header">
    <h1 class="page-title-section">{$nativeblogprestashop_title|escape:'htmlall':'UTF-8'}</h1>
  </div>
  <section id="content" class="page-content page-content--general">
  {if $nativeblogprestashop_articles}
    <div id="nativeblogprestashop-list" class="products nativeblogprestashop-list">
      {foreach from=$nativeblogprestashop_articles item=article}
        <article class="product-miniature js-product-miniature product-miniature__item nativeblogprestashop-list__item">
          <div class="product-miniature__inner">
            <div class="product-miniature__top">
              {if $article.cover_url}
                <div class="product-miniature__image-container thumbnail-container">
                  <a class="product-miniature__image-link outline outline--rounded" href="{$article.link|escape:'htmlall':'UTF-8'}">
                    <picture>
                      <img class="product-miniature__image img-fluid" src="{$article.cover_url|escape:'htmlall':'UTF-8'}" loading="lazy" alt="{$article.title|escape:'htmlall':'UTF-8'}" title="{$article.title|escape:'htmlall':'UTF-8'}">
                    </picture>
                  </a>
                </div>
              {/if}
            </div>
            <div class="product-miniature__bottom">
              <div class="product-miniature__infos">
                <h2 class="blog-miniature__title">
                  <a href="{$article.link|escape:'htmlall':'UTF-8'}">{$article.title|escape:'htmlall':'UTF-8'}</a>
                </h2>
                {if $article.excerpt}
                  <p class="product-miniature__description">
                    {$article.excerpt|escape:'htmlall':'UTF-8'}
                  </p>
                {/if}
                {include file='module:nativeblogprestashop/views/templates/front/_partials/article-meta.tpl'
                  meta_author=$article.author_display
                  meta_author_url=$article.author_url
                  meta_author_avatar_url=$article.author_avatar_url
                  meta_category_name=$article.category_name
                  meta_category_url=$article.category_url
                  meta_publication_date=$article.publication_date
                  meta_average_grade=$article.average_grade
                  meta_comment_count=$article.comment_count}
              </div>
            </div>
          </div>
        </article>
      {/foreach}
    </div>
    {if $nativeblogprestashop_pagination.total_pages > 1}
      <nav class="nativeblogprestashop-pagination" aria-label="{l s='Blog pagination' d='Modules.Nativeblogprestashop.Shop'}">
        {if $nativeblogprestashop_pagination.has_previous}
          <a class="btn btn-outline-primary" href="{$nativeblogprestashop_pagination.previous_url|escape:'htmlall':'UTF-8'}">{l s='Previous' d='Modules.Nativeblogprestashop.Shop'}</a>
        {/if}
        <span class="nativeblogprestashop-pagination__status">
          {l s='Page' d='Modules.Nativeblogprestashop.Shop'} {$nativeblogprestashop_pagination.current_page|intval} / {$nativeblogprestashop_pagination.total_pages|intval}
        </span>
        {if $nativeblogprestashop_pagination.has_next}
          <a class="btn btn-outline-primary" href="{$nativeblogprestashop_pagination.next_url|escape:'htmlall':'UTF-8'}">{l s='Next' d='Modules.Nativeblogprestashop.Shop'}</a>
        {/if}
      </nav>
    {/if}
  {else}
    <div class="alert alert-info" role="status">{l s='No published articles yet.' d='Modules.Nativeblogprestashop.Shop'}</div>
  {/if}
  </section>
</div>
{/block}
