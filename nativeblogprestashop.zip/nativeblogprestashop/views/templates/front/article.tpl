{*
 * Native PrestaShop Blog article
 * @author Kamel Kelkoul
 * @license OSL-3.0
 *}
{extends file='layouts/layout-full-width.tpl'}

{block name='breadcrumb'}
  {include file='_partials/breadcrumb.tpl'}
{/block}

{block name='content'}
<article class="nativeblogprestashop page page--full-width" id="nativeblogprestashop-article" itemscope itemtype="https://schema.org/Article">
  {* 1. Article title (page header / breadcrumb) *}
  <div class="page-header">
    <h1 class="page-title-section">{$nativeblogprestashop_article.title|escape:'htmlall':'UTF-8'}</h1>
    {include file='module:nativeblogprestashop/views/templates/front/_partials/article-meta.tpl'
      meta_author=$nativeblogprestashop_article.author
      meta_author_url=$nativeblogprestashop_article.author_url
      meta_author_avatar_url=$nativeblogprestashop_article.author_avatar_url
      meta_category_name=$nativeblogprestashop_article.category_name
      meta_category_url=$nativeblogprestashop_article.category_url
      meta_publication_date=$nativeblogprestashop_article.publication_date
      meta_average_grade=$nativeblogprestashop_article.average_grade
      meta_comment_count=$nativeblogprestashop_article.comment_count
      meta_schema=true}
  </div>
  <section id="content" class="page-content page-content--general">
    {* Article content (WYSIWYG - nofilter is intentional for HTML content) *}
    <div class="nativeblogprestashop-article__content" itemprop="articleBody">
      {$nativeblogprestashop_article.content nofilter}
    </div>
  {if $nativeblogprestashop_article.canonical_url}
    <link rel="canonical" href="{$nativeblogprestashop_article.canonical_url|escape:'htmlall':'UTF-8'}">
  {/if}
  {* 8. Article tags *}
  {if $nativeblogprestashop_article.tags}
    <ul class="nativeblogprestashop-article__tags" aria-label="{l s='Tags' d='Modules.Nativeblogprestashop.Shop'}">
      {foreach from=$nativeblogprestashop_article.tags item=tag}
        <li><span class="badge">{$tag.name|escape:'htmlall':'UTF-8'}</span></li>
      {/foreach}
    </ul>
  {/if}
  </section>
  {* 9. Comments + rating, and 10. article form *}
  {if $nativeblogprestashop_comments_enabled}
    {include file='module:nativeblogprestashop/views/templates/front/_partials/comments.tpl'}
  {/if}
</article>
{/block}
