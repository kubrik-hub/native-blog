{*
 * Native PrestaShop Blog category list.
 * @author Kamel Kelkoul
 * @license OSL-3.0
 *}
<div class="panel">
  <div class="panel-heading"><i class="icon-folder-open"></i> {l s='Categories' mod='nativeblogprestashop'}</div>
  <a class="btn btn-primary" href="{$nativeblogprestashop_add_url|escape:'htmlall':'UTF-8'}">
    <i class="icon-plus"></i> {l s='Add new category' mod='nativeblogprestashop'}
  </a>
  <table class="table">
    <thead><tr><th>ID</th><th>{l s='Name' mod='nativeblogprestashop'}</th><th>{l s='Slug' mod='nativeblogprestashop'}</th><th>{l s='Actions' mod='nativeblogprestashop'}</th></tr></thead>
    <tbody>
      {foreach from=$nativeblogprestashop_categories item=category}
        <tr>
          <td>{$category.id_nativeblogprestashop_category|intval}</td>
          <td>{$category.display_name|escape:'htmlall':'UTF-8'}</td>
          <td>{$category.slug|escape:'htmlall':'UTF-8'}</td>
          <td>
            <a class="btn btn-default" href="{$nativeblogprestashop_edit_base|cat:$category.id_nativeblogprestashop_category|escape:'htmlall':'UTF-8'}">{l s='Edit' mod='nativeblogprestashop'}</a>
            <a class="btn btn-default" href="{$nativeblogprestashop_delete_base|cat:$category.id_nativeblogprestashop_category|escape:'htmlall':'UTF-8'}" onclick="return confirm('{l s='Delete this category?' mod='nativeblogprestashop' js=1}');">{l s='Delete' mod='nativeblogprestashop'}</a>
          </td>
        </tr>
      {foreachelse}
        <tr><td colspan="4">{l s='No categories yet.' mod='nativeblogprestashop'}</td></tr>
      {/foreach}
    </tbody>
  </table>
</div>
