{*
 * Native PrestaShop Blog comment list.
 * @author Kamel Kelkoul
 * @license OSL-3.0
 *}
<div class="panel">
  <div class="panel-heading">
    <i class="icon-comments"></i> {l s='Comments' mod='nativeblogprestashop'}
    {if $nativeblogprestashop_comment_total_pending > 0}
      <span class="badge">{$nativeblogprestashop_comment_total_pending|intval} {l s='pending' mod='nativeblogprestashop'}</span>
    {/if}
  </div>

  <form method="get" action="{$nativeblogprestashop_comment_form_url|escape:'htmlall':'UTF-8'}" class="form-inline nativeblogprestashop-comment-filters" style="margin-bottom:15px;">
    <input type="hidden" name="controller" value="AdminNativeBlogComments">
    <div class="form-group" style="margin-right:10px;">
      <label for="nbps_comment_status">{l s='Status' mod='nativeblogprestashop'}</label>
      <select class="form-control" id="nbps_comment_status" name="nbps_comment_status">
        <option value=""{if $nativeblogprestashop_comment_status == ''} selected{/if}>{l s='All' mod='nativeblogprestashop'}</option>
        <option value="pending"{if $nativeblogprestashop_comment_status == 'pending'} selected{/if}>{l s='Pending approval' mod='nativeblogprestashop'}</option>
        <option value="approved"{if $nativeblogprestashop_comment_status == 'approved'} selected{/if}>{l s='Approved' mod='nativeblogprestashop'}</option>
      </select>
    </div>
    <div class="form-group" style="margin-right:10px;">
      <label for="nbps_comment_search">{l s='Search' mod='nativeblogprestashop'}</label>
      <input type="text" class="form-control" id="nbps_comment_search" name="nbps_comment_search" value="{$nativeblogprestashop_comment_search|escape:'htmlall':'UTF-8'}" placeholder="{l s='Author, title, article, content…' mod='nativeblogprestashop'}">
    </div>
    {if $nativeblogprestashop_comment_article_filter}
      <input type="hidden" name="id_nativeblogprestashop_article" value="{$nativeblogprestashop_comment_article_filter|intval}">
      <span class="label label-info">{l s='Filtered on one article' mod='nativeblogprestashop'} &mdash;
        <a href="{$nativeblogprestashop_comment_form_url|escape:'htmlall':'UTF-8'}{if $nativeblogprestashop_comment_status}&nbps_comment_status={$nativeblogprestashop_comment_status|escape:'htmlall':'UTF-8'}{/if}" style="color:#fff;text-decoration:underline;">{l s='clear' mod='nativeblogprestashop'}</a>
      </span>
    {/if}
    <button type="submit" class="btn btn-default"><i class="icon-search"></i> {l s='Filter' mod='nativeblogprestashop'}</button>
  </form>

  <form method="post" action="{$nativeblogprestashop_comment_form_url|escape:'htmlall':'UTF-8'}" id="nativeblogprestashop-comments-form">
    <input type="hidden" name="token" value="{$nativeblogprestashop_comment_token|escape:'htmlall':'UTF-8'}">
    <input type="hidden" name="submitNativeBlogCommentBulk" value="1">
    <table class="table">
      <thead>
        <tr>
          <th style="width:20px;"><input type="checkbox" id="nativeblogprestashop-check-all"></th>
          <th>{l s='Article' mod='nativeblogprestashop'}</th>
          <th>{l s='Author' mod='nativeblogprestashop'}</th>
          <th>{l s='Title / review' mod='nativeblogprestashop'}</th>
          <th>{l s='Rating' mod='nativeblogprestashop'}</th>
          <th>{l s='Date' mod='nativeblogprestashop'}</th>
          <th>{l s='Status' mod='nativeblogprestashop'}</th>
          <th>{l s='Actions' mod='nativeblogprestashop'}</th>
        </tr>
      </thead>
      <tbody>
        {foreach from=$nativeblogprestashop_comments item=comment}
          <tr>
            <td><input type="checkbox" name="comment_ids[]" value="{$comment.id_nativeblogprestashop_comment|intval}"></td>
            <td>
              {if $comment.article_url}
                <a href="{$comment.article_url|escape:'htmlall':'UTF-8'}" target="_blank">{$comment.article_title|escape:'htmlall':'UTF-8'}</a>
              {else}
                {$comment.article_title|escape:'htmlall':'UTF-8'}
              {/if}
            </td>
            <td>{$comment.author_name|escape:'htmlall':'UTF-8'}<br><small>{$comment.author_email|escape:'htmlall':'UTF-8'}</small></td>
            <td><strong>{$comment.title|escape:'htmlall':'UTF-8'}</strong><br>{$comment.content|truncate:120:'…'|escape:'htmlall':'UTF-8'}</td>
            <td>
              {section name=star start=0 loop=5 step=1}
                {if $smarty.section.star.index < $comment.grade}★{else}☆{/if}
              {/section}
              <span>({$comment.grade|intval}/5)</span>
            </td>
            <td>{$comment.date_add|escape:'htmlall':'UTF-8'}</td>
            <td>
              {if $comment.approved}
                <span class="label label-success">{l s='Approved' mod='nativeblogprestashop'}</span>
              {else}
                <span class="label label-warning">{l s='Pending' mod='nativeblogprestashop'}</span>
              {/if}
            </td>
            <td class="nativeblogprestashop-comment-actions">
              {if !$comment.approved}
                <a class="btn btn-default btn-xs" href="{$nativeblogprestashop_comment_approve_base|cat:$comment.id_nativeblogprestashop_comment|escape:'htmlall':'UTF-8'}&token={$nativeblogprestashop_comment_token|escape:'htmlall':'UTF-8'}" title="{l s='Approve' mod='nativeblogprestashop'}"><i class="icon-check"></i> {l s='Approve' mod='nativeblogprestashop'}</a>
              {else}
                <a class="btn btn-default btn-xs" href="{$nativeblogprestashop_comment_reject_base|cat:$comment.id_nativeblogprestashop_comment|escape:'htmlall':'UTF-8'}&token={$nativeblogprestashop_comment_token|escape:'htmlall':'UTF-8'}" title="{l s='Unpublish' mod='nativeblogprestashop'}"><i class="icon-eye-slash"></i> {l s='Unpublish' mod='nativeblogprestashop'}</a>
              {/if}
              <a class="btn btn-default btn-xs" href="{$nativeblogprestashop_comment_delete_base|cat:$comment.id_nativeblogprestashop_comment|escape:'htmlall':'UTF-8'}&token={$nativeblogprestashop_comment_token|escape:'htmlall':'UTF-8'}" onclick="return confirm('{l s='Delete this review?' mod='nativeblogprestashop' js=1}');" title="{l s='Delete' mod='nativeblogprestashop'}"><i class="icon-trash"></i></a>
            </td>
          </tr>
        {foreachelse}
          <tr><td colspan="8">{l s='No reviews found.' mod='nativeblogprestashop'}</td></tr>
        {/foreach}
      </tbody>
    </table>

    {if $nativeblogprestashop_comments}
      <div class="nativeblogprestashop-comment-bulk" style="margin-top:10px;">
        <select name="bulk_action" class="form-control" style="display:inline-block;width:auto;">
          <option value="approve">{l s='Approve selection' mod='nativeblogprestashop'}</option>
          <option value="reject">{l s='Unpublish selection' mod='nativeblogprestashop'}</option>
          <option value="delete">{l s='Delete selection' mod='nativeblogprestashop'}</option>
        </select>
        <button type="submit" class="btn btn-default" onclick="return confirm('{l s='Apply this action to every selected review?' mod='nativeblogprestashop' js=1}');">{l s='Apply' mod='nativeblogprestashop'}</button>
      </div>
    {/if}
  </form>

  {if $nativeblogprestashop_comment_pagination.total_pages > 1}
    <nav class="nativeblogprestashop-pagination" style="margin-top:15px;">
      {if $nativeblogprestashop_comment_pagination.has_previous}
        <a class="btn btn-default" href="{$nativeblogprestashop_comment_pagination.previous_url|escape:'htmlall':'UTF-8'}">&laquo; {l s='Previous' mod='nativeblogprestashop'}</a>
      {/if}
      <span>{l s='Page' mod='nativeblogprestashop'} {$nativeblogprestashop_comment_pagination.current_page|intval} / {$nativeblogprestashop_comment_pagination.total_pages|intval}</span>
      {if $nativeblogprestashop_comment_pagination.has_next}
        <a class="btn btn-default" href="{$nativeblogprestashop_comment_pagination.next_url|escape:'htmlall':'UTF-8'}">{l s='Next' mod='nativeblogprestashop'} &raquo;</a>
      {/if}
    </nav>
  {/if}
</div>
<script type="text/javascript">
  document.addEventListener('DOMContentLoaded', function () {
    var checkAll = document.getElementById('nativeblogprestashop-check-all');
    if (checkAll) {
      checkAll.addEventListener('change', function () {
        var boxes = document.querySelectorAll('#nativeblogprestashop-comments-form input[name="comment_ids[]"]');
        boxes.forEach(function (box) { box.checked = checkAll.checked; });
      });
    }
  });
</script>
