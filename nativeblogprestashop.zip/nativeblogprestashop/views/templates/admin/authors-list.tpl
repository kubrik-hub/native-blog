{*
 * Native PrestaShop Blog author list.
 * @author Kamel Kelkoul
 * @license OSL-3.0
 *}
<div class="panel">
  <div class="panel-heading"><i class="icon-user"></i> {l s='Authors' mod='nativeblogprestashop'}</div>
  <a class="btn btn-primary" href="{$nativeblogprestashop_add_url|escape:'htmlall':'UTF-8'}">{l s='Add new author' mod='nativeblogprestashop'}</a>
  <table class="table">
    <thead><tr><th>ID</th><th>{l s='First name' mod='nativeblogprestashop'}</th><th>{l s='Last name' mod='nativeblogprestashop'}</th><th>{l s='Slug' mod='nativeblogprestashop'}</th><th>{l s='Actions' mod='nativeblogprestashop'}</th></tr></thead>
    <tbody>
      {foreach from=$nativeblogprestashop_authors item=author}
        <tr>
          <td>{$author.id_nativeblogprestashop_author|intval}</td>
          <td>{$author.firstname|escape:'htmlall':'UTF-8'}</td>
          <td>{$author.lastname|escape:'htmlall':'UTF-8'}</td>
          <td>{$author.slug|escape:'htmlall':'UTF-8'}</td>
          <td>
            <a class="btn btn-default" href="{$nativeblogprestashop_edit_base|cat:$author.id_nativeblogprestashop_author|escape:'htmlall':'UTF-8'}">{l s='Edit' mod='nativeblogprestashop'}</a>
            <a class="btn btn-default" href="{$nativeblogprestashop_delete_base|cat:$author.id_nativeblogprestashop_author|escape:'htmlall':'UTF-8'}" onclick="return confirm('{l s='Delete this author?' mod='nativeblogprestashop' js=1}');">{l s='Delete' mod='nativeblogprestashop'}</a>
          </td>
        </tr>
      {foreachelse}
        <tr><td colspan="5">{l s='No authors yet.' mod='nativeblogprestashop'}</td></tr>
      {/foreach}
    </tbody>
  </table>
</div>
