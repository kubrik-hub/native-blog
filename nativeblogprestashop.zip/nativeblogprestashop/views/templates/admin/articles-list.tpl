{*
 * Native PrestaShop Blog article list.
 * @author Kamel Kelkoul
 * @license OSL-3.0
 *}
<div class="panel">
  <div class="panel-heading"><i class="icon-book"></i> {l s='Articles' mod='nativeblogprestashop'}</div>
  <a class="btn btn-primary" href="{$nativeblogprestashop_add_url|escape:'htmlall':'UTF-8'}">
    <i class="icon-plus"></i> {l s='Add new article' mod='nativeblogprestashop'}
  </a>
  <table class="table">
    <thead><tr><th>ID</th><th>{l s='Title' mod='nativeblogprestashop'}</th><th>{l s='Slug' mod='nativeblogprestashop'}</th><th>{l s='Active' mod='nativeblogprestashop'}</th><th>{l s='Comments' mod='nativeblogprestashop'}</th><th>{l s='Actions' mod='nativeblogprestashop'}</th></tr></thead>
    <tbody>
      {foreach from=$nativeblogprestashop_articles item=article}
        <tr>
          <td>{$article.id_nativeblogprestashop_article|intval}</td>
          <td>{$article.title|escape:'htmlall':'UTF-8'}</td>
          <td>{$article.slug|escape:'htmlall':'UTF-8'}</td>
          <td>{if $article.active}{l s='Yes' mod='nativeblogprestashop'}{else}{l s='No' mod='nativeblogprestashop'}{/if}</td>
          <td>
            <a href="{$article.comments_url|escape:'htmlall':'UTF-8'}">
              {if $article.pending_comments > 0}
                <span class="label label-warning">{$article.pending_comments|intval} {l s='pending' mod='nativeblogprestashop'}</span>
              {else}
                {l s='View comments' mod='nativeblogprestashop'}
              {/if}
            </a>
          </td>
          <td>
            <a class="btn btn-default" href="{$nativeblogprestashop_edit_base|cat:$article.id_nativeblogprestashop_article|escape:'htmlall':'UTF-8'}">{l s='Edit' mod='nativeblogprestashop'}</a>
            <a class="btn btn-default" href="{$nativeblogprestashop_delete_base|cat:$article.id_nativeblogprestashop_article|escape:'htmlall':'UTF-8'}" onclick="return confirm('{l s='Delete this article?' mod='nativeblogprestashop' js=1}');">{l s='Delete' mod='nativeblogprestashop'}</a>
          </td>
        </tr>
      {foreachelse}
        <tr><td colspan="6">{l s='No articles yet.' mod='nativeblogprestashop'}</td></tr>
      {/foreach}
    </tbody>
  </table>
</div>
