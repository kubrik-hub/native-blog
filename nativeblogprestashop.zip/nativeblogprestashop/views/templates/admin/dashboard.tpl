{*
 * Native PrestaShop Blog dashboard
 * @author Kamel Kelkoul
 * @license OSL-3.0
 *}
<div class="panel">
  <h3>{l s='Native PrestaShop Blog' mod='nativeblogprestashop'}</h3>
  <p>{l s='Use the child tabs to manage categories, articles, authors and comments.' mod='nativeblogprestashop'}</p>
</div>
