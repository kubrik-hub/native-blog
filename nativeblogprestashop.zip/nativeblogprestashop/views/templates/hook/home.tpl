{*
 * Native PrestaShop Blog
 * @author Kamel Kelkoul
 * @license OSL-3.0
 *}
<section class="nativeblogprestashop" id="nativeblogprestashop-home">
  <div class="container">
    <h2 class-"page-title-section">
      {$nativeblogprestashop_title|escape:'htmlall':'UTF-8'}
    </h2>
    {if $nativeblogprestashop_home_articles}
      <div class="products nativeblogprestashop-home__articles">
        {foreach from=$nativeblogprestashop_home_articles item=article}
          <article class="product-miniature product-miniature__item">
            {if $article.cover_url}
              <a class="product-miniature__image-link" href="{$article.link|escape:'htmlall':'UTF-8'}">
                <img class="product-miniature__image img-fluid" src="{$article.cover_url|escape:'htmlall':'UTF-8'}" alt="{$article.title|escape:'htmlall':'UTF-8'}" loading="lazy">
              </a>
            {/if}
            <h3 class="blog-miniature__title">
              <a href="{$article.link|escape:'htmlall':'UTF-8'}">
                {$article.title|escape:'htmlall':'UTF-8'}
              </a>
            </h3>
            {if $article.excerpt}
              <p class="product-miniature__description">
                {$article.excerpt|escape:'htmlall':'UTF-8'}
              </p>
            {/if}
            {include file='module:nativeblogprestashop/views/templates/front/_partials/article-meta.tpl'
              meta_author=$article.author_display
              meta_author_url=$article.author_url
              meta_author_avatar_url=$article.author_avatar_url
              meta_category_name=$article.category_name
              meta_category_url=$article.category_url
              meta_publication_date=$article.publication_date
              meta_average_grade=$article.average_grade
              meta_comment_count=$article.comment_count}
          </article>
        {/foreach}
      </div>
    {/if}
  </div>
</section>
