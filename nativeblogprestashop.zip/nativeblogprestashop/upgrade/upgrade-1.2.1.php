<?php
/**
 * Native PrestaShop Blog 1.2.1 upgrade.
 *
 * Version 1.2.1 is a maintenance release that fixes minor compliance issues:
 * - Replaced $this->trans() with $this->l() for consistency
 * - Translated all French comments to English
 * - Added security documentation for WYSIWYG content
 * - Cleaned up test images from upload directory
 *
 * @author Kamel Kelkoul
 * @license https://opensource.org/licenses/OSL-3.0 Open Software License 3.0 (OSL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_2_1($module): bool
{
    // This is a code-only upgrade with no database changes
    // The upgrade process will handle file replacement automatically
    return true;
}
