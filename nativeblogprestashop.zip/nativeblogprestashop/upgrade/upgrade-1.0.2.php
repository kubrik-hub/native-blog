<?php
/**
 * Native PrestaShop Blog 1.0.2 upgrade.
 *
 * Repairs tab parent links and access roles without changing module data.
 *
 * @author Kamel Kelkoul
 * @license https://opensource.org/licenses/OSL-3.0 Open Software License 3.0 (OSL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_2($module): bool
{
    $parentId = (int) Tab::getIdFromClassName('AdminNativeBlog');
    if ($parentId === 0) {
        return false;
    }

    foreach (['AdminNativeBlogCategories', 'AdminNativeBlogArticles'] as $className) {
        $tabId = (int) Tab::getIdFromClassName($className);
        if ($tabId === 0) {
            return false;
        }

        $tab = new Tab($tabId);
        if ((int) $tab->id_parent !== $parentId) {
            $tab->id_parent = $parentId;
            if (!$tab->update()) {
                return false;
            }
        }

        if (!Tab::initAccess($tabId)) {
            return false;
        }
    }

    return (bool) Tab::initAccess($parentId);
}
