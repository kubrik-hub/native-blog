<?php
/**
 * Native PrestaShop Blog 1.2.2 upgrade.
 *
 * Version 1.2.2 fixes several issues:
 * - Added config.xml for proper zip installation
 * - Removed duplicate author field in article creation form
 * - Removed duplicate slug field in article creation form
 * - Removed remove cover image field in article creation form
 * - Fixed pending comments display issue (orphaned comments)
 * - Fixed security token error in comment validation
 *
 * @author Kamel Kelkoul
 * @license https://opensource.org/licenses/OSL-3.0 Open Software License 3.0 (OSL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_2_2($module): bool
{
    // This is a code-only upgrade with no database changes
    // The upgrade process will handle file replacement automatically
    return true;
}
