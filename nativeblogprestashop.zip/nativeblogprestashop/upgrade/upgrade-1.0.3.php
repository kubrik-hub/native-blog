<?php
/**
 * Native PrestaShop Blog 1.0.3 upgrade.
 *
 * Repairs legacy admin tab access without changing module data.
 *
 * @author Kamel Kelkoul
 * @license https://opensource.org/licenses/OSL-3.0 Open Software License 3.0 (OSL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_3($module): bool
{
    foreach (['AdminNativeBlog', 'AdminNativeBlogCategories', 'AdminNativeBlogArticles'] as $className) {
        $tabId = (int) Tab::getIdFromClassName($className);
        if ($tabId === 0 || !Tab::initAccess($tabId)) {
            return false;
        }
    }

    return true;
}
