<?php
/**
 * Native PrestaShop Blog 1.2.0 upgrade.
 *
 * Adds the "Comments" admin tab (dedicated moderation screen for the
 * blog's product-comments-like review system) under the module's menu.
 *
 * @author Kamel Kelkoul
 * @license https://opensource.org/licenses/OSL-3.0 Open Software License 3.0 (OSL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_2_0($module): bool
{
    if (Tab::getIdFromClassName('AdminNativeBlogComments')) {
        return true;
    }

    $parentId = (int) Tab::getIdFromClassName('AdminNativeBlog');
    if ($parentId <= 0) {
        return false;
    }

    $tab = new Tab();
    $tab->class_name = 'AdminNativeBlogComments';
    $tab->module = $module->name;
    $tab->active = true;
    $tab->id_parent = $parentId;
    foreach (Language::getLanguages(true) as $language) {
        $tab->name[(int) $language['id_lang']] = $module->l('Comments', 'nativeblogprestashop');
    }

    return $tab->add();
}
