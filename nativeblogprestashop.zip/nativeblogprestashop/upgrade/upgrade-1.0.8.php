<?php
/**
 * Native PrestaShop Blog 1.0.8 upgrade.
 *
 * Adds shop-scoped authors and preserves the existing article author text.
 *
 * @author Kamel Kelkoul
 * @license https://opensource.org/licenses/OSL-3.0 Open Software License 3.0 (OSL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_8($module): bool
{
    $db = Db::getInstance();
    $articleTable = _DB_PREFIX_ . 'nativeblogprestashop_article';
    $column = $db->getValue(
        'SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = "' . pSQL($articleTable) . '" AND COLUMN_NAME = "id_nativeblogprestashop_author"'
    );
    if ($column === false || ((int) $column === 0 && !$db->execute(
        'ALTER TABLE `' . bqSQL($articleTable) . '` ADD `id_nativeblogprestashop_author` INT UNSIGNED NULL AFTER `id_nativeblogprestashop_category`'
    ))) {
        return false;
    }
    foreach ([
        'CREATE TABLE IF NOT EXISTS `' . bqSQL(_DB_PREFIX_ . 'nativeblogprestashop_author') . '` (
            `id_nativeblogprestashop_author` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `avatar` VARCHAR(255) NULL, `date_add` DATETIME NOT NULL, `date_upd` DATETIME NOT NULL,
            PRIMARY KEY (`id_nativeblogprestashop_author`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
        'CREATE TABLE IF NOT EXISTS `' . bqSQL(_DB_PREFIX_ . 'nativeblogprestashop_author_lang') . '` (
            `id_nativeblogprestashop_author` INT UNSIGNED NOT NULL, `id_lang` INT UNSIGNED NOT NULL,
            `firstname` VARCHAR(128) NOT NULL, `lastname` VARCHAR(128) NOT NULL, `hobbies` TEXT NULL,
            PRIMARY KEY (`id_nativeblogprestashop_author`, `id_lang`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
        'CREATE TABLE IF NOT EXISTS `' . bqSQL(_DB_PREFIX_ . 'nativeblogprestashop_author_shop') . '` (
            `id_nativeblogprestashop_author` INT UNSIGNED NOT NULL, `id_shop` INT UNSIGNED NOT NULL,
            `active` TINYINT(1) UNSIGNED NOT NULL DEFAULT 1,
            PRIMARY KEY (`id_nativeblogprestashop_author`, `id_shop`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
    ] as $query) {
        if (!$db->execute($query)) {
            return false;
        }
    }
    return true;
}
