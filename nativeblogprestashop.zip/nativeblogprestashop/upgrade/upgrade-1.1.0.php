<?php
/**
 * Native PrestaShop Blog 1.1.0 upgrade.
 *
 * Adds the author `slug` column (used for the author archive URL) and
 * backfills a unique slug for every existing author.
 *
 * @author Kamel Kelkoul
 * @license https://opensource.org/licenses/OSL-3.0 Open Software License 3.0 (OSL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_1_0($module): bool
{
    // ensureDatabaseSchema() is idempotent and already contains the full
    // migration (column creation + slug backfill), so the upgrade script
    // simply delegates to it instead of duplicating the logic.
    return $module->ensureDatabaseSchema();
}
