<?php
/**
 * Native PrestaShop Blog 1.0.1 upgrade.
 *
 * This upgrade is intentionally non-destructive. It only ensures the
 * module's Back Office tabs exist; it does not alter or remove data tables.
 *
 * @author Kamel Kelkoul
 * @license https://opensource.org/licenses/OSL-3.0 Open Software License 3.0 (OSL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_1($module): bool
{
    $parentId = (int) Tab::getIdFromClassName('AdminNativeBlog');
    if ($parentId === 0) {
        $parent = new Tab();
        $parent->class_name = 'AdminNativeBlog';
        $parent->module = $module->name;
        $parent->active = true;
        $parent->id_parent = 0;
        foreach (Language::getLanguages(true) as $language) {
            $parent->name[(int) $language['id_lang']] = $module->l('Blog');
        }
        if (!$parent->add()) {
            return false;
        }
        $parentId = (int) $parent->id;
    }

    foreach ([
        ['AdminNativeBlogCategories', 'Categories'],
        ['AdminNativeBlogArticles', 'Articles'],
    ] as $child) {
        $tabId = (int) Tab::getIdFromClassName($child[0]);
        if ($tabId > 0) {
            continue;
        }

        $tab = new Tab();
        $tab->class_name = $child[0];
        $tab->module = $module->name;
        $tab->active = true;
        $tab->id_parent = $parentId;
        foreach (Language::getLanguages(true) as $language) {
            $tab->name[(int) $language['id_lang']] = $module->l($child[1]);
        }
        if (!$tab->add()) {
            return false;
        }
    }

    return true;
}
