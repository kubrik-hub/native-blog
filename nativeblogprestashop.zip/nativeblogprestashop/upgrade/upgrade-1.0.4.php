<?php
/**
 * Native PrestaShop Blog 1.0.4 upgrade.
 *
 * The category save improvements require no schema changes.
 *
 * @author Kamel Kelkoul
 * @license https://opensource.org/licenses/OSL-3.0 Open Software License 3.0 (OSL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_4($module): bool
{
    return true;
}
