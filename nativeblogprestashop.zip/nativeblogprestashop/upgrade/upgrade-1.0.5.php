<?php
/**
 * Native PrestaShop Blog 1.0.5 upgrade.
 *
 * Adds optional article cover image storage without changing existing records.
 *
 * @author Kamel Kelkoul
 * @license https://opensource.org/licenses/OSL-3.0 Open Software License 3.0 (OSL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_5($module): bool
{
    $table = _DB_PREFIX_ . 'nativeblogprestashop_article';
    $column = Db::getInstance()->getValue(
        'SELECT COUNT(*)
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = "' . pSQL($table) . '"
        AND COLUMN_NAME = "cover_image"'
    );

    if ((int) $column > 0) {
        return true;
    }

    return Db::getInstance()->execute(
        'ALTER TABLE `' . bqSQL($table) . '` ADD `cover_image` VARCHAR(255) NULL AFTER `slug`'
    );
}
