<?php
/**
 * Native PrestaShop Blog 1.0.7 upgrade.
 *
 * Adds multilingual article authors and normalized multilingual tags without
 * changing existing article, shop, or comment data.
 *
 * @author Kamel Kelkoul
 * @license https://opensource.org/licenses/OSL-3.0 Open Software License 3.0 (OSL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_7($module): bool
{
    $db = Db::getInstance();
    $langTable = _DB_PREFIX_ . 'nativeblogprestashop_article_lang';
    $authorColumn = $db->getValue(
        'SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = "' . pSQL($langTable) . '"
        AND COLUMN_NAME = "author"'
    );
    if ($authorColumn === false || ((int) $authorColumn === 0 && !$db->execute(
        'ALTER TABLE `' . bqSQL($langTable) . '` ADD `author` VARCHAR(255) NULL AFTER `title`'
    ))) {
        return false;
    }

    $queries = [
        'CREATE TABLE IF NOT EXISTS `' . bqSQL(_DB_PREFIX_ . 'nativeblogprestashop_tag') . '` (
            `id_nativeblogprestashop_tag` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `slug` VARCHAR(255) NOT NULL,
            PRIMARY KEY (`id_nativeblogprestashop_tag`),
            UNIQUE KEY `nativeblogprestashop_tag_slug` (`slug`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
        'CREATE TABLE IF NOT EXISTS `' . bqSQL(_DB_PREFIX_ . 'nativeblogprestashop_tag_lang') . '` (
            `id_nativeblogprestashop_tag` INT UNSIGNED NOT NULL,
            `id_lang` INT UNSIGNED NOT NULL,
            `name` VARCHAR(255) NOT NULL,
            PRIMARY KEY (`id_nativeblogprestashop_tag`, `id_lang`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
        'CREATE TABLE IF NOT EXISTS `' . bqSQL(_DB_PREFIX_ . 'nativeblogprestashop_article_tag') . '` (
            `id_nativeblogprestashop_article` INT UNSIGNED NOT NULL,
            `id_nativeblogprestashop_tag` INT UNSIGNED NOT NULL,
            PRIMARY KEY (`id_nativeblogprestashop_article`, `id_nativeblogprestashop_tag`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
    ];

    foreach ($queries as $query) {
        if (!$db->execute($query)) {
            return false;
        }
    }

    return true;
}
