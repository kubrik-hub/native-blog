<?php
/**
 * Native PrestaShop Blog 1.0.6 upgrade.
 *
 * Adds moderated article comments and ratings without changing existing data.
 *
 * @author Kamel Kelkoul
 * @license https://opensource.org/licenses/OSL-3.0 Open Software License 3.0 (OSL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_0_6($module): bool
{
    $table = _DB_PREFIX_ . 'nativeblogprestashop_comment';

    return Db::getInstance()->execute(
        'CREATE TABLE IF NOT EXISTS `' . bqSQL($table) . '` (
            `id_nativeblogprestashop_comment` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `id_nativeblogprestashop_article` INT UNSIGNED NOT NULL,
            `id_shop` INT UNSIGNED NOT NULL,
            `id_customer` INT UNSIGNED NULL,
            `guest_hash` CHAR(64) NOT NULL,
            `author_name` VARCHAR(64) NOT NULL,
            `author_email` VARCHAR(255) NULL,
            `title` VARCHAR(64) NOT NULL,
            `content` TEXT NOT NULL,
            `grade` TINYINT UNSIGNED NOT NULL,
            `approved` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
            `date_add` DATETIME NOT NULL,
            PRIMARY KEY (`id_nativeblogprestashop_comment`),
            UNIQUE KEY `nativeblogprestashop_comment_duplicate` (`id_nativeblogprestashop_article`, `id_shop`, `guest_hash`),
            KEY `nativeblogprestashop_comment_article` (`id_nativeblogprestashop_article`, `id_shop`, `approved`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );
}
