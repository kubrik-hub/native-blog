# Documentation

## Phase 2 scope

The module creates dedicated article and category base tables with language
tables and shop association tables. Back Office tabs use legacy native
`ModuleAdminController` and `HelperForm` patterns; no Symfony controllers,
Composer packages, overrides, or external services are used.

Articles have SEO-friendly slugs, translated title/excerpt/content fields,
shop-scoped active state, optional categories, and optional publish dates.
The module front controller lists published articles and renders a published
article by its slug.

The module is enabled by default. The **Blog title** setting is rendered with
PrestaShop's `HelperForm`; all visible markup is kept in Smarty templates.

On installation, a top-level **Blog** tab is created with **Categories** and
**Articles** child tabs. Uninstall removes those tabs and all module tables.

## Updating to 1.0.8

Version 1.0.8 adds shop-scoped author records with multilingual first name,
last name, hobbies, and secure optional avatars. Articles can select an author;
the legacy multilingual author text remains as a fallback for existing data.
The migration is idempotent and preserves existing article/category/comment data.

## Updating to 1.0.7

Version 1.0.7 adds multilingual article authors and normalized multilingual
article tags. It also exposes publication/category metadata and approved
comment aggregates in the front office. The migration is idempotent and does
not remove existing article, cover, shop, or comment data.

## Updating to 1.0.6

The 1.0.6 change adds moderated article comments and ratings while preserving
all existing records. Upload the
new `nativeblogprestashop.zip` in the module manager and choose **Upgrade**.
PrestaShop updates the files and runs `upgrade/upgrade-1.0.6.php`, which
adds the comments table idempotently. Category forms now accept
HelperForm's multilingual field names, and an empty slug is generated safely
from the category name. The admin pages use explicit Smarty list templates, so
they show content and Add/Edit/Delete actions even when the legacy ObjectModel
list renderer has no module model class. Do not uninstall/reinstall. Direct
filesystem replacement is a fallback for controlled deployments, but the
module manager upgrade is the recommended path because it records the version
and runs the upgrade script.

For direct file deployments, opening the module configuration or Articles
Back Office page performs the same idempotent cover-image/comments schema
check. It is
not run on front-office requests; no existing records are changed.

## Security Notes

### WYSIWYG Content Security
Article content fields use the `nofilter` modifier in Smarty templates to allow
HTML content from the WYSIWYG editor. This is intentional and necessary for
rich text content to display properly. The module relies on PrestaShop's built-in
HTML purifier functions in the back office to sanitize content before storage,
ensuring that malicious scripts are removed while preserving legitimate HTML
formatting.

All other template variables are properly escaped using `|escape:'htmlall':'UTF-8'`
to prevent XSS attacks.
