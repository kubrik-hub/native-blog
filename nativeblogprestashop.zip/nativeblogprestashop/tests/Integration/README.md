# Integration tests

Place PrestaShop integration tests here when a test shop fixture is available.
