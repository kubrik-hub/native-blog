<?php
/**
 * Native PrestaShop Blog test bootstrap.
 *
 * @author Kamel Kelkoul
 * @license https://opensource.org/licenses/OSL-3.0 Open Software License 3.0 (OSL-3.0)
 */

declare(strict_types=1);

// PrestaShop integration bootstrap is supplied by the host test environment.
