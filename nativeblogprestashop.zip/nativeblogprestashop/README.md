# Native PrestaShop Blog

Phase 2 of a native PrestaShop 9.x blog module. The installable module
provides a configuration screen, dedicated article/category tables, multilingual
content, shop-scoped publishing, native Back Office CRUD controllers, and
minimal front-office listing/detail pages.

## Version 1.2.2

This version fixes several critical issues:
- Fixed module installation from zip file (added config.xml)
- Removed duplicate author field in article creation form
- Removed duplicate slug field in article creation form  
- Removed remove cover image field in article creation form
- Fixed pending comments display issue (orphaned comments)
- Fixed security token error in comment validation

## Version 1.2.1

This is a maintenance release that addresses minor compliance issues:
- Replaced $this->trans() with $this->l() for consistency
- Translated all French comments to English in templates
- Added security documentation for WYSIWYG content handling
- Cleaned up test images from upload directory

## Requirements

- PrestaShop 9.x (`9.0.0` through `9.99.99`)
- PHP 8.1 or newer
- No Composer or external dependencies

## Installation

Copy this directory to the shop's `modules` directory as
`nativeblogprestashop`, then install **Native PrestaShop Blog** from the
Back Office module manager. Configure it from the module configuration page.

Uninstalling removes the module configuration and its dedicated database table.
It also removes all Phase 2 article and category tables. Do not uninstall to
apply updates: upload the newer ZIP in the module manager and choose
**Upgrade**, which runs the non-destructive `upgrade/upgrade-1.1.0.php` script.

## License

Copyright Kamel Kelkoul. Licensed under OSL-3.0. See `LICENSE`.
