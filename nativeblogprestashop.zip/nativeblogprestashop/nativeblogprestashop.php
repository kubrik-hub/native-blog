<?php
/**
 * Native PrestaShop Blog
 *
 * @author Kamel Kelkoul
 * @license https://opensource.org/licenses/OSL-3.0 Open Software License 3.0 (OSL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class NativeBlogPrestaShop extends Module
{
    private const TABLE_POST = 'nativeblogprestashop_post';
    private const TABLE_CATEGORY = 'nativeblogprestashop_category';
    private const TABLE_CATEGORY_LANG = 'nativeblogprestashop_category_lang';
    private const TABLE_CATEGORY_SHOP = 'nativeblogprestashop_category_shop';
    private const TABLE_ARTICLE = 'nativeblogprestashop_article';
    private const TABLE_ARTICLE_LANG = 'nativeblogprestashop_article_lang';
    private const TABLE_ARTICLE_SHOP = 'nativeblogprestashop_article_shop';
    private const TABLE_TAG = 'nativeblogprestashop_tag';
    private const TABLE_TAG_LANG = 'nativeblogprestashop_tag_lang';
    private const TABLE_ARTICLE_TAG = 'nativeblogprestashop_article_tag';
    private const TABLE_AUTHOR = 'nativeblogprestashop_author';
    private const TABLE_AUTHOR_LANG = 'nativeblogprestashop_author_lang';
    private const TABLE_AUTHOR_SHOP = 'nativeblogprestashop_author_shop';
    private const CONFIG_ENABLED = 'NBPS_ENABLED';
    private const CONFIG_TITLE = 'NBPS_TITLE';
    private const CONFIG_HOME_LIMIT = 'NBPS_HOME_LIMIT';
    private const CONFIG_HOME_CATEGORY = 'NBPS_HOME_CATEGORY';
    private const CONFIG_HOME_ARTICLES = 'NBPS_HOME_ARTICLES';
    private const CONFIG_COMMENTS_ENABLED = 'NBPS_COMMENTS_ENABLED';

    public function __construct()
    {
        $this->name = 'nativeblogprestashop';
        $this->tab = 'front_office_features';
        $this->version = '1.2.2';
        $this->author = 'Kamel Kelkoul';
        $this->need_instance = 0;
        $this->bootstrap = true;
        $this->ps_versions_compliancy = [
            'min' => '9.0.0',
            'max' => '9.99.99',
        ];

        parent::__construct();

        $this->displayName = $this->l('Native PrestaShop Blog');
        $this->description = $this->l('A simple blog for PrestaShop.');
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall this module?');
    }

    public function install(): bool
    {
        return parent::install()
            && $this->registerHook('displayHome')
            && $this->registerHook('moduleRoutes')
            && $this->registerHook('actionAdminControllerSetMedia')
            && $this->installTabs()
            && $this->installDatabase()
            && Configuration::updateValue(self::CONFIG_ENABLED, true)
            && Configuration::updateValue(self::CONFIG_TITLE, $this->l('Blog'))
            && Configuration::updateValue(self::CONFIG_HOME_LIMIT, 6)
            && Configuration::updateValue(self::CONFIG_HOME_CATEGORY, 0)
            && Configuration::updateValue(self::CONFIG_HOME_ARTICLES, '')
            && Configuration::updateValue(self::CONFIG_COMMENTS_ENABLED, false);
    }

    public function uninstall(): bool
    {
        return Configuration::deleteByName(self::CONFIG_ENABLED)
            && Configuration::deleteByName(self::CONFIG_TITLE)
            && Configuration::deleteByName(self::CONFIG_HOME_LIMIT)
            && Configuration::deleteByName(self::CONFIG_HOME_CATEGORY)
            && Configuration::deleteByName(self::CONFIG_HOME_ARTICLES)
            && Configuration::deleteByName(self::CONFIG_COMMENTS_ENABLED)
            && $this->removeManagedMainMenuLinks()
            && $this->uninstallDatabase()
            && $this->uninstallTabs()
            && parent::uninstall();
    }

    public function getContent(): string
    {
        $output = '';

        if (!$this->isRegisteredInHook('moduleRoutes') && !$this->registerHook('moduleRoutes')) {
            $output .= $this->displayError($this->l('The blog SEO routes could not be registered.'));
        }
        if (!$this->isRegisteredInHook('actionAdminControllerSetMedia') && !$this->registerHook('actionAdminControllerSetMedia')) {
            $output .= $this->displayError($this->l('The blog menu choices could not be synchronized.'));
        }
        if (Module::isInstalled('ps_mainmenu') && Hook::getIdByName('actionMainMenuModifier')
            && !$this->isRegisteredInHook('actionMainMenuModifier')
            && !$this->registerHook('actionMainMenuModifier')) {
            $output .= $this->displayError($this->l('The blog category submenus could not be enabled.'));
        }

        if (!$this->ensureDatabaseSchema()) {
            $error = Db::getInstance()->getMsgError();
            $message = $this->l('The blog database schema could not be updated.');
            if ($error !== '') {
                $message .= ' ' . $error;
            }
            $output .= $this->displayError($message);
        }

        if (!$this->syncMainMenuLinks()) {
            $output .= $this->displayError($this->l('The blog links could not be added to the main menu choices.'));
        }

        if (Tools::isSubmit('submitNativeBlogPrestaShop')) {
            $idShop = (int) $this->context->shop->id;
            $enabled = (bool) Tools::getValue(self::CONFIG_ENABLED);
            $titles = $this->getMultilingualInputValue(self::CONFIG_TITLE);
            $hasTitle = false;
            foreach ($titles as $titleValue) {
                if (trim((string) $titleValue) !== '') {
                    $hasTitle = true;
                    break;
                }
            }
            $homeLimit = max(1, min(50, (int) Tools::getValue(self::CONFIG_HOME_LIMIT)));
            $homeCategory = max(0, (int) Tools::getValue(self::CONFIG_HOME_CATEGORY));
            $homeArticles = $this->normalizeArticleIds(Tools::getValue(self::CONFIG_HOME_ARTICLES, []));
            $commentsEnabled = (bool) Tools::getValue(self::CONFIG_COMMENTS_ENABLED);

            if (!$hasTitle) {
                $output .= $this->displayError($this->l('The blog title cannot be empty.'));
            } else {
                $saved = Configuration::updateValue(self::CONFIG_ENABLED, $enabled, false, null, $idShop)
                    && Configuration::updateValue(self::CONFIG_TITLE, $titles, false, null, $idShop)
                    && Configuration::updateValue(self::CONFIG_HOME_LIMIT, $homeLimit, false, null, $idShop)
                    && Configuration::updateValue(self::CONFIG_HOME_CATEGORY, $homeCategory, false, null, $idShop)
                    && Configuration::updateValue(self::CONFIG_HOME_ARTICLES, implode(',', $homeArticles), false, null, $idShop)
                    && Configuration::updateValue(self::CONFIG_COMMENTS_ENABLED, $commentsEnabled, false, null, $idShop);
                $output .= $saved
                    ? $this->displayConfirmation($this->l('Settings updated.'))
                    : $this->displayError($this->l('The settings could not be saved.'));
            }

        }
        if (!$this->syncAdminTabs()) {
            $output .= $this->displayError($this->l('The blog administration menu could not be updated.'));
        }
        return $output . $this->renderForm();
    }

    public function hookModuleRoutes(): array
    {
        return [
            'module-nativeblogprestashop-home' => [
                'rule' => 'blog',
                'keywords' => [],
                'controller' => 'home',
                'params' => [
                    'fc' => 'module',
                    'module' => $this->name,
                ],
            ],
            'module-nativeblogprestashop-category' => [
                'rule' => 'blog/categorie/{category_path}',
                'keywords' => [
                    'category_path' => [
                        'regexp' => '[a-zA-Z0-9-]+(?:/[a-zA-Z0-9-]+)*',
                        'param' => 'category_path',
                    ],
                ],
                'controller' => 'home',
                'params' => [
                    'fc' => 'module',
                    'module' => $this->name,
                ],
            ],
            'module-nativeblogprestashop-article' => [
                'rule' => 'blog/{slug}',
                'keywords' => [
                    'slug' => [
                        'regexp' => '[a-zA-Z0-9-]+',
                        'param' => 'slug',
                    ],
                ],
                'controller' => 'article',
                'params' => [
                    'fc' => 'module',
                    'module' => $this->name,
                ],
            ],
            'module-nativeblogprestashop-author' => [
                'rule' => 'blog/author/{slug}',
                'keywords' => [
                    'slug' => [
                        'regexp' => '[a-zA-Z0-9-]+',
                        'param' => 'slug',
                    ],
                ],
                'controller' => 'author',
                'params' => [
                    'fc' => 'module',
                    'module' => $this->name,
                ],
            ],
        ];
    }

    public function getCategoryLink(int $categoryId, ?int $idLang = null, ?int $idShop = null): string
    {
        $idLang = $idLang ?: (int) $this->context->language->id;
        $idShop = $idShop ?: (int) $this->context->shop->id;
        $pathSegments = [];
        $visited = [];
        $currentId = $categoryId;

        while ($currentId > 0 && !isset($visited[$currentId])) {
            $visited[$currentId] = true;
            $category = Db::getInstance()->getRow(
                'SELECT c.id_parent, c.slug
                FROM `' . _DB_PREFIX_ . self::TABLE_CATEGORY . '` c
                INNER JOIN `' . _DB_PREFIX_ . self::TABLE_CATEGORY_SHOP . '` cs
                    ON cs.id_nativeblogprestashop_category = c.id_nativeblogprestashop_category
                    AND cs.id_shop = ' . $idShop . ' AND cs.active = 1
                WHERE c.id_nativeblogprestashop_category = ' . (int) $currentId
            );
            if (!$category || !preg_match('/^[a-zA-Z0-9-]+$/', (string) $category['slug'])) {
                return $this->context->link->getModuleLink($this->name, 'home', ['category' => $categoryId], null, $idLang, $idShop);
            }
            array_unshift($pathSegments, (string) $category['slug']);
            $currentId = (int) $category['id_parent'];
        }

        if ($currentId > 0 || !$pathSegments) {
            return $this->context->link->getModuleLink($this->name, 'home', ['category' => $categoryId], null, $idLang, $idShop);
        }

        return $this->context->link->getPageLink(
            'module-' . $this->name . '-category',
            null,
            $idLang,
            ['category_path' => implode('/', $pathSegments)],
            false,
            $idShop
        );
    }

    public function getCategoryIdFromPath(string $categoryPath, ?int $idShop = null): int
    {
        $idShop = $idShop ?: (int) $this->context->shop->id;
        $segments = explode('/', trim($categoryPath, '/'));
        if (!$segments || count($segments) > 100) {
            return 0;
        }
        foreach ($segments as $segment) {
            if (!preg_match('/^[a-zA-Z0-9-]+$/', $segment)) {
                return 0;
            }
        }

        $categoryId = (int) Db::getInstance()->getValue(
            'SELECT c.id_nativeblogprestashop_category
            FROM `' . _DB_PREFIX_ . self::TABLE_CATEGORY . '` c
            INNER JOIN `' . _DB_PREFIX_ . self::TABLE_CATEGORY_SHOP . '` cs
                ON cs.id_nativeblogprestashop_category = c.id_nativeblogprestashop_category
                AND cs.id_shop = ' . $idShop . ' AND cs.active = 1
            WHERE c.slug = "' . pSQL(end($segments)) . '"'
        );
        if ($categoryId <= 0) {
            return 0;
        }

        $targetCategoryId = $categoryId;
        $visited = [];
        for ($index = count($segments) - 1; $index >= 0; --$index) {
            if ($categoryId <= 0 || isset($visited[$categoryId])) {
                return 0;
            }
            $visited[$categoryId] = true;
            $category = Db::getInstance()->getRow(
                'SELECT c.id_parent, c.slug
                FROM `' . _DB_PREFIX_ . self::TABLE_CATEGORY . '` c
                INNER JOIN `' . _DB_PREFIX_ . self::TABLE_CATEGORY_SHOP . '` cs
                    ON cs.id_nativeblogprestashop_category = c.id_nativeblogprestashop_category
                    AND cs.id_shop = ' . $idShop . ' AND cs.active = 1
                WHERE c.id_nativeblogprestashop_category = ' . $categoryId
            );
            if (!$category || (string) $category['slug'] !== $segments[$index]) {
                return 0;
            }
            $categoryId = (int) $category['id_parent'];
        }

        return $categoryId === 0 ? $targetCategoryId : 0;
    }

    public function ensureDatabaseSchema(): bool
    {
        $table = _DB_PREFIX_ . self::TABLE_ARTICLE;
        $column = Db::getInstance()->getValue(
            'SELECT COUNT(*)
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME = "' . pSQL($table) . '"
            AND COLUMN_NAME = "cover_image"'
        );
        if ($column === false) {
            return false;
        }
        if ((int) $column === 0 && !Db::getInstance()->execute(
            'ALTER TABLE `' . bqSQL($table) . '` ADD `cover_image` VARCHAR(255) NULL AFTER `slug`'
        )) {
            return false;
        }

        $authorColumn = Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = "' . pSQL(_DB_PREFIX_ . self::TABLE_ARTICLE_LANG) . '"
            AND COLUMN_NAME = "author"'
        );
        if ($authorColumn === false) {
            return false;
        }
        if ((int) $authorColumn === 0 && !Db::getInstance()->execute(
            'ALTER TABLE `' . bqSQL(_DB_PREFIX_ . self::TABLE_ARTICLE_LANG) . '` ADD `author` VARCHAR(255) NULL AFTER `title`'
        )) {
            return false;
        }

        $articleTable = _DB_PREFIX_ . self::TABLE_ARTICLE;
        $authorIdColumn = Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = "' . pSQL($articleTable) . '"
            AND COLUMN_NAME = "id_nativeblogprestashop_author"'
        );
        if ($authorIdColumn === false || ((int) $authorIdColumn === 0 && !Db::getInstance()->execute(
            'ALTER TABLE `' . bqSQL($articleTable) . '` ADD `id_nativeblogprestashop_author` INT UNSIGNED NULL AFTER `id_nativeblogprestashop_category`'
        ))) {
            return false;
        }

        $categoryTable = _DB_PREFIX_ . self::TABLE_CATEGORY;
        $parentIdColumn = Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = "' . pSQL($categoryTable) . '"
            AND COLUMN_NAME = "id_parent"'
        );
        if ($parentIdColumn === false || ((int) $parentIdColumn === 0 && !Db::getInstance()->execute(
            'ALTER TABLE `' . bqSQL($categoryTable) . '` ADD `id_parent` INT UNSIGNED NOT NULL DEFAULT 0 AFTER `id_nativeblogprestashop_category`'
        ))) {
            return false;
        }

        foreach ([
            'CREATE TABLE IF NOT EXISTS `' . bqSQL(_DB_PREFIX_ . self::TABLE_AUTHOR) . '` (
                `id_nativeblogprestashop_author` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `slug` VARCHAR(255) NULL,
                `avatar` VARCHAR(255) NULL,
                `date_add` DATETIME NOT NULL,
                `date_upd` DATETIME NOT NULL,
                PRIMARY KEY (`id_nativeblogprestashop_author`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
            'CREATE TABLE IF NOT EXISTS `' . bqSQL(_DB_PREFIX_ . self::TABLE_AUTHOR_LANG) . '` (
                `id_nativeblogprestashop_author` INT UNSIGNED NOT NULL,
                `id_lang` INT UNSIGNED NOT NULL,
                `firstname` VARCHAR(128) NOT NULL,
                `lastname` VARCHAR(128) NOT NULL,
                `hobbies` TEXT NULL,
                PRIMARY KEY (`id_nativeblogprestashop_author`, `id_lang`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
            'CREATE TABLE IF NOT EXISTS `' . bqSQL(_DB_PREFIX_ . self::TABLE_AUTHOR_SHOP) . '` (
                `id_nativeblogprestashop_author` INT UNSIGNED NOT NULL,
                `id_shop` INT UNSIGNED NOT NULL,
                `active` TINYINT(1) UNSIGNED NOT NULL DEFAULT 1,
                PRIMARY KEY (`id_nativeblogprestashop_author`, `id_shop`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
            'CREATE TABLE IF NOT EXISTS `' . bqSQL(_DB_PREFIX_ . self::TABLE_TAG) . '` (
                `id_nativeblogprestashop_tag` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `slug` VARCHAR(255) NOT NULL,
                PRIMARY KEY (`id_nativeblogprestashop_tag`),
                UNIQUE KEY `nativeblogprestashop_tag_slug` (`slug`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
            'CREATE TABLE IF NOT EXISTS `' . bqSQL(_DB_PREFIX_ . self::TABLE_TAG_LANG) . '` (
                `id_nativeblogprestashop_tag` INT UNSIGNED NOT NULL,
                `id_lang` INT UNSIGNED NOT NULL,
                `name` VARCHAR(255) NOT NULL,
                PRIMARY KEY (`id_nativeblogprestashop_tag`, `id_lang`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
            'CREATE TABLE IF NOT EXISTS `' . bqSQL(_DB_PREFIX_ . self::TABLE_ARTICLE_TAG) . '` (
                `id_nativeblogprestashop_article` INT UNSIGNED NOT NULL,
                `id_nativeblogprestashop_tag` INT UNSIGNED NOT NULL,
                PRIMARY KEY (`id_nativeblogprestashop_article`, `id_nativeblogprestashop_tag`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
        ] as $tagQuery) {
            if (!Db::getInstance()->execute($tagQuery)) {
                return false;
            }
        }

        if (!$this->ensureAuthorSlugColumn()) {
            return false;
        }

        $commentTable = _DB_PREFIX_ . 'nativeblogprestashop_comment';
        return Db::getInstance()->execute(
            'CREATE TABLE IF NOT EXISTS `' . bqSQL($commentTable) . '` (
                `id_nativeblogprestashop_comment` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `id_nativeblogprestashop_article` INT UNSIGNED NOT NULL,
                `id_shop` INT UNSIGNED NOT NULL,
                `id_customer` INT UNSIGNED NULL,
                `guest_hash` CHAR(64) NOT NULL,
                `author_name` VARCHAR(64) NOT NULL,
                `author_email` VARCHAR(255) NULL,
                `title` VARCHAR(64) NOT NULL,
                `content` TEXT NOT NULL,
                `grade` TINYINT UNSIGNED NOT NULL,
                `approved` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
                `date_add` DATETIME NOT NULL,
                PRIMARY KEY (`id_nativeblogprestashop_comment`),
                UNIQUE KEY `nativeblogprestashop_comment_duplicate` (`id_nativeblogprestashop_article`, `id_shop`, `guest_hash`),
                KEY `nativeblogprestashop_comment_article` (`id_nativeblogprestashop_article`, `id_shop`, `approved`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
        );
    }

    /**
     * Adds the `slug` column to the author table for installs created before
     * it existed, then backfills a unique slug for every author missing one.
     */
    private function ensureAuthorSlugColumn(): bool
    {
        $authorTable = _DB_PREFIX_ . self::TABLE_AUTHOR;
        $slugColumn = Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = "' . pSQL($authorTable) . '"
            AND COLUMN_NAME = "slug"'
        );
        if ($slugColumn === false) {
            return false;
        }
        if ((int) $slugColumn === 0 && !Db::getInstance()->execute(
            'ALTER TABLE `' . bqSQL($authorTable) . '` ADD `slug` VARCHAR(255) NULL AFTER `id_nativeblogprestashop_author`'
        )) {
            return false;
        }

        $authorsMissingSlug = Db::getInstance()->executeS(
            'SELECT id_nativeblogprestashop_author FROM `' . bqSQL($authorTable) . '`
            WHERE slug IS NULL OR slug = ""'
        );
        if (!$authorsMissingSlug) {
            return true;
        }

        $defaultLanguageId = (int) Configuration::get('PS_LANG_DEFAULT');
        foreach ($authorsMissingSlug as $author) {
            $authorId = (int) $author['id_nativeblogprestashop_author'];
            $name = (string) Db::getInstance()->getValue(
                'SELECT CONCAT_WS(" ", firstname, lastname) FROM `' . bqSQL(_DB_PREFIX_ . self::TABLE_AUTHOR_LANG) . '`
                WHERE id_nativeblogprestashop_author = ' . $authorId . '
                ORDER BY (id_lang = ' . $defaultLanguageId . ') DESC LIMIT 1'
            );
            $baseSlug = Tools::str2url($name) ?: 'author-' . $authorId;
            $slug = $baseSlug;
            $suffix = 2;
            while ((int) Db::getInstance()->getValue(
                'SELECT id_nativeblogprestashop_author FROM `' . bqSQL($authorTable) . '`
                WHERE slug = \'' . pSQL($slug) . '\' AND id_nativeblogprestashop_author != ' . $authorId
            ) > 0) {
                $slug = $baseSlug . '-' . $suffix++;
            }
            if (!Db::getInstance()->execute(
                'UPDATE `' . bqSQL($authorTable) . '` SET slug = \'' . pSQL($slug) . '\'
                WHERE id_nativeblogprestashop_author = ' . $authorId
            )) {
                return false;
            }
        }

        return true;
    }

    public function hookActionAdminControllerSetMedia(array $params): void
    {
        $configuredModule = (string) Tools::getValue('configure');
        if ($configuredModule === 'ps_mainmenu' || (string) Tools::getValue('module_name') === 'ps_mainmenu') {
            if (Hook::getIdByName('actionMainMenuModifier') && !$this->isRegisteredInHook('actionMainMenuModifier')) {
                $this->registerHook('actionMainMenuModifier');
            }
            $this->syncMainMenuLinks();
        }
    }

    /**
     * Adds descendants of selected blog categories as nested menu entries.
     * ps_mainmenu exposes this hook after loading its configured menu items.
     */
    public function hookActionMainMenuModifier(array &$params): void
    {
        if (empty($params['menu']['children']) || !is_array($params['menu']['children'])) {
            return;
        }

        if (!$this->ensureDatabaseSchema()) {
            return;
        }

        $shopId = (int) $this->context->shop->id;
        $langId = (int) $this->context->language->id;
        $categories = Db::getInstance()->executeS(
            'SELECT c.id_nativeblogprestashop_category, c.id_parent, cl.name
            FROM `' . _DB_PREFIX_ . self::TABLE_CATEGORY . '` c
            INNER JOIN `' . _DB_PREFIX_ . self::TABLE_CATEGORY_SHOP . '` cs
                ON cs.id_nativeblogprestashop_category = c.id_nativeblogprestashop_category
                AND cs.id_shop = ' . $shopId . ' AND cs.active = 1
            LEFT JOIN `' . _DB_PREFIX_ . self::TABLE_CATEGORY_LANG . '` cl
                ON cl.id_nativeblogprestashop_category = c.id_nativeblogprestashop_category
                AND cl.id_lang = ' . $langId
        ) ?: [];
        $categoriesById = [];
        foreach ($categories as $category) {
            $categoriesById[(int) $category['id_nativeblogprestashop_category']] = [
                'id_parent' => (int) $category['id_parent'],
                'name' => (string) $category['name'],
            ];
        }
        if (!$categoriesById) {
            return;
        }

        $homeUrl = $this->context->link->getModuleLink($this->name, 'home');
        $isBlogLink = false;
        $selectedCategoryIds = [];
        foreach ($params['menu']['children'] as $node) {
            $url = (string) ($node['url'] ?? '');
            $query = [];
            parse_str((string) parse_url($url, PHP_URL_QUERY), $query);
            $categoryId = (int) ($query['category'] ?? 0);
            if ($categoryId > 0 && isset($categoriesById[$categoryId])) {
                $selectedCategoryIds[$categoryId] = true;
            } elseif ($categoryId === 0 && rtrim($url, '/') === rtrim($homeUrl, '/')) {
                $isBlogLink = true;
            }
        }
        if (!$isBlogLink && !$selectedCategoryIds) {
            return;
        }

        $childrenByParent = [];
        foreach ($categoriesById as $categoryId => $category) {
            $parentId = $category['id_parent'];
            if ($parentId === $categoryId || !isset($categoriesById[$parentId])) {
                $parentId = 0;
            }
            $childrenByParent[$parentId][] = $categoryId;
        }
        $makeCategoryNodes = function ($parentId, $depth, array $ancestors = []) use (&$makeCategoryNodes, $childrenByParent, $categoriesById, $shopId, $langId) {
            $nodes = [];
            foreach ($childrenByParent[$parentId] ?? [] as $categoryId) {
                if (isset($ancestors[$categoryId])) {
                    continue;
                }
                $category = $categoriesById[$categoryId];
                $nextAncestors = $ancestors;
                $nextAncestors[$categoryId] = true;
                $nodes[] = [
                    'type' => 'link',
                    'page_identifier' => 'nativeblog-category-' . $categoryId,
                    'label' => Tools::safeOutput($category['name']),
                    'url' => $this->getCategoryLink($categoryId, $langId, $shopId),
                    'children' => $makeCategoryNodes($categoryId, $depth + 1, $nextAncestors),
                    'open_in_new_window' => false,
                    'image_urls' => [],
                    'depth' => $depth,
                    'current' => false,
                ];
            }
            return $nodes;
        };

        $menuChildren = [];
        $insertedBlogTree = false;
        foreach ($params['menu']['children'] as $node) {
            $url = (string) ($node['url'] ?? '');
            $query = [];
            parse_str((string) parse_url($url, PHP_URL_QUERY), $query);
            $categoryId = (int) ($query['category'] ?? 0);
            $isManagedCategory = $categoryId > 0 && isset($categoriesById[$categoryId]);
            $isBlogNode = !$categoryId && rtrim($url, '/') === rtrim($homeUrl, '/');

            if ($isBlogLink && ($isBlogNode || $isManagedCategory)) {
                if (!$insertedBlogTree) {
                    $node['label'] = 'Blog';
                    $node['children'] = $makeCategoryNodes(0, (int) ($node['depth'] ?? 1) + 1);
                    $menuChildren[] = $node;
                    $insertedBlogTree = true;
                }
                continue;
            }

            if ($isManagedCategory) {
                if (isset($selectedCategoryIds[$categoryId])) {
                    $hasSelectedAncestor = false;
                    $parentId = $categoriesById[$categoryId]['id_parent'];
                    $visited = [];
                    while ($parentId > 0 && isset($categoriesById[$parentId]) && !isset($visited[$parentId])) {
                        if (isset($selectedCategoryIds[$parentId])) {
                            $hasSelectedAncestor = true;
                            break;
                        }
                        $visited[$parentId] = true;
                        $parentId = $categoriesById[$parentId]['id_parent'];
                    }
                    if (!$hasSelectedAncestor) {
                        $node['label'] = Tools::safeOutput($categoriesById[$categoryId]['name']);
                        $node['url'] = $this->getCategoryLink($categoryId, $langId, $shopId);
                        $node['children'] = $makeCategoryNodes($categoryId, (int) ($node['depth'] ?? 1) + 1, [$categoryId => true]);
                        $menuChildren[] = $node;
                    }
                }
                continue;
            }

            $menuChildren[] = $node;
        }

        $params['menu']['children'] = $menuChildren;
    }

    public function syncMainMenuLinks(): bool
    {
        // Upgrade existing installations before querying the category hierarchy.
        if (!$this->ensureDatabaseSchema()) {
            return false;
        }

        if (!Module::isInstalled('ps_mainmenu')) {
            return true;
        }

        $shopId = (int) $this->context->shop->id;
        $linkTable = _DB_PREFIX_ . 'linksmenutop';
        $linkLangTable = _DB_PREFIX_ . 'linksmenutop_lang';
        $mappingTable = _DB_PREFIX_ . 'nativeblogprestashop_menu_link';
        $tablesExist = (int) Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME IN ("' . pSQL($linkTable) . '", "' . pSQL($linkLangTable) . '")'
        );
        if ($tablesExist < 2) {
            return true;
        }

        if (!Db::getInstance()->execute(
            'CREATE TABLE IF NOT EXISTS `' . bqSQL($mappingTable) . '` (
                `id_shop` INT UNSIGNED NOT NULL,
                `id_category` INT UNSIGNED NOT NULL DEFAULT 0,
                `id_linksmenutop` INT UNSIGNED NOT NULL,
                PRIMARY KEY (`id_shop`, `id_category`),
                UNIQUE KEY `nativeblogprestashop_menu_link_id` (`id_linksmenutop`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
        )) {
            return false;
        }

        $items = [0 => ['depth' => 0]];
        $categories = Db::getInstance()->executeS(
            'SELECT c.id_nativeblogprestashop_category, c.id_parent
            FROM `' . _DB_PREFIX_ . self::TABLE_CATEGORY . '` c
            INNER JOIN `' . _DB_PREFIX_ . self::TABLE_CATEGORY_SHOP . '` cs
                ON cs.id_nativeblogprestashop_category = c.id_nativeblogprestashop_category
                AND cs.id_shop = ' . $shopId . '
                AND cs.active = 1
            ORDER BY c.id_nativeblogprestashop_category ASC'
        ) ?: [];
        $parentIds = [];
        foreach ($categories as $category) {
            $parentIds[(int) $category['id_nativeblogprestashop_category']] = (int) $category['id_parent'];
        }
        foreach ($categories as $category) {
            $categoryId = (int) $category['id_nativeblogprestashop_category'];
            $depth = 0;
            $parentId = $parentIds[$categoryId] ?? 0;
            $visited = [$categoryId => true];
            while ($parentId > 0 && isset($parentIds[$parentId]) && !isset($visited[$parentId])) {
                $visited[$parentId] = true;
                ++$depth;
                $parentId = $parentIds[$parentId];
            }
            // Blog is the root item, so every category starts one level below it.
            $items[$categoryId] = ['depth' => $depth + 1];
        }

        $languages = Language::getLanguages(false);
        $defaultLanguageId = (int) Configuration::get('PS_LANG_DEFAULT');
        $existingRows = Db::getInstance()->executeS(
            'SELECT id_category, id_linksmenutop FROM `' . bqSQL($mappingTable) . '` WHERE id_shop = ' . $shopId
        ) ?: [];
        $existing = [];
        foreach ($existingRows as $row) {
            $existing[(int) $row['id_category']] = (int) $row['id_linksmenutop'];
        }

        foreach ($items as $categoryId => $item) {
            $labels = [];
            $links = [];
            foreach ($languages as $language) {
                $languageId = (int) $language['id_lang'];
                if ($categoryId === 0) {
                    $labels[$languageId] = 'Blog';
                } else {
                    $name = (string) Db::getInstance()->getValue(
                        'SELECT name FROM `' . _DB_PREFIX_ . self::TABLE_CATEGORY_LANG . '`
                        WHERE id_nativeblogprestashop_category = ' . (int) $categoryId . '
                        AND id_lang = ' . $languageId
                    );
                    if ($name === '' && $languageId !== $defaultLanguageId) {
                        $name = (string) Db::getInstance()->getValue(
                            'SELECT name FROM `' . _DB_PREFIX_ . self::TABLE_CATEGORY_LANG . '`
                            WHERE id_nativeblogprestashop_category = ' . (int) $categoryId . '
                            AND id_lang = ' . $defaultLanguageId
                        );
                    }
                    $indent = str_repeat("\xC2\xA0\xC2\xA0", (int) $item['depth']);
                    $labels[$languageId] = $indent . ($name !== '' ? $name : 'Category ' . (int) $categoryId);
                }

                $params = $categoryId > 0 ? ['category' => (int) $categoryId] : [];
                $links[$languageId] = $this->context->link->getModuleLink(
                    $this->name,
                    'home',
                    $params,
                    null,
                    $languageId,
                    $shopId
                );
            }

            $linkId = $existing[$categoryId] ?? 0;
            $linkExists = $linkId > 0 && (int) Db::getInstance()->getValue(
                'SELECT COUNT(*) FROM `' . bqSQL($linkTable) . '`
                WHERE id_linksmenutop = ' . $linkId . ' AND id_shop = ' . $shopId
            ) > 0;

            if (!$linkExists) {
                if (!Db::getInstance()->insert('linksmenutop', ['new_window' => 0, 'id_shop' => $shopId])) {
                    return false;
                }
                $linkId = (int) Db::getInstance()->Insert_ID();
                if (!Db::getInstance()->insert('nativeblogprestashop_menu_link', [
                    'id_shop' => $shopId,
                    'id_category' => (int) $categoryId,
                    'id_linksmenutop' => $linkId,
                ])) {
                    Db::getInstance()->delete('linksmenutop', 'id_linksmenutop = ' . $linkId . ' AND id_shop = ' . $shopId);
                    return false;
                }
            }

            foreach ($languages as $language) {
                $languageId = (int) $language['id_lang'];
                $where = 'id_linksmenutop = ' . $linkId . ' AND id_lang = ' . $languageId . ' AND id_shop = ' . $shopId;
                $langRowExists = (int) Db::getInstance()->getValue(
                    'SELECT COUNT(*) FROM `' . bqSQL($linkLangTable) . '` WHERE ' . $where
                ) > 0;
                $values = [
                    'label' => pSQL($labels[$languageId]),
                    'link' => pSQL($links[$languageId]),
                ];
                $saved = $langRowExists
                    ? Db::getInstance()->update('linksmenutop_lang', $values, $where)
                    : Db::getInstance()->insert('linksmenutop_lang', $values + [
                        'id_linksmenutop' => $linkId,
                        'id_lang' => $languageId,
                        'id_shop' => $shopId,
                    ]);
                if (!$saved) {
                    return false;
                }
            }
        }

        foreach ($existing as $categoryId => $linkId) {
            if (array_key_exists($categoryId, $items)) {
                continue;
            }
            Db::getInstance()->delete('linksmenutop_lang', 'id_linksmenutop = ' . (int) $linkId);
            Db::getInstance()->delete('linksmenutop', 'id_linksmenutop = ' . (int) $linkId . ' AND id_shop = ' . $shopId);
            Db::getInstance()->delete('nativeblogprestashop_menu_link', 'id_shop = ' . $shopId . ' AND id_category = ' . (int) $categoryId);
        }

        $this->clearMainMenuCache();

        return true;
    }

    private function removeManagedMainMenuLinks(): bool
    {
        $mappingTable = _DB_PREFIX_ . 'nativeblogprestashop_menu_link';
        $exists = (int) Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = "' . pSQL($mappingTable) . '"'
        );
        if (!$exists) {
            return true;
        }

        foreach (Db::getInstance()->executeS(
            'SELECT id_shop, id_linksmenutop FROM `' . bqSQL($mappingTable) . '`'
        ) ?: [] as $row) {
            $shopId = (int) $row['id_shop'];
            $linkId = (int) $row['id_linksmenutop'];
            $shopGroupId = (int) Shop::getGroupFromShop($shopId);
            $items = explode(',', (string) Configuration::get(
                'MOD_BLOCKTOPMENU_ITEMS',
                null,
                $shopGroupId,
                $shopId
            ));
            $items = array_values(array_filter($items, static function ($item) use ($linkId) {
                return $item !== 'LNK' . $linkId && $item !== '';
            }));
            Configuration::updateValue(
                'MOD_BLOCKTOPMENU_ITEMS',
                implode(',', $items),
                false,
                $shopGroupId,
                $shopId
            );

            $linksExist = (int) Db::getInstance()->getValue(
                'SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME IN ("' . pSQL(_DB_PREFIX_ . 'linksmenutop') . '", "' . pSQL(_DB_PREFIX_ . 'linksmenutop_lang') . '")'
            );
            if ($linksExist === 2) {
                Db::getInstance()->delete('linksmenutop_lang', 'id_linksmenutop = ' . $linkId);
                Db::getInstance()->delete('linksmenutop', 'id_linksmenutop = ' . $linkId . ' AND id_shop = ' . $shopId);
            }
        }

        $this->clearMainMenuCache();

        return true;
    }

    private function clearMainMenuCache(): void
    {
        $cacheDirectory = _PS_CACHE_DIR_ . 'ps_mainmenu';
        if (!is_dir($cacheDirectory)) {
            return;
        }

        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($cacheDirectory, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($iterator as $file) {
            if ($file->isFile() && strtolower($file->getExtension()) === 'json') {
                @unlink($file->getPathname());
            }
        }
    }

    public function hookDisplayHome(array $params): string
    {
        $idShop = (int) $this->context->shop->id;
        if (!Configuration::get(self::CONFIG_ENABLED, null, null, $idShop)) {
            return '';
        }

        $idLang = (int) $this->context->language->id;
        $defaultLanguageId = (int) Configuration::get('PS_LANG_DEFAULT');
        $blogTitle = '';
        foreach ([
            Configuration::get(self::CONFIG_TITLE, $idLang, null, $idShop),
            Configuration::get(self::CONFIG_TITLE . '_' . $idLang, null, null, $idShop),
            Configuration::get(self::CONFIG_TITLE, $defaultLanguageId, null, $idShop),
            Configuration::get(self::CONFIG_TITLE . '_' . $defaultLanguageId, null, null, $idShop),
            Configuration::get(self::CONFIG_TITLE, null, null, $idShop),
            Configuration::get(self::CONFIG_TITLE),
        ] as $configuredBlogTitle) {
            if (is_array($configuredBlogTitle)) {
                $configuredBlogTitle = $configuredBlogTitle[$idLang]
                    ?? $configuredBlogTitle[$defaultLanguageId]
                    ?? '';
            }
            $configuredBlogTitle = trim((string) $configuredBlogTitle);
            if ($configuredBlogTitle !== '') {
                $blogTitle = $configuredBlogTitle;
                break;
            }
        }
        if ($blogTitle === '') {
            $blogTitle = 'Blog';
        }
        $limit = max(1, min(50, (int) Configuration::get(self::CONFIG_HOME_LIMIT, null, null, $idShop, 6)));
        $selected = $this->normalizeArticleIds(Configuration::get(self::CONFIG_HOME_ARTICLES, null, null, $idShop, ''));
        $where = '';
        if ($selected) {
            $where = ' AND a.id_nativeblogprestashop_article IN (' . implode(',', $selected) . ')';
        } else {
            $categoryId = (int) Configuration::get(self::CONFIG_HOME_CATEGORY, null, null, $idShop, 0);
            if ($categoryId > 0) {
                $where = ' AND a.id_nativeblogprestashop_category = ' . $categoryId;
            }
        }
        $articles = Db::getInstance()->executeS(
            'SELECT a.id_nativeblogprestashop_article, a.id_nativeblogprestashop_category,
                a.slug, a.cover_image, al.title, al.excerpt,
                COALESCE(NULLIF(CONCAT_WS(" ", au.firstname, au.lastname), ""), al.author) AS author_display,
                au_base.slug AS author_slug,
                au_base.avatar AS author_avatar,
                cl.name AS category_name,
                ash.date_publish, a.date_add,
                (SELECT COUNT(*)
                 FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_comment` c
                 WHERE c.id_nativeblogprestashop_article = a.id_nativeblogprestashop_article
                    AND c.id_shop = ' . $idShop . ' AND c.approved = 1) AS comment_count,
                COALESCE((SELECT AVG(c.grade)
                 FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_comment` c
                 WHERE c.id_nativeblogprestashop_article = a.id_nativeblogprestashop_article
                    AND c.id_shop = ' . $idShop . ' AND c.approved = 1), 0) AS average_grade
            FROM `' . _DB_PREFIX_ . self::TABLE_ARTICLE . '` a
            INNER JOIN `' . _DB_PREFIX_ . self::TABLE_ARTICLE_LANG . '` al
                ON al.id_nativeblogprestashop_article = a.id_nativeblogprestashop_article AND al.id_lang = ' . $idLang . '
            INNER JOIN `' . _DB_PREFIX_ . self::TABLE_ARTICLE_SHOP . '` ash
                ON ash.id_nativeblogprestashop_article = a.id_nativeblogprestashop_article
                AND ash.id_shop = ' . $idShop . ' AND ash.active = 1
                AND (ash.date_publish IS NULL OR ash.date_publish <= NOW())
            LEFT JOIN `' . _DB_PREFIX_ . self::TABLE_AUTHOR_LANG . '` au
                ON au.id_nativeblogprestashop_author = a.id_nativeblogprestashop_author AND au.id_lang = ' . $idLang . '
            LEFT JOIN `' . _DB_PREFIX_ . self::TABLE_AUTHOR . '` au_base
                ON au_base.id_nativeblogprestashop_author = a.id_nativeblogprestashop_author
            LEFT JOIN `' . _DB_PREFIX_ . self::TABLE_CATEGORY_LANG . '` cl
                ON cl.id_nativeblogprestashop_category = a.id_nativeblogprestashop_category
                AND cl.id_lang = ' . $idLang . '
            WHERE 1 ' . $where . '
            ORDER BY COALESCE(ash.date_publish, a.date_add) DESC
            LIMIT ' . $limit
        ) ?: [];
        foreach ($articles as &$article) {
            $article['link'] = $this->context->link->getModuleLink($this->name, 'article', ['slug' => $article['slug']]);
            $article['publication_date'] = date('Y-m-d', strtotime((string) ($article['date_publish'] ?: $article['date_add'])));
            $article['comment_count'] = (int) $article['comment_count'];
            $article['average_grade'] = round((float) $article['average_grade'], 1);
            $article['cover_url'] = preg_match('/^[a-f0-9]{32}\.(jpg|png|gif|webp)$/', (string) $article['cover_image'])
                && is_file($this->getLocalPath() . 'upload/' . $article['cover_image'])
                ? __PS_BASE_URI__ . 'modules/' . $this->name . '/upload/' . $article['cover_image']
                : '';
            $article['author_display'] = trim((string) $article['author_display']);
            $article['author_url'] = $article['author_display'] !== '' && (string) $article['author_slug'] !== ''
                ? $this->context->link->getModuleLink($this->name, 'author', ['slug' => $article['author_slug']])
                : '';
            $article['author_avatar_url'] = preg_match('/^[a-f0-9]{32}\.(jpg|png|gif|webp)$/', (string) $article['author_avatar'])
                && is_file($this->getLocalPath() . 'upload/authors/' . $article['author_avatar'])
                ? __PS_BASE_URI__ . 'modules/' . $this->name . '/upload/authors/' . $article['author_avatar']
                : '';
            $article['category_name'] = trim((string) $article['category_name']);
            $article['category_url'] = (int) $article['id_nativeblogprestashop_category'] > 0
                ? $this->getCategoryLink((int) $article['id_nativeblogprestashop_category'])
                : '';
        }
        unset($article);
        $this->context->smarty->assign([
            'nativeblogprestashop_title' => $blogTitle,
            'nativeblogprestashop_link' => $this->context->link->getModuleLink($this->name, 'home'),
            'nativeblogprestashop_home_articles' => $articles,
            'nativeblogprestashop_comments_enabled' => $this->isCommentsEnabled(),
        ]);

        return $this->display(__FILE__, 'views/templates/hook/home.tpl');
    }

    public function isCommentsEnabled(): bool
    {
        return (bool) Configuration::get(
            self::CONFIG_COMMENTS_ENABLED,
            null,
            null,
            (int) $this->context->shop->id,
            false
        );
    }

    private function syncAdminTabs(): bool
    {
        $success = true;
        $commentsEnabled = $this->isCommentsEnabled();
        $originalLanguage = $this->context->language;
        foreach ([
            'AdminNativeBlog' => 'Blog',
            'AdminNativeBlogCategories' => 'Categories',
            'AdminNativeBlogArticles' => 'Articles',
            'AdminNativeBlogAuthors' => 'Authors',
            'AdminNativeBlogComments' => 'Comments',
        ] as $className => $label) {
            $idTab = (int) Tab::getIdFromClassName($className);
            if ($idTab <= 0) {
                continue;
            }

            $tab = new Tab($idTab);
            $changed = false;
            foreach (Language::getLanguages(false) as $language) {
                $languageId = (int) $language['id_lang'];
                $this->context->language = new Language($languageId);
                $translatedLabel = $this->l($label);
                if (!isset($tab->name[$languageId]) || $tab->name[$languageId] !== $translatedLabel) {
                    $tab->name[$languageId] = $translatedLabel;
                    $changed = true;
                }
            }

            $active = $className === 'AdminNativeBlogComments' ? (int) $commentsEnabled : (int) $tab->active;
            if ((int) $tab->active !== $active) {
                $tab->active = $active;
                $changed = true;
            }
            if ($changed && !$tab->update()) {
                $success = false;
            }
        }
        $this->context->language = $originalLanguage;

        return $success;
    }

    private function getMultilingualInputValue(string $key): array
    {
        $submitted = Tools::getValue($key);
        $values = is_array($submitted) ? $submitted : [];
        foreach (Language::getLanguages(false) as $language) {
            $languageId = (int) $language['id_lang'];
            $translatedValue = Tools::getValue($key . '_' . $languageId);
            if ($translatedValue !== false && $translatedValue !== null) {
                $values[$languageId] = $translatedValue;
            }
        }
        if (!is_array($submitted) && $submitted !== false && $submitted !== null && $submitted !== '') {
            $values[(int) $this->context->language->id] = $submitted;
        }

        return $values;
    }

    private function installTabs(): bool
    {
        $parent = new Tab();
        $parent->class_name = 'AdminNativeBlog';
        $parent->module = $this->name;
        $parent->active = true;
        $parent->id_parent = 0;
        foreach (Language::getLanguages(true) as $language) {
            $parent->name[(int) $language['id_lang']] = $this->l('Blog');
        }

        if (!$parent->add()) {
            return false;
        }

        foreach ([
            ['AdminNativeBlogCategories', 'Categories'],
            ['AdminNativeBlogArticles', 'Articles'],
            ['AdminNativeBlogAuthors', 'Authors'],
            ['AdminNativeBlogComments', 'Comments'],
        ] as $child) {
            $tab = new Tab();
            $tab->class_name = $child[0];
            $tab->module = $this->name;
            $tab->active = true;
            $tab->id_parent = (int) $parent->id;
            foreach (Language::getLanguages(true) as $language) {
                $tab->name[(int) $language['id_lang']] = $this->l($child[1]);
            }

            if (!$tab->add()) {
                return false;
            }
        }

        return true;
    }

    private function uninstallTabs(): bool
    {
        $success = true;
        foreach (['AdminNativeBlogComments', 'AdminNativeBlogAuthors', 'AdminNativeBlogArticles', 'AdminNativeBlogCategories', 'AdminNativeBlog'] as $className) {
            $idTab = (int) Tab::getIdFromClassName($className);
            if ($idTab > 0) {
                $tab = new Tab($idTab);
                $success = $tab->delete() && $success;
            }
        }

        return $success;
    }

    private function installDatabase(): bool
    {
        $postTable = _DB_PREFIX_ . bqSQL(self::TABLE_POST);
        $categoryTable = _DB_PREFIX_ . bqSQL(self::TABLE_CATEGORY);
        $categoryLangTable = _DB_PREFIX_ . bqSQL(self::TABLE_CATEGORY_LANG);
        $categoryShopTable = _DB_PREFIX_ . bqSQL(self::TABLE_CATEGORY_SHOP);
        $articleTable = _DB_PREFIX_ . bqSQL(self::TABLE_ARTICLE);
        $articleLangTable = _DB_PREFIX_ . bqSQL(self::TABLE_ARTICLE_LANG);
        $articleShopTable = _DB_PREFIX_ . bqSQL(self::TABLE_ARTICLE_SHOP);
        $queries = [
            'CREATE TABLE IF NOT EXISTS `' . $postTable . '` (
            `id_nativeblogprestashop_post` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `title` VARCHAR(255) NOT NULL,
            `slug` VARCHAR(255) NOT NULL,
            `content` TEXT NOT NULL,
            `active` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
            `date_add` DATETIME NOT NULL,
            `date_upd` DATETIME NOT NULL,
            PRIMARY KEY (`id_nativeblogprestashop_post`),
            UNIQUE KEY `nativeblogprestashop_post_slug` (`slug`),
            KEY `nativeblogprestashop_post_active` (`active`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
            'CREATE TABLE IF NOT EXISTS `' . $categoryTable . '` (
                `id_nativeblogprestashop_category` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `id_parent` INT UNSIGNED NOT NULL DEFAULT 0,
                `slug` VARCHAR(255) NOT NULL,
                `date_add` DATETIME NOT NULL,
                `date_upd` DATETIME NOT NULL,
                PRIMARY KEY (`id_nativeblogprestashop_category`),
                UNIQUE KEY `nativeblogprestashop_category_slug` (`slug`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
            'CREATE TABLE IF NOT EXISTS `' . $categoryLangTable . '` (
                `id_nativeblogprestashop_category` INT UNSIGNED NOT NULL,
                `id_lang` INT UNSIGNED NOT NULL,
                `name` VARCHAR(255) NOT NULL,
                `description` TEXT NULL,
                `meta_title` VARCHAR(255) NULL,
                `meta_description` VARCHAR(512) NULL,
                PRIMARY KEY (`id_nativeblogprestashop_category`, `id_lang`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
            'CREATE TABLE IF NOT EXISTS `' . $categoryShopTable . '` (
                `id_nativeblogprestashop_category` INT UNSIGNED NOT NULL,
                `id_shop` INT UNSIGNED NOT NULL,
                `active` TINYINT(1) UNSIGNED NOT NULL DEFAULT 1,
                PRIMARY KEY (`id_nativeblogprestashop_category`, `id_shop`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
            'CREATE TABLE IF NOT EXISTS `' . $articleTable . '` (
                `id_nativeblogprestashop_article` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `id_nativeblogprestashop_category` INT UNSIGNED NULL,
                `id_nativeblogprestashop_author` INT UNSIGNED NULL,
                `slug` VARCHAR(255) NOT NULL,
                `cover_image` VARCHAR(255) NULL,
                `date_add` DATETIME NOT NULL,
                `date_upd` DATETIME NOT NULL,
                PRIMARY KEY (`id_nativeblogprestashop_article`),
                UNIQUE KEY `nativeblogprestashop_article_slug` (`slug`),
                KEY `nativeblogprestashop_article_category` (`id_nativeblogprestashop_category`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
            'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'nativeblogprestashop_comment` (
                `id_nativeblogprestashop_comment` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `id_nativeblogprestashop_article` INT UNSIGNED NOT NULL,
                `id_shop` INT UNSIGNED NOT NULL,
                `id_customer` INT UNSIGNED NULL,
                `guest_hash` CHAR(64) NOT NULL,
                `author_name` VARCHAR(64) NOT NULL,
                `author_email` VARCHAR(255) NULL,
                `title` VARCHAR(64) NOT NULL,
                `content` TEXT NOT NULL,
                `grade` TINYINT UNSIGNED NOT NULL,
                `approved` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
                `date_add` DATETIME NOT NULL,
                PRIMARY KEY (`id_nativeblogprestashop_comment`),
                UNIQUE KEY `nativeblogprestashop_comment_duplicate` (`id_nativeblogprestashop_article`, `id_shop`, `guest_hash`),
                KEY `nativeblogprestashop_comment_article` (`id_nativeblogprestashop_article`, `id_shop`, `approved`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
            'CREATE TABLE IF NOT EXISTS `' . $articleLangTable . '` (
                `id_nativeblogprestashop_article` INT UNSIGNED NOT NULL,
                `id_lang` INT UNSIGNED NOT NULL,
                `title` VARCHAR(255) NOT NULL,
                `author` VARCHAR(255) NULL,
                `excerpt` TEXT NULL,
                `content` LONGTEXT NOT NULL,
                `meta_title` VARCHAR(255) NULL,
                `meta_description` VARCHAR(512) NULL,
                PRIMARY KEY (`id_nativeblogprestashop_article`, `id_lang`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
            'CREATE TABLE IF NOT EXISTS `' . $articleShopTable . '` (
                `id_nativeblogprestashop_article` INT UNSIGNED NOT NULL,
                `id_shop` INT UNSIGNED NOT NULL,
                `active` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
                `date_publish` DATETIME NULL,
                PRIMARY KEY (`id_nativeblogprestashop_article`, `id_shop`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
            'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'nativeblogprestashop_tag` (
                `id_nativeblogprestashop_tag` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `slug` VARCHAR(255) NOT NULL,
                PRIMARY KEY (`id_nativeblogprestashop_tag`),
                UNIQUE KEY `nativeblogprestashop_tag_slug` (`slug`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
            'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'nativeblogprestashop_tag_lang` (
                `id_nativeblogprestashop_tag` INT UNSIGNED NOT NULL,
                `id_lang` INT UNSIGNED NOT NULL,
                `name` VARCHAR(255) NOT NULL,
                PRIMARY KEY (`id_nativeblogprestashop_tag`, `id_lang`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
            'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'nativeblogprestashop_article_tag` (
                `id_nativeblogprestashop_article` INT UNSIGNED NOT NULL,
                `id_nativeblogprestashop_tag` INT UNSIGNED NOT NULL,
                PRIMARY KEY (`id_nativeblogprestashop_article`, `id_nativeblogprestashop_tag`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci',
        ];

        foreach ($queries as $query) {
            if (!Db::getInstance()->execute($query)) {
                return false;
            }
        }

        return true;
    }

    private function uninstallDatabase(): bool
    {
        foreach ([
            self::TABLE_ARTICLE_SHOP,
            self::TABLE_ARTICLE_LANG,
            self::TABLE_ARTICLE,
            self::TABLE_AUTHOR_SHOP,
            self::TABLE_AUTHOR_LANG,
            self::TABLE_AUTHOR,
            'nativeblogprestashop_comment',
            self::TABLE_ARTICLE_TAG,
            self::TABLE_TAG_LANG,
            self::TABLE_TAG,
            self::TABLE_CATEGORY_SHOP,
            self::TABLE_CATEGORY_LANG,
            self::TABLE_CATEGORY,
            'nativeblogprestashop_menu_link',
            self::TABLE_POST,
        ] as $tableName) {
            $table = _DB_PREFIX_ . bqSQL($tableName);
            if (!Db::getInstance()->execute('DROP TABLE IF EXISTS `' . $table . '`')) {
                return false;
            }
        }

        return true;
    }

    private function renderForm(): string
    {
        $helper = new HelperForm();
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;
        $helper->submit_action = 'submitNativeBlogPrestaShop';
        $helper->default_form_language = (int) Configuration::get('PS_LANG_DEFAULT');
        $helper->allow_employee_form_lang = (int) Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG');
        $helper->languages = Language::getLanguages(false);
        foreach ($helper->languages as &$language) {
            $language['is_default'] = (int) ((int) $language['id_lang'] === (int) $helper->default_form_language);
        }
        unset($language);
        $idShop = (int) $this->context->shop->id;
        $helper->fields_value[self::CONFIG_ENABLED] = (bool) Configuration::get(self::CONFIG_ENABLED, null, null, $idShop);
        $helper->fields_value[self::CONFIG_COMMENTS_ENABLED] = $this->isCommentsEnabled();
        $storedTitles = Configuration::get(self::CONFIG_TITLE, null, null, $idShop);
        $storedScalarTitle = is_array($storedTitles) ? '' : trim((string) $storedTitles);
        $titleValues = is_array($storedTitles) ? $storedTitles : [];
        foreach ($helper->languages as $language) {
            $languageId = (int) $language['id_lang'];
            if (!isset($titleValues[$languageId]) || trim((string) $titleValues[$languageId]) === '') {
                $languageTitle = Configuration::get(self::CONFIG_TITLE, $languageId, null, $idShop);
                if ($languageTitle !== false && $languageTitle !== null && $languageTitle !== '') {
                    $titleValues[$languageId] = $languageTitle;
                } elseif ($storedScalarTitle !== '') {
                    $titleValues[$languageId] = $storedScalarTitle;
                } else {
                    $titleValues[$languageId] = '';
                }
            }
        }
        $helper->fields_value[self::CONFIG_TITLE] = $titleValues;
        $helper->fields_value[self::CONFIG_HOME_LIMIT] = (int) Configuration::get(self::CONFIG_HOME_LIMIT, null, null, $idShop, 6);
        $helper->fields_value[self::CONFIG_HOME_CATEGORY] = (int) Configuration::get(self::CONFIG_HOME_CATEGORY, null, null, $idShop, 0);
        $selectedArticleIds = $this->normalizeArticleIds(Configuration::get(self::CONFIG_HOME_ARTICLES, null, null, $idShop, ''));
        $helper->fields_value[self::CONFIG_HOME_ARTICLES] = $selectedArticleIds;
        $helper->fields_value[self::CONFIG_HOME_ARTICLES . '[]'] = $selectedArticleIds;
        $idLang = (int) $this->context->language->id;
        $idShop = (int) $this->context->shop->id;
        $categoryOptions = [['id' => 0, 'name' => $this->l('All categories')]];
        foreach (Db::getInstance()->executeS(
            'SELECT c.id_nativeblogprestashop_category AS id, cl.name
            FROM `' . _DB_PREFIX_ . self::TABLE_CATEGORY . '` c
            INNER JOIN `' . _DB_PREFIX_ . self::TABLE_CATEGORY_LANG . '` cl
                ON cl.id_nativeblogprestashop_category = c.id_nativeblogprestashop_category
                AND cl.id_lang = ' . $idLang . '
            INNER JOIN `' . _DB_PREFIX_ . self::TABLE_CATEGORY_SHOP . '` cs
                ON cs.id_nativeblogprestashop_category = c.id_nativeblogprestashop_category
                AND cs.id_shop = ' . $idShop . ' AND cs.active = 1
            ORDER BY cl.name ASC'
        ) ?: [] as $category) {
            $categoryOptions[] = ['id' => (int) $category['id'], 'name' => (string) $category['name']];
        }
        $articleOptions = [];
        foreach (Db::getInstance()->executeS(
            'SELECT a.id_nativeblogprestashop_article AS id, al.title
            FROM `' . _DB_PREFIX_ . self::TABLE_ARTICLE . '` a
            INNER JOIN `' . _DB_PREFIX_ . self::TABLE_ARTICLE_LANG . '` al
                ON al.id_nativeblogprestashop_article = a.id_nativeblogprestashop_article
                AND al.id_lang = ' . $idLang . '
            INNER JOIN `' . _DB_PREFIX_ . self::TABLE_ARTICLE_SHOP . '` ash
                ON ash.id_nativeblogprestashop_article = a.id_nativeblogprestashop_article
                AND ash.id_shop = ' . $idShop . '
            ORDER BY al.title ASC'
        ) ?: [] as $article) {
            $articleOptions[] = ['id' => (int) $article['id'], 'name' => (string) $article['title']];
        }

        return $helper->generateForm([
            [
                'form' => [
                    'legend' => [
                        'title' => $this->l('Settings'),
                        'icon' => 'icon-cogs',
                    ],
                    'input' => [
                        [
                            'type' => 'switch',
                            'label' => $this->l('Enable blog'),
                            'name' => self::CONFIG_ENABLED,
                            'is_bool' => true,
                            'values' => [
                                ['id' => 'enabled_on', 'value' => true, 'label' => $this->l('Yes')],
                                ['id' => 'enabled_off', 'value' => false, 'label' => $this->l('No')],
                            ],
                        ],
                        [
                            'type' => 'text',
                            'label' => $this->l('Blog title'),
                            'name' => self::CONFIG_TITLE,
                            'lang' => true,
                            'required' => true,
                        ],
                        [
                            'type' => 'text',
                            'label' => $this->l('Homepage article limit'),
                            'name' => self::CONFIG_HOME_LIMIT,
                            'desc' => $this->l('Between 1 and 50.'),
                        ],
                        [
                            'type' => 'select',
                            'label' => $this->l('Homepage category scope'),
                            'name' => self::CONFIG_HOME_CATEGORY,
                            'options' => ['query' => $categoryOptions, 'id' => 'id', 'name' => 'name'],
                        ],
                        [
                            'type' => 'select',
                            'label' => $this->l('Specific homepage articles'),
                            'name' => self::CONFIG_HOME_ARTICLES . '[]',
                            'multiple' => true,
                            'size' => 10,
                            'desc' => $this->l('Optional. Selected articles take precedence over the category and all-article scope.'),
                            'options' => ['query' => $articleOptions, 'id' => 'id', 'name' => 'name'],
                        ],
                        [
                            'type' => 'switch',
                            'label' => $this->l('Enable comments'),
                            'name' => self::CONFIG_COMMENTS_ENABLED,
                            'is_bool' => true,
                            'desc' => $this->l('Comments and ratings are disabled by default.'),
                            'values' => [
                                ['id' => 'comments_enabled_on', 'value' => true, 'label' => $this->l('Yes')],
                                ['id' => 'comments_enabled_off', 'value' => false, 'label' => $this->l('No')],
                            ],
                        ],
                    ],
                    'submit' => [
                        'title' => $this->l('Save'),
                    ],
                ],
            ],
        ]);
    }

    private function normalizeArticleIds($value): array
    {
        $values = is_array($value) ? $value : explode(',', (string) $value);
        $ids = [];
        foreach ($values as $item) {
            $id = (int) $item;
            if ($id > 0) {
                $ids[$id] = $id;
            }
        }

        return array_values($ids);
    }
}
