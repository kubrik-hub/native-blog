<?php
/**
 * Native PrestaShop Blog comments controller.
 *
 * Centralised moderation screen for every review left on every article,
 * reproducing the back-office functionalities of PrestaShop's native
 * `productcomments` module (approve, reject, delete, bulk actions,
 * filter by status/article, search).
 *
 * @author Kamel Kelkoul
 * @license https://opensource.org/licenses/OSL-3.0 Open Software License 3.0 (OSL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminNativeBlogCommentsController extends ModuleAdminController
{
    private const COMMENTS_PER_PAGE = 20;

    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
        $this->meta_title = $this->module->l('Comments', 'AdminNativeBlogCommentsController');
    }

    public function initContent()
    {
        $this->processActions();
        $this->content .= $this->renderCommentsList();
        parent::initContent();
    }

    /**
     * Handles single-row actions (approve / reject / delete, triggered from
     * the row links) and the bulk action form (checkboxes + action select).
     */
    private function processActions(): void
    {
        if (Tools::isSubmit('submitNativeBlogCommentBulk')) {
            $ids = array_filter(array_map('intval', (array) Tools::getValue('comment_ids', [])), function ($id) {
                return $id > 0;
            });
            $action = (string) Tools::getValue('bulk_action');
            if ($ids && in_array($action, ['approve', 'reject', 'delete'], true)) {
                $this->applyAction($action, $ids);
            } elseif (!$ids) {
                $this->errors[] = $this->module->l('Please select at least one review.', 'AdminNativeBlogCommentsController');
            }

            return;
        }

        $commentId = (int) Tools::getValue('comment_id');
        if ($commentId <= 0) {
            return;
        }
        if (Tools::isSubmit('approveNativeBlogComment')) {
            $this->applyAction('approve', [$commentId]);
        } elseif (Tools::isSubmit('rejectNativeBlogComment')) {
            $this->applyAction('reject', [$commentId]);
        } elseif (Tools::isSubmit('deleteNativeBlogComment')) {
            $this->applyAction('delete', [$commentId]);
        }
    }

    private function applyAction(string $action, array $ids): void
    {
        $idShop = (int) $this->context->shop->id;
        $idsList = implode(',', array_map('intval', $ids));
        if ($idsList === '') {
            return;
        }

        $commentTable = _DB_PREFIX_ . 'nativeblogprestashop_comment';
        switch ($action) {
            case 'approve':
                $success = Db::getInstance()->execute(
                    'UPDATE `' . bqSQL($commentTable) . '` SET approved = 1
                    WHERE id_nativeblogprestashop_comment IN (' . $idsList . ') AND id_shop = ' . $idShop
                );
                $okMessage = $this->module->l('The selected review(s) have been approved.', 'AdminNativeBlogCommentsController');
                $koMessage = $this->module->l('The selected review(s) could not be approved.', 'AdminNativeBlogCommentsController');
                break;
            case 'reject':
                $success = Db::getInstance()->execute(
                    'UPDATE `' . bqSQL($commentTable) . '` SET approved = 0
                    WHERE id_nativeblogprestashop_comment IN (' . $idsList . ') AND id_shop = ' . $idShop
                );
                $okMessage = $this->module->l('The selected review(s) have been rejected.', 'AdminNativeBlogCommentsController');
                $koMessage = $this->module->l('The selected review(s) could not be rejected.', 'AdminNativeBlogCommentsController');
                break;
            case 'delete':
                $success = Db::getInstance()->execute(
                    'DELETE FROM `' . bqSQL($commentTable) . '`
                    WHERE id_nativeblogprestashop_comment IN (' . $idsList . ') AND id_shop = ' . $idShop
                );
                $okMessage = $this->module->l('The selected review(s) have been deleted.', 'AdminNativeBlogCommentsController');
                $koMessage = $this->module->l('The selected review(s) could not be deleted.', 'AdminNativeBlogCommentsController');
                break;
            default:
                return;
        }

        if ($success) {
            $this->confirmations[] = $okMessage;
        } else {
            $this->errors[] = $koMessage;
        }
    }

    private function renderCommentsList(): string
    {
        $idLang = (int) $this->context->language->id;
        $idShop = (int) $this->context->shop->id;

        $status = (string) Tools::getValue('nbps_comment_status');
        $search = trim((string) Tools::getValue('nbps_comment_search'));
        $articleFilter = (int) Tools::getValue('id_nativeblogprestashop_article');

        $where = ' WHERE c.id_shop = ' . $idShop;
        if ($status === 'pending') {
            $where .= ' AND c.approved = 0';
        } elseif ($status === 'approved') {
            $where .= ' AND c.approved = 1';
        }
        if ($articleFilter > 0) {
            $where .= ' AND c.id_nativeblogprestashop_article = ' . $articleFilter;
        }
        if ($search !== '') {
            $escaped = pSQL($search);
            $where .= ' AND (c.author_name LIKE "%' . $escaped . '%"
                OR c.author_email LIKE "%' . $escaped . '%"
                OR c.title LIKE "%' . $escaped . '%"
                OR c.content LIKE "%' . $escaped . '%"
                OR al.title LIKE "%' . $escaped . '%")';
        }

        $joinArticle = 'INNER JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_article` a
                ON a.id_nativeblogprestashop_article = c.id_nativeblogprestashop_article
            LEFT JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_article_lang` al
                ON al.id_nativeblogprestashop_article = a.id_nativeblogprestashop_article
                AND al.id_lang = ' . $idLang . ' ';

        $totalComments = (int) Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_comment` c ' . $joinArticle . $where
        );
        $totalPending = (int) Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_comment` c
            INNER JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_article` a ON a.id_nativeblogprestashop_article = c.id_nativeblogprestashop_article
            WHERE c.id_shop = ' . $idShop . ' AND c.approved = 0'
        );

        $totalPages = max(1, (int) ceil($totalComments / self::COMMENTS_PER_PAGE));
        $page = max(1, min($totalPages, (int) Tools::getValue('page', 1)));
        $offset = ($page - 1) * self::COMMENTS_PER_PAGE;

        $comments = Db::getInstance()->executeS(
            'SELECT c.id_nativeblogprestashop_comment, c.author_name, c.author_email, c.title, c.content,
                c.grade, c.approved, c.date_add, c.id_nativeblogprestashop_article,
                a.slug AS article_slug, al.title AS article_title
            FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_comment` c ' . $joinArticle . $where . '
            ORDER BY c.approved ASC, c.date_add DESC
            LIMIT ' . self::COMMENTS_PER_PAGE . ' OFFSET ' . $offset
        ) ?: [];
        foreach ($comments as &$comment) {
            $comment['article_url'] = $comment['article_slug']
                ? $this->context->link->getModuleLink($this->module->name, 'article', ['slug' => $comment['article_slug']])
                : '';
            $comment['grade'] = (int) $comment['grade'];
            $comment['approved'] = (bool) $comment['approved'];
        }
        unset($comment);

        $baseUrl = self::$currentIndex . '&token=' . $this->token;
        $filterUrl = $baseUrl;
        if ($status !== '') {
            $filterUrl .= '&nbps_comment_status=' . urlencode($status);
        }
        if ($search !== '') {
            $filterUrl .= '&nbps_comment_search=' . urlencode($search);
        }
        if ($articleFilter > 0) {
            $filterUrl .= '&id_nativeblogprestashop_article=' . $articleFilter;
        }
        $pageLink = function (int $targetPage) use ($filterUrl): string {
            return $filterUrl . ($targetPage > 1 ? '&page=' . $targetPage : '');
        };

        $this->context->smarty->assign([
            'nativeblogprestashop_comments' => $comments,
            'nativeblogprestashop_comment_status' => $status,
            'nativeblogprestashop_comment_search' => $search,
            'nativeblogprestashop_comment_article_filter' => $articleFilter,
            'nativeblogprestashop_comment_total' => $totalComments,
            'nativeblogprestashop_comment_total_pending' => $totalPending,
            'nativeblogprestashop_comment_pagination' => [
                'current_page' => $page,
                'total_pages' => $totalPages,
                'has_previous' => $page > 1,
                'has_next' => $page < $totalPages,
                'previous_url' => $page > 1 ? $pageLink($page - 1) : '',
                'next_url' => $page < $totalPages ? $pageLink($page + 1) : '',
            ],
            'nativeblogprestashop_comment_form_url' => $baseUrl,
            'nativeblogprestashop_comment_token' => $this->token,
            'nativeblogprestashop_comment_approve_base' => $baseUrl . '&approveNativeBlogComment=1&comment_id=',
            'nativeblogprestashop_comment_reject_base' => $baseUrl . '&rejectNativeBlogComment=1&comment_id=',
            'nativeblogprestashop_comment_delete_base' => $baseUrl . '&deleteNativeBlogComment=1&comment_id=',
        ]);

        return $this->context->smarty->fetch($this->module->getLocalPath() . 'views/templates/admin/comments-list.tpl');
    }
}
