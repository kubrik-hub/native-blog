<?php
/**
 * Native PrestaShop Blog directory guard.
 *
 * @author Kamel Kelkoul
 * @license https://opensource.org/licenses/OSL-3.0 Open Software License 3.0 (OSL-3.0)
 */

exit;
