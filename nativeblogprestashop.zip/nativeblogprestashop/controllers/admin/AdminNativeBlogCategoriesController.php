<?php
/**
 * Native PrestaShop Blog categories controller.
 *
 * @author Kamel Kelkoul
 * @license https://opensource.org/licenses/OSL-3.0 Open Software License 3.0 (OSL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminNativeBlogCategoriesController extends ModuleAdminController
{
    public function __construct()
    {
        $this->table = 'nativeblogprestashop_category';
        $this->className = '';
        $this->identifier = 'id_nativeblogprestashop_category';
        $this->lang = true;
        $this->bootstrap = true;
        $this->display = 'list';
        parent::__construct();
        $this->meta_title = $this->module->l('Categories', 'AdminNativeBlogCategoriesController');
    }

    public function initPageHeaderToolbar()
    {
        if ($this->display !== 'edit') {
            $this->page_header_toolbar_btn['new_category'] = [
                'href' => self::$currentIndex . '&token=' . $this->token . '&add' . $this->table,
                'desc' => $this->module->l('Add new category', 'AdminNativeBlogCategoriesController'),
            ];
        }

        parent::initPageHeaderToolbar();
    }

    public function renderList()
    {
        $categories = Db::getInstance()->executeS(
            'SELECT c.id_nativeblogprestashop_category, c.id_parent, c.slug, c.date_upd, cl.name
            FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_category` c
            LEFT JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_category_lang` cl
                ON cl.id_nativeblogprestashop_category = c.id_nativeblogprestashop_category
                AND cl.id_lang = ' . (int) $this->context->language->id . '
            INNER JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_category_shop` cs
                ON cs.id_nativeblogprestashop_category = c.id_nativeblogprestashop_category
                AND cs.id_shop = ' . (int) $this->context->shop->id . '
            ORDER BY c.date_upd DESC'
        );
        $parentIds = [];
        foreach ($categories ?: [] as $category) {
            $parentIds[(int) $category['id_nativeblogprestashop_category']] = (int) $category['id_parent'];
        }
        $categories = $categories ?: [];
        foreach ($categories as &$category) {
            $categoryId = (int) $category['id_nativeblogprestashop_category'];
            $depth = 0;
            $parentId = $parentIds[$categoryId] ?? 0;
            $visited = [$categoryId => true];
            while ($parentId > 0 && isset($parentIds[$parentId]) && !isset($visited[$parentId])) {
                $visited[$parentId] = true;
                ++$depth;
                $parentId = $parentIds[$parentId];
            }
            $category['display_name'] = str_repeat("\xC2\xA0\xC2\xA0", $depth) . (string) $category['name'];
        }
        unset($category);
        $childrenByParent = [];
        foreach ($categories as $category) {
            $childrenByParent[(int) $category['id_parent']][] = $category;
        }
        $orderedCategories = [];
        $appendChildren = function ($parentId, array $ancestors) use (&$appendChildren, &$orderedCategories, $childrenByParent) {
            foreach ($childrenByParent[$parentId] ?? [] as $category) {
                $categoryId = (int) $category['id_nativeblogprestashop_category'];
                if (isset($ancestors[$categoryId])) {
                    continue;
                }
                $orderedCategories[] = $category;
                $nextAncestors = $ancestors;
                $nextAncestors[$categoryId] = true;
                $appendChildren($categoryId, $nextAncestors);
            }
        };
        $appendChildren(0, []);
        if (count($orderedCategories) < count($categories)) {
            $orderedIds = array_fill_keys(array_map(static function ($category) {
                return (int) $category['id_nativeblogprestashop_category'];
            }, $orderedCategories), true);
            foreach ($categories as $category) {
                if (!isset($orderedIds[(int) $category['id_nativeblogprestashop_category']])) {
                    $orderedCategories[] = $category;
                }
            }
        }
        $categories = $orderedCategories;
        $this->context->smarty->assign([
            'nativeblogprestashop_categories' => $categories,
            'nativeblogprestashop_add_url' => self::$currentIndex . '&token=' . $this->token . '&add' . $this->table,
            'nativeblogprestashop_edit_base' => self::$currentIndex . '&token=' . $this->token . '&update' . $this->table . '&' . $this->identifier . '=',
            'nativeblogprestashop_delete_base' => self::$currentIndex . '&token=' . $this->token . '&delete' . $this->table . '&' . $this->identifier . '=',
        ]);

        return $this->context->smarty->fetch($this->module->getLocalPath() . 'views/templates/admin/categories-list.tpl');
    }

    public function renderForm()
    {
        $id = $this->getCategoryId();
        $this->module->ensureDatabaseSchema();
        if ($id > 0) {
            $this->fields_value = Db::getInstance()->getRow(
                'SELECT slug, id_parent FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_category`
                WHERE id_nativeblogprestashop_category = ' . $id
            ) ?: [];
            $translations = Db::getInstance()->executeS(
                'SELECT id_lang, name, description
                FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_category_lang`
                WHERE id_nativeblogprestashop_category = ' . $id
            );
            foreach ($translations as $translation) {
                $languageId = (int) $translation['id_lang'];
                $this->fields_value['name'][$languageId] = $translation['name'];
                $this->fields_value['description'][$languageId] = $translation['description'];
            }
        }
        $this->fields_value[$this->identifier] = $id;
        $this->fields_value['id_parent'] = (int) ($this->fields_value['id_parent'] ?? 0);
        $parentOptions = [['id' => 0, 'name' => $this->module->l('No parent', 'AdminNativeBlogCategoriesController')]];
        foreach ($this->getParentCategoryOptions($id) as $option) {
            $parentOptions[] = $option;
        }
        $this->fields_form = [
            'legend' => ['title' => $this->module->l('Category', 'AdminNativeBlogCategoriesController')],
            'input' => [
                ['type' => 'hidden', 'name' => $this->identifier],
                ['type' => 'select', 'label' => $this->module->l('Parent category', 'AdminNativeBlogCategoriesController'), 'name' => 'id_parent', 'options' => [
                    'query' => $parentOptions,
                    'id' => 'id',
                    'name' => 'name',
                ]],
                ['type' => 'text', 'label' => $this->module->l('Name'), 'name' => 'name', 'lang' => true, 'required' => true],
                ['type' => 'textarea', 'label' => $this->module->l('Description'), 'name' => 'description', 'lang' => true],
                ['type' => 'text', 'label' => $this->module->l('Slug'), 'name' => 'slug', 'desc' => $this->module->l('Optional. Leave empty to generate it from the category name.')],
            ],
            'submit' => ['title' => $this->module->l('Save')],
        ];

        return parent::renderForm();
    }

    public function processAdd()
    {
        return $this->saveCategory();
    }

    public function processUpdate()
    {
        if ($this->getCategoryId() <= 0) {
            $this->errors[] = $this->module->l('The category identifier is missing; the category was not updated.');
            return false;
        }

        return $this->saveCategory();
    }

    public function processDelete()
    {
        $id = (int) Tools::getValue($this->identifier);
        $shopId = (int) $this->context->shop->id;
        if ($id <= 0 || !(int) Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_category_shop`
            WHERE id_nativeblogprestashop_category = ' . $id . ' AND id_shop = ' . $shopId
        )) {
            $this->errors[] = $this->module->l('Invalid category ID.', 'AdminNativeBlogCategoriesController');
            return false;
        }

        $shopCount = (int) Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_category_shop`
            WHERE id_nativeblogprestashop_category = ' . $id
        );
        if ($shopCount > 1) {
            $deleted = Db::getInstance()->delete(
                'nativeblogprestashop_category_shop',
                'id_nativeblogprestashop_category = ' . $id . ' AND id_shop = ' . $shopId
            );
        } else {
            $hasArticles = (int) Db::getInstance()->getValue(
                'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_article`
                WHERE id_nativeblogprestashop_category = ' . $id
            ) > 0;
            $hasChildren = (int) Db::getInstance()->getValue(
                'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_category`
                WHERE id_parent = ' . $id
            ) > 0;
            if ($hasArticles || $hasChildren) {
                $this->errors[] = $this->module->l(
                    'Reassign this category\'s articles and child categories before deleting it.',
                    'AdminNativeBlogCategoriesController'
                );
                return false;
            }

            $deleted = Db::getInstance()->delete('nativeblogprestashop_category_lang', 'id_nativeblogprestashop_category = ' . $id)
                && Db::getInstance()->delete('nativeblogprestashop_category_shop', 'id_nativeblogprestashop_category = ' . $id)
                && Db::getInstance()->delete('nativeblogprestashop_category', 'id_nativeblogprestashop_category = ' . $id);
        }

        if ($deleted) {
            $this->module->syncMainMenuLinks();
        }

        return $deleted;
    }

    private function saveCategory()
    {
        if (!$this->module->ensureDatabaseSchema()) {
            $this->errors[] = $this->module->l('The category database schema is not ready.', 'AdminNativeBlogCategoriesController');
            return false;
        }
        $id = $this->getCategoryId();
        $parentId = max(0, (int) Tools::getValue('id_parent', 0));
        if (!$this->isValidParentCategory($parentId, $id)) {
            $this->errors[] = $this->module->l('The selected parent category is invalid.', 'AdminNativeBlogCategoriesController');
            return false;
        }
        $names = $this->getMultilingualValue('name');
        $descriptions = $this->getMultilingualValue('description');
        $name = $this->getDefaultLanguageValue($names);
        if ($name === '') {
            $this->errors[] = $this->module->l('A category name is required.');
            return false;
        }

        $slug = Tools::str2url((string) Tools::getValue('slug'));
        if ($slug === '') {
            $slug = Tools::str2url($name);
        }
        if ($slug === '') {
            $this->errors[] = $this->module->l('A valid category name or slug is required.');
            return false;
        }
        $slug = $this->getUniqueSlug($slug, $id);

        $now = date('Y-m-d H:i:s');
        $data = ['id_parent' => $parentId, 'slug' => pSQL($slug), 'date_upd' => pSQL($now)];
        if ($id === 0) {
            $data['date_add'] = pSQL($now);
            if (!Db::getInstance()->insert('nativeblogprestashop_category', $data)) {
                return false;
            }
            $id = (int) Db::getInstance()->Insert_ID();
            if (!Db::getInstance()->insert('nativeblogprestashop_category_shop', [
                'id_nativeblogprestashop_category' => $id,
                'id_shop' => (int) $this->context->shop->id,
            ])) {
                return false;
            }
        } elseif (!Db::getInstance()->update('nativeblogprestashop_category', $data, 'id_nativeblogprestashop_category = ' . $id)) {
            return false;
        }

        if (!Db::getInstance()->delete('nativeblogprestashop_category_lang', 'id_nativeblogprestashop_category = ' . $id)) {
            return false;
        }
        foreach (Language::getLanguages(true) as $language) {
            $languageId = (int) $language['id_lang'];
            $translatedName = trim((string) (isset($names[$languageId]) ? $names[$languageId] : $name));
            $description = isset($descriptions[$languageId]) ? $descriptions[$languageId] : '';
            if (!Db::getInstance()->insert('nativeblogprestashop_category_lang', [
                'id_nativeblogprestashop_category' => $id,
                'id_lang' => $languageId,
                'name' => pSQL($translatedName),
                'description' => pSQL((string) $description, true),
            ])) {
                return false;
            }
        }

        $this->module->syncMainMenuLinks();

        return true;
    }

    private function getMultilingualValue($field)
    {
        $value = Tools::getValue($field);
        $values = is_array($value) ? $value : [];

        foreach (Language::getLanguages(true) as $language) {
            $languageId = (int) $language['id_lang'];
            $languageValue = Tools::getValue($field . '_' . $languageId);
            if ($languageValue !== false && $languageValue !== null) {
                $values[$languageId] = $languageValue;
            }
        }

        if (!is_array($value) && $value !== false && $value !== null && $value !== '') {
            $values[(int) $this->context->language->id] = $value;
        }

        return $values;
    }

    private function getCategoryId()
    {
        $id = (int) Tools::getValue($this->identifier);
        if ($id <= 0) {
            $id = (int) Tools::getValue('id_' . $this->table);
        }

        return $id;
    }

    private function getParentCategoryOptions($excludedId): array
    {
        $rows = Db::getInstance()->executeS(
            'SELECT c.id_nativeblogprestashop_category AS id, c.id_parent, cl.name
            FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_category` c
            INNER JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_category_lang` cl
                ON cl.id_nativeblogprestashop_category = c.id_nativeblogprestashop_category
                AND cl.id_lang = ' . (int) $this->context->language->id . '
            INNER JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_category_shop` cs
                ON cs.id_nativeblogprestashop_category = c.id_nativeblogprestashop_category
                AND cs.id_shop = ' . (int) $this->context->shop->id . '
            ORDER BY cl.name ASC'
        ) ?: [];
        $byParent = [];
        foreach ($rows as $row) {
            $categoryId = (int) $row['id'];
            if ($categoryId !== (int) $excludedId) {
                $byParent[(int) $row['id_parent']][] = $row;
            }
        }
        $excludedDescendants = [];
        if ((int) $excludedId > 0) {
            $pending = [(int) $excludedId];
            while ($pending) {
                $ancestorId = array_pop($pending);
                foreach ($rows as $row) {
                    if ((int) $row['id_parent'] === $ancestorId) {
                        $childId = (int) $row['id'];
                        if (!isset($excludedDescendants[$childId])) {
                            $excludedDescendants[$childId] = true;
                            $pending[] = $childId;
                        }
                    }
                }
            }
        }
        $options = [];
        $appendChildren = function ($parentId, $depth, array $ancestors) use (&$appendChildren, &$options, $byParent, $excludedDescendants) {
            foreach ($byParent[$parentId] ?? [] as $row) {
                $categoryId = (int) $row['id'];
                if (isset($ancestors[$categoryId]) || isset($excludedDescendants[$categoryId])) {
                    continue;
                }
                $options[] = [
                    'id' => $categoryId,
                    'name' => str_repeat('-- ', $depth) . (string) $row['name'],
                ];
                $nextAncestors = $ancestors;
                $nextAncestors[$categoryId] = true;
                $appendChildren($categoryId, $depth + 1, $nextAncestors);
            }
        };
        $appendChildren(0, 0, []);
        return $options;
    }

    private function isValidParentCategory($parentId, $categoryId): bool
    {
        if ($parentId === 0) {
            return true;
        }
        if ($parentId === (int) $categoryId || !(int) Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_category` c
            INNER JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_category_shop` cs
                ON cs.id_nativeblogprestashop_category = c.id_nativeblogprestashop_category
                AND cs.id_shop = ' . (int) $this->context->shop->id . '
            WHERE c.id_nativeblogprestashop_category = ' . (int) $parentId
        )) {
            return false;
        }
        $visited = [];
        while ($parentId > 0) {
            if ($parentId === (int) $categoryId || isset($visited[$parentId])) {
                return false;
            }
            $visited[$parentId] = true;
            $parentId = (int) Db::getInstance()->getValue(
                'SELECT id_parent FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_category`
                WHERE id_nativeblogprestashop_category = ' . (int) $parentId
            );
        }
        return true;
    }

    private function getDefaultLanguageValue(array $values)
    {
        $defaultLanguageId = (int) Configuration::get('PS_LANG_DEFAULT');
        $value = isset($values[$defaultLanguageId]) ? $values[$defaultLanguageId] : '';
        if (trim((string) $value) === '') {
            $value = isset($values[(int) $this->context->language->id]) ? $values[(int) $this->context->language->id] : '';
        }
        if (trim((string) $value) === '') {
            foreach ($values as $candidate) {
                if (trim((string) $candidate) !== '') {
                    return trim((string) $candidate);
                }
            }
        }

        return trim((string) $value);
    }

    private function getUniqueSlug($slug, $id)
    {
        $baseSlug = $slug;
        $suffix = 2;
        while ((int) Db::getInstance()->getValue(
            'SELECT id_nativeblogprestashop_category
            FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_category`
            WHERE slug = \'' . pSQL($slug) . '\'
            AND id_nativeblogprestashop_category != ' . (int) $id
        ) > 0) {
            $slug = $baseSlug . '-' . $suffix++;
        }

        return $slug;
    }
}
