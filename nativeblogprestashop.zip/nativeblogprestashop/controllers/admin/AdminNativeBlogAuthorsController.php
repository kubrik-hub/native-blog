<?php
/**
 * Native PrestaShop Blog authors controller.
 *
 * @author Kamel Kelkoul
 * @license https://opensource.org/licenses/OSL-3.0 Open Software License 3.0 (OSL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminNativeBlogAuthorsController extends ModuleAdminController
{
    private const AVATAR_MAX_SIZE = 2097152;

    public function __construct()
    {
        $this->table = 'nativeblogprestashop_author';
        $this->className = '';
        $this->identifier = 'id_nativeblogprestashop_author';
        $this->lang = true;
        $this->bootstrap = true;
        $this->display = 'list';
        parent::__construct();
        $this->meta_title = $this->module->l('Authors', 'AdminNativeBlogAuthorsController');
        $this->module->ensureDatabaseSchema();
    }

    public function initPageHeaderToolbar()
    {
        if ($this->display !== 'edit') {
            $this->page_header_toolbar_btn['new_author'] = [
                'href' => self::$currentIndex . '&token=' . $this->token . '&add' . $this->table,
                'desc' => $this->module->l('Add new author', 'AdminNativeBlogAuthorsController'),
            ];
        }
        parent::initPageHeaderToolbar();
    }

    public function renderList()
    {
        $rows = Db::getInstance()->executeS(
            'SELECT a.id_nativeblogprestashop_author, a.slug, a.avatar, al.firstname, al.lastname
            FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_author` a
            LEFT JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_author_lang` al
                ON al.id_nativeblogprestashop_author = a.id_nativeblogprestashop_author
                AND al.id_lang = ' . (int) $this->context->language->id . '
            INNER JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_author_shop` ash
                ON ash.id_nativeblogprestashop_author = a.id_nativeblogprestashop_author
                AND ash.id_shop = ' . (int) $this->context->shop->id . '
            ORDER BY a.date_upd DESC'
        );
        $this->context->smarty->assign([
            'nativeblogprestashop_authors' => $rows ?: [],
            'nativeblogprestashop_add_url' => self::$currentIndex . '&token=' . $this->token . '&add' . $this->table,
            'nativeblogprestashop_edit_base' => self::$currentIndex . '&token=' . $this->token . '&update' . $this->table . '&' . $this->identifier . '=',
            'nativeblogprestashop_delete_base' => self::$currentIndex . '&token=' . $this->token . '&delete' . $this->table . '&' . $this->identifier . '=',
        ]);

        return $this->context->smarty->fetch($this->module->getLocalPath() . 'views/templates/admin/authors-list.tpl');
    }

    public function renderForm()
    {
        $id = $this->getAuthorId();
        if ($id > 0) {
            $this->fields_value = Db::getInstance()->getRow(
                'SELECT slug, avatar FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_author` WHERE id_nativeblogprestashop_author = ' . $id
            ) ?: [];
            foreach (Db::getInstance()->executeS(
                'SELECT id_lang, firstname, lastname, hobbies FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_author_lang`
                WHERE id_nativeblogprestashop_author = ' . $id
            ) as $row) {
                $languageId = (int) $row['id_lang'];
                $this->fields_value['firstname'][$languageId] = $row['firstname'];
                $this->fields_value['lastname'][$languageId] = $row['lastname'];
                $this->fields_value['hobbies'][$languageId] = $row['hobbies'];
            }
        }

        $avatar = (string) ($this->fields_value['avatar'] ?? '');
        $avatarDescription = '';

        if ($avatar !== '' && $id > 0) {
            $avatarUrl = $this->module->getPathUri()
                . 'upload/authors/'
                . rawurlencode($avatar);

            $deleteUrl = self::$currentIndex
                . '&token=' . rawurlencode($this->token)
                . '&ajax=1&action=DeleteAvatar'
                . '&' . rawurlencode($this->identifier) . '=' . (int) $id;

            $avatarDescription = sprintf(
                '<div id="nativeblog-avatar-preview" style="margin-top:10px">
                    <img src="%s" alt="%s" style="max-width:100px;max-height:100px;vertical-align:middle">
                    <button type="button" id="nativeblog-delete-avatar" data-url="%s"
                        aria-label="%s"
                        style="display:block;padding:0;border:0;background:none;color:#b00;font-size:35px;cursor:pointer">
                        &times;
                    </button>
                    <span id="nativeblog-avatar-message" role="status"></span>
                </div>
                <script>
                (function () {
                    var button = document.getElementById("nativeblog-delete-avatar");
                    if (!button) {
                        return;
                    }

                    button.addEventListener("click", function () {
                        if (!window.confirm("%s")) {
                            return;
                        }

                        button.disabled = true;

                        fetch(button.getAttribute("data-url"), {
                            method: "POST",
                            credentials: "same-origin",
                            headers: { "X-Requested-With": "XMLHttpRequest" }
                        })
                        .then(function (response) {
                            return response.json();
                        })
                        .then(function (result) {
                            if (!result.success) {
                                throw new Error(result.message || "%s");
                            }

                            var preview = document.getElementById("nativeblog-avatar-preview");
                            if (preview) {
                                preview.remove();
                            }
                        })
                        .catch(function (error) {
                            button.disabled = false;
                            var message = document.getElementById("nativeblog-avatar-message");
                            if (message) {
                                message.textContent = error.message;
                                message.style.color = "#b00";
                            }
                        });
                    });
                })();
                </script>',
                htmlspecialchars($avatarUrl, ENT_QUOTES, 'UTF-8'),
                htmlspecialchars($this->module->l('Current avatar'), ENT_QUOTES, 'UTF-8'),
                htmlspecialchars($deleteUrl, ENT_QUOTES, 'UTF-8'),
                htmlspecialchars($this->module->l('Remove avatar'), ENT_QUOTES, 'UTF-8'),
                addslashes($this->module->l('Delete this avatar now?')),
                addslashes($this->module->l('Unable to delete the avatar.'))
            );
        }

        $this->fields_value[$this->identifier] = $id;
        $this->fields_form = [
            'legend' => ['title' => $this->module->l('Author', 'AdminNativeBlogAuthorsController')],
            'enctype' => 'multipart/form-data',
            'input' => [
                ['type' => 'hidden', 'name' => $this->identifier],
                ['type' => 'text', 'label' => $this->module->l('First name'), 'name' => 'firstname', 'lang' => true, 'required' => true],
                ['type' => 'text', 'label' => $this->module->l('Last name'), 'name' => 'lastname', 'lang' => true, 'required' => true],
                ['type' => 'textarea', 'label' => $this->module->l('Hobbies'), 'name' => 'hobbies', 'lang' => true],
                ['type' => 'text', 'label' => $this->module->l('Slug'), 'name' => 'slug', 'desc' => $this->module->l('Optional. Leave empty to generate it from the first and last name. Used in the author page URL.')],
                [
                    'type' => 'file',
                    'label' => $this->module->l('Avatar'),
                    'name' => 'avatar',
                    'desc' => $avatarDescription,
                ],
            ],
            'submit' => ['title' => $this->module->l('Save')],
        ];

        return parent::renderForm();
    }

    public function ajaxProcessDeleteAvatar()
    {
        header('Content-Type: application/json; charset=utf-8');

        $id = $this->getAuthorId();
        if ($id <= 0) {
            $this->ajaxRender(Tools::jsonEncode([
                'success' => false,
                'message' => $this->module->l('The author identifier is missing.'),
            ]));

            return false;
        }

        $avatar = (string) Db::getInstance()->getValue(
            'SELECT avatar FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_author`
            WHERE id_nativeblogprestashop_author = ' . (int) $id
        );

        if ($avatar === '') {
            $this->ajaxRender(Tools::jsonEncode(['success' => true]));

            return false;
        }

        $updated = Db::getInstance()->update(
            'nativeblogprestashop_author',
            ['avatar' => null, 'date_upd' => pSQL(date('Y-m-d H:i:s'))],
            'id_nativeblogprestashop_author = ' . (int) $id
        );

        if (!$updated) {
            $this->ajaxRender(Tools::jsonEncode([
                'success' => false,
                'message' => $this->module->l('Unable to update the author.'),
            ]));

            return false;
        }

        $this->deleteAvatar($avatar);

        $this->ajaxRender(Tools::jsonEncode(['success' => true]));

        return false;
    }

    public function processUpdate()
    {
        if ($this->getAuthorId() <= 0) {
            $this->errors[] = $this->module->l('The author identifier is missing; the author was not updated.');
            return false;
        }
        return $this->saveAuthor();
    }

    public function processAdd()
    {
        return $this->saveAuthor();
    }

    public function processDelete()
    {
        $id = (int) Tools::getValue($this->identifier);
        $shopId = (int) $this->context->shop->id;
        if ($id <= 0 || !(int) Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_author_shop`
            WHERE id_nativeblogprestashop_author = ' . $id . ' AND id_shop = ' . $shopId
        )) {
            $this->errors[] = $this->module->l('The author is not assigned to this shop.');
            return false;
        }

        $shopCount = (int) Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_author_shop`
            WHERE id_nativeblogprestashop_author = ' . $id
        );
        if ($shopCount > 1) {
            return Db::getInstance()->delete(
                'nativeblogprestashop_author_shop',
                'id_nativeblogprestashop_author = ' . $id . ' AND id_shop = ' . $shopId
            );
        }

        if ((int) Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_article`
            WHERE id_nativeblogprestashop_author = ' . $id
        ) > 0) {
            $this->errors[] = $this->module->l('Reassign this author\'s articles before deleting the author.');
            return false;
        }

        $avatar = (string) Db::getInstance()->getValue('SELECT avatar FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_author` WHERE id_nativeblogprestashop_author = ' . $id);
        return Db::getInstance()->delete('nativeblogprestashop_author_lang', 'id_nativeblogprestashop_author = ' . $id)
            && Db::getInstance()->delete('nativeblogprestashop_author_shop', 'id_nativeblogprestashop_author = ' . $id)
            && Db::getInstance()->delete('nativeblogprestashop_author', 'id_nativeblogprestashop_author = ' . $id)
            && $this->deleteAvatar($avatar);
    }

    private function saveAuthor()
    {
        $id = $this->getAuthorId();
        $firstnames = $this->getMultilingualValue('firstname');
        $lastnames = $this->getMultilingualValue('lastname');
        $hobbies = $this->getMultilingualValue('hobbies');
        $firstname = $this->defaultValue($firstnames);
        $lastname = $this->defaultValue($lastnames);
        if ($firstname === '' || $lastname === '') {
            $this->errors[] = $this->module->l('First name and last name are required.');
            return false;
        }
        $slug = Tools::str2url((string) Tools::getValue('slug'));
        if ($slug === '') {
            $slug = Tools::str2url($firstname . ' ' . $lastname);
        }
        if ($slug === '') {
            $this->errors[] = $this->module->l('A valid name or slug is required.');
            return false;
        }
        $slug = $this->getUniqueSlug($slug, $id);
        $oldAvatar = $id > 0 ? (string) Db::getInstance()->getValue('SELECT avatar FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_author` WHERE id_nativeblogprestashop_author = ' . $id) : '';
        $newAvatar = $this->processAvatarUpload();
        if ($newAvatar === false) {
            return false;
        }
        $avatar = $newAvatar !== null ? $newAvatar : $oldAvatar;
        if ($newAvatar === null && Tools::getValue('remove_avatar')) {
            $avatar = '';
        }
        $now = date('Y-m-d H:i:s');
        $data = ['slug' => pSQL($slug), 'avatar' => $avatar !== '' ? pSQL($avatar) : null, 'date_upd' => pSQL($now)];
        if ($id === 0) {
            $data['date_add'] = pSQL($now);
            if (!Db::getInstance()->insert('nativeblogprestashop_author', $data)) {
                return false;
            }
            $id = (int) Db::getInstance()->Insert_ID();
            if (!Db::getInstance()->insert('nativeblogprestashop_author_shop', ['id_nativeblogprestashop_author' => $id, 'id_shop' => (int) $this->context->shop->id])) {
                return false;
            }
        } elseif (!Db::getInstance()->update('nativeblogprestashop_author', $data, 'id_nativeblogprestashop_author = ' . $id)) {
            return false;
        }
        if ($newAvatar !== null && $oldAvatar !== '') {
            $this->deleteAvatar($oldAvatar);
        } elseif ($avatar === '' && $oldAvatar !== '') {
            $this->deleteAvatar($oldAvatar);
        }
        Db::getInstance()->delete('nativeblogprestashop_author_lang', 'id_nativeblogprestashop_author = ' . $id);
        foreach (Language::getLanguages(true) as $language) {
            $languageId = (int) $language['id_lang'];
            if (!Db::getInstance()->insert('nativeblogprestashop_author_lang', [
                'id_nativeblogprestashop_author' => $id,
                'id_lang' => $languageId,
                'firstname' => pSQL(trim((string) ($firstnames[$languageId] ?? $firstname))),
                'lastname' => pSQL(trim((string) ($lastnames[$languageId] ?? $lastname))),
                'hobbies' => pSQL((string) ($hobbies[$languageId] ?? ''), true),
            ])) {
                return false;
            }
        }
        return true;
    }

    private function processAvatarUpload()
    {
        if (!isset($_FILES['avatar']) || (int) $_FILES['avatar']['error'] === UPLOAD_ERR_NO_FILE) {
            return null;
        }
        $file = $_FILES['avatar'];
        $info = @getimagesize($file['tmp_name']);
        $types = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_GIF => 'gif', IMAGETYPE_WEBP => 'webp'];
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = $finfo ? finfo_file($finfo, $file['tmp_name']) : false;
        if ($finfo) {
            finfo_close($finfo);
        }
        $mimes = ['jpg' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif', 'webp' => 'image/webp'];
        if ((int) $file['error'] !== UPLOAD_ERR_OK || (int) $file['size'] > self::AVATAR_MAX_SIZE || !is_array($info) || !isset($types[(int) $info[2]]) || $mime !== $mimes[$types[(int) $info[2]]]) {
            $this->errors[] = $this->module->l('The avatar must be a valid image no larger than 2 MB.');
            return false;
        }
        $dir = $this->module->getLocalPath() . 'upload/authors/';
        if (!is_dir($dir) && !mkdir($dir, 0755, true)) {
            $this->errors[] = $this->module->l('The avatar directory is not available.');
            return false;
        }
        if (!is_writable($dir)) {
            $this->errors[] = $this->module->l('The avatar directory is not writable.');
            return false;
        }
        $filename = bin2hex(random_bytes(16)) . '.' . $types[(int) $info[2]];
        return move_uploaded_file($file['tmp_name'], $dir . $filename) ? $filename : false;
    }

    private function deleteAvatar($filename)
    {
        if ($filename === '' || !preg_match('/^[a-f0-9]{32}\.(jpg|png|gif|webp)$/', $filename)) {
            return true;
        }
        $path = $this->module->getLocalPath() . 'upload/authors/' . $filename;
        return !file_exists($path) || unlink($path);
    }

    private function getMultilingualValue($field)
    {
        $value = Tools::getValue($field);
        $values = is_array($value) ? $value : [];
        foreach (Language::getLanguages(true) as $language) {
            $id = (int) $language['id_lang'];
            $flat = Tools::getValue($field . '_' . $id);
            if ($flat !== false && $flat !== null) {
                $values[$id] = $flat;
            }
        }
        return $values;
    }

    private function defaultValue(array $values)
    {
        foreach ([(int) Configuration::get('PS_LANG_DEFAULT'), (int) $this->context->language->id] as $id) {
            if (!empty($values[$id])) {
                return trim((string) $values[$id]);
            }
        }
        foreach ($values as $value) {
            if (trim((string) $value) !== '') {
                return trim((string) $value);
            }
        }
        return '';
    }

    private function getAuthorId()
    {
        return max((int) Tools::getValue($this->identifier), (int) Tools::getValue('id_' . $this->table));
    }

    private function getUniqueSlug($slug, $id)
    {
        $baseSlug = $slug;
        $suffix = 2;
        while ((int) Db::getInstance()->getValue(
            'SELECT id_nativeblogprestashop_author
            FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_author`
            WHERE slug = \'' . pSQL($slug) . '\'
            AND id_nativeblogprestashop_author != ' . (int) $id
        ) > 0) {
            $slug = $baseSlug . '-' . $suffix++;
        }

        return $slug;
    }
}
