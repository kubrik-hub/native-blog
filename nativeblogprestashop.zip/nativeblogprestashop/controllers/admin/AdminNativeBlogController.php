<?php
/**
 * Native PrestaShop Blog dashboard controller.
 *
 * @author Kamel Kelkoul
 * @license https://opensource.org/licenses/OSL-3.0 Open Software License 3.0 (OSL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminNativeBlogController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
        $this->meta_title = $this->module->l('Blog', 'AdminNativeBlogController');
    }

    public function initContent()
    {
        $this->content = $this->context->smarty->fetch(
            $this->module->getLocalPath() . 'views/templates/admin/dashboard.tpl'
        );
        parent::initContent();
    }
}
