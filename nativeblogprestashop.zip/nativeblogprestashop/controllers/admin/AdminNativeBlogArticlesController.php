<?php
/**
 * Native PrestaShop Blog articles controller.
 *
 * @author Kamel Kelkoul
 * @license https://opensource.org/licenses/OSL-3.0 Open Software License 3.0 (OSL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminNativeBlogArticlesController extends ModuleAdminController
{
    private const COVER_MAX_SIZE = 5242880;
    private const COVER_FIELD = 'cover_image';
    private const COVER_DIRECTORY = 'upload/';

    public function __construct()
    {
        $this->table = 'nativeblogprestashop_article';
        $this->className = '';
        $this->identifier = 'id_nativeblogprestashop_article';
        $this->lang = true;
        $this->bootstrap = true;
        $this->display = 'list';
        parent::__construct();
        $this->meta_title = $this->module->l('Articles', 'AdminNativeBlogArticlesController');
        if (!$this->module->ensureDatabaseSchema()) {
            $error = Db::getInstance()->getMsgError();
            $message = $this->module->l('The article database schema is not ready. Open the module configuration to retry the update.');
            if ($error !== '') {
                $message .= ' ' . $error;
            }
            $this->errors[] = $message;
        }
    }

    public function initPageHeaderToolbar()
    {
        if ($this->display !== 'edit') {
            $this->page_header_toolbar_btn['new_article'] = [
                'href' => self::$currentIndex . '&token=' . $this->token . '&add' . $this->table,
                'desc' => $this->module->l('Add new article', 'AdminNativeBlogArticlesController'),
            ];
        }

        parent::initPageHeaderToolbar();
    }

    public function renderList()
    {
        $articles = Db::getInstance()->executeS(
            'SELECT a.id_nativeblogprestashop_article, a.slug, a.date_upd, al.title, ash.active,
                (SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_comment` c
                 WHERE c.id_nativeblogprestashop_article = a.id_nativeblogprestashop_article
                 AND c.id_shop = ' . (int) $this->context->shop->id . '
                 AND c.approved = 0) AS pending_comments
            FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_article` a
            LEFT JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_article_lang` al
                ON al.id_nativeblogprestashop_article = a.id_nativeblogprestashop_article
                AND al.id_lang = ' . (int) $this->context->language->id . '
            INNER JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_article_shop` ash
                ON ash.id_nativeblogprestashop_article = a.id_nativeblogprestashop_article
                AND ash.id_shop = ' . (int) $this->context->shop->id . '
            ORDER BY a.date_upd DESC'
        );
        $commentsAdminLink = $this->context->link->getAdminLink('AdminNativeBlogComments');
        $articles = $articles ?: [];
        foreach ($articles as &$article) {
            $article['pending_comments'] = (int) $article['pending_comments'];
            $article['comments_url'] = $commentsAdminLink . '&id_nativeblogprestashop_article=' . (int) $article['id_nativeblogprestashop_article'];
        }
        unset($article);
        $this->context->smarty->assign([
            'nativeblogprestashop_articles' => $articles,
            'nativeblogprestashop_add_url' => self::$currentIndex . '&token=' . $this->token . '&add' . $this->table,
            'nativeblogprestashop_edit_base' => self::$currentIndex . '&token=' . $this->token . '&update' . $this->table . '&' . $this->identifier . '=',
            'nativeblogprestashop_delete_base' => self::$currentIndex . '&token=' . $this->token . '&delete' . $this->table . '&' . $this->identifier . '=',
            'nativeblogprestashop_comments_url' => $commentsAdminLink,
        ]);

        return $this->context->smarty->fetch($this->module->getLocalPath() . 'views/templates/admin/articles-list.tpl');
    }

    public function renderForm()
    {
        $id = $this->getArticleId();
        if ($id > 0) {
            $this->fields_value = Db::getInstance()->getRow(
                'SELECT slug, cover_image FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_article`
                WHERE id_nativeblogprestashop_article = ' . $id
            ) ?: [];
            $this->fields_value['id_nativeblogprestashop_category'] = (int) Db::getInstance()->getValue(
                'SELECT id_nativeblogprestashop_category
                FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_article`
                WHERE id_nativeblogprestashop_article = ' . $id
            );
            $this->fields_value['id_nativeblogprestashop_author'] = (int) Db::getInstance()->getValue(
                'SELECT id_nativeblogprestashop_author FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_article`
                WHERE id_nativeblogprestashop_article = ' . $id
            );
            $active = Db::getInstance()->getValue(
                'SELECT active FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_article_shop`
                WHERE id_nativeblogprestashop_article = ' . $id . '
                AND id_shop = ' . (int) $this->context->shop->id
            );
            $this->fields_value['active'] = (bool) $active;
            $translations = Db::getInstance()->executeS(
                'SELECT id_lang, title, excerpt, content
                FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_article_lang`
                WHERE id_nativeblogprestashop_article = ' . $id
            );
            foreach ($translations as $translation) {
                $languageId = (int) $translation['id_lang'];
                $this->fields_value['title'][$languageId] = $translation['title'];
                $this->fields_value['excerpt'][$languageId] = $translation['excerpt'];
                $this->fields_value['content'][$languageId] = $translation['content'];
            }
            $tagRows = Db::getInstance()->executeS(
                'SELECT tl.id_lang, tl.name
                FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_article_tag` at
                INNER JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_tag_lang` tl
                    ON tl.id_nativeblogprestashop_tag = at.id_nativeblogprestashop_tag
                WHERE at.id_nativeblogprestashop_article = ' . $id . '
                ORDER BY tl.name ASC'
            );
            foreach ($tagRows ?: [] as $tagRow) {
                $this->fields_value['tags'][(int) $tagRow['id_lang']][] = $tagRow['name'];
            }
            foreach (($this->fields_value['tags'] ?? []) as $languageId => $tagNames) {
                $this->fields_value['tags'][$languageId] = implode(', ', $tagNames);
            }
        }
        $this->fields_value[$this->identifier] = $id;
        $categories = Db::getInstance()->executeS(
            'SELECT c.id_nativeblogprestashop_category, cl.name
            FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_category` c
            INNER JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_category_lang` cl
                ON cl.id_nativeblogprestashop_category = c.id_nativeblogprestashop_category
                AND cl.id_lang = ' . (int) $this->context->language->id
        );
        $categoryOptions = [];
        foreach ($categories as $category) {
            $categoryOptions[] = [
                'id' => (int) $category['id_nativeblogprestashop_category'],
                'name' => $category['name'],
            ];
        }
        $authorOptions = [];
        foreach (Db::getInstance()->executeS(
            'SELECT a.id_nativeblogprestashop_author, al.firstname, al.lastname
            FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_author` a
            INNER JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_author_lang` al
                ON al.id_nativeblogprestashop_author = a.id_nativeblogprestashop_author
                AND al.id_lang = ' . (int) $this->context->language->id . '
            INNER JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_author_shop` ash
                ON ash.id_nativeblogprestashop_author = a.id_nativeblogprestashop_author
                AND ash.id_shop = ' . (int) $this->context->shop->id . '
            ORDER BY al.lastname, al.firstname'
        ) ?: [] as $author) {
            $authorOptions[] = ['id' => (int) $author['id_nativeblogprestashop_author'], 'name' => trim($author['firstname'] . ' ' . $author['lastname'])];
        }
        $hookProductOptions = Db::getInstance()->executeS(
            'SELECT p.id_product AS id, pl.name
            FROM `' . _DB_PREFIX_ . 'product` p
            INNER JOIN `' . _DB_PREFIX_ . 'product_shop` ps
                ON ps.id_product = p.id_product AND ps.id_shop = ' . (int) $this->context->shop->id . ' AND ps.active = 1
            INNER JOIN `' . _DB_PREFIX_ . 'product_lang` pl
                ON pl.id_product = p.id_product AND pl.id_shop = ' . (int) $this->context->shop->id . '
                AND pl.id_lang = ' . (int) $this->context->language->id . '
            ORDER BY pl.name ASC'
        ) ?: [];
        $productOptions = [['id' => 0, 'name' => $this->module->l('Choose a product')]];
        foreach ($hookProductOptions as $productOption) {
            $productOptions[] = [
                'id' => (int) $productOption['id'],
                'name' => (string) $productOption['name'],
            ];
        }

        $hookToolbar = '<div class="nbps-editor-tools" style="width:83.333333%;max-width:83.333333%;box-sizing:border-box;border:1px solid #ccc;border-radius:2px;background:#fff;padding:16px;margin:0 0 0 5.3rem;">'
            . '<strong style="display:block;margin-bottom:12px;">' . htmlspecialchars($this->module->l('Insert shop products'), ENT_QUOTES, 'UTF-8') . '</strong>'
            . '<div style="display:flex;flex-wrap:wrap;align-items:center;gap:8px;">'
            . '<select class="nbps-hook-type" onchange="window.nbpsUpdateArticleProductPreview(this)">'
            . '<option value="new">' . htmlspecialchars($this->module->l('New products'), ENT_QUOTES, 'UTF-8') . '</option>'
            . '<option value="specials">' . htmlspecialchars($this->module->l('Promotions'), ENT_QUOTES, 'UTF-8') . '</option>'
            . '<option value="bestsellers">' . htmlspecialchars($this->module->l('Best sellers'), ENT_QUOTES, 'UTF-8') . '</option>'
            . '<option value="featured" data-note="' . htmlspecialchars($this->module->l('The Featured products module must be enabled.'), ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars($this->module->l('Featured products'), ENT_QUOTES, 'UTF-8') . '</option>'
            . '<option value="product">' . htmlspecialchars($this->module->l('Specific product'), ENT_QUOTES, 'UTF-8') . '</option>'
            . '</select> '
            . '<label class="nbps-hook-limit-label">' . htmlspecialchars($this->module->l('Number of products'), ENT_QUOTES, 'UTF-8') . ' '
            . '<input class="nbps-hook-limit" type="number" min="1" step="1" value="6" style="width:75px;" onchange="window.nbpsUpdateArticleProductPreview(this)">' 
            . '</label> '
            . '<select class="nbps-hook-product" style="display:none" onchange="window.nbpsUpdateArticleProductPreview(this)">';
        foreach ($productOptions as $productOption) {
            $hookToolbar .= '<option value="' . (int) $productOption['id'] . '">'
                . htmlspecialchars($productOption['name'], ENT_QUOTES, 'UTF-8') . '</option>';
        }
        $hookToolbar .= '</select> '
            . '</div>'
            . '<div style="margin-top:12px;padding-top:12px;border-top:1px solid #ddd;">'
            . '<p class="nbps-hook-explanation" style="margin:0 0 6px;">'
            . 'Copie et colle le code ci-dessous pour afficher '
            . '<strong class="nbps-hook-kind">' . htmlspecialchars($this->module->l('New products'), ENT_QUOTES, 'UTF-8') . '</strong> '
            . "à l'endroit de votre choix dans l'article. "
            . '<span class="nbps-hook-note"></span>'
            . '</p><code class="nbps-hook-code" style="display:inline-block;user-select:all;">[nbps:products type="new" limit="6"]</code>'
            . '</div></div>';
        $hookToolbar .= <<<'HTML'
<script>
window.nbpsUpdateArticleProductPreview = function (control) {
    var tools = control.closest('.nbps-editor-tools');
    var typeSelect = tools.querySelector('.nbps-hook-type');
    var type = typeSelect.value;
    var selectedOption = typeSelect.options[typeSelect.selectedIndex];
    var isProduct = type === 'product';
    var productSelect = tools.querySelector('.nbps-hook-product');
    var productId = parseInt(productSelect.value, 10) || 0;

    productSelect.style.display = isProduct ? '' : 'none';
    tools.querySelector('.nbps-hook-limit-label').style.display = isProduct ? 'none' : '';
    tools.querySelector('.nbps-hook-kind').textContent = isProduct
        ? productSelect.options[productSelect.selectedIndex].textContent
        : selectedOption.textContent;
    tools.querySelector('.nbps-hook-note').textContent = selectedOption.getAttribute('data-note') || '';

    var marker = '';
    if (isProduct && productId > 0) {
        marker = '[nbps:product id="' + productId + '"]';
    } else if (!isProduct) {
        var limit = Math.max(1, parseInt(tools.querySelector('.nbps-hook-limit').value, 10) || 1);
        marker = '[nbps:products type="' + type + '" limit="' + limit + '"]';
    }

    tools.querySelector('.nbps-hook-code').textContent = marker;
};
window.nbpsUpdateArticleProductPreview(document.querySelector('.nbps-editor-tools .nbps-hook-type'));
</script>
HTML;

        $this->fields_form = [
            'legend' => ['title' => $this->module->l('Article', 'AdminNativeBlogArticlesController')],
            'enctype' => 'multipart/form-data',
            'input' => [
                ['type' => 'hidden', 'name' => $this->identifier],
                ['type' => 'text', 'label' => $this->module->l('Title'), 'name' => 'title', 'lang' => true, 'required' => true],
                ['type' => 'text', 'label' => $this->module->l('Tags'), 'name' => 'tags', 'lang' => true, 'desc' => $this->module->l('Optional, comma-separated. Tags are stored per article and language.')],
                ['type' => 'textarea', 'label' => $this->module->l('Excerpt'), 'name' => 'excerpt', 'lang' => true],
                ['type' => 'textarea', 'label' => $this->module->l('Content'), 'name' => 'content', 'lang' => true, 'autoload_rte' => true, 'required' => true],
                ['type' => 'html', 'name' => 'nativeblogprestashop_editor_tools', 'html_content' => $hookToolbar],
                ['type' => 'file', 'label' => $this->module->l('Cover image'), 'name' => self::COVER_FIELD, 'desc' => $this->module->l('Optional JPG, PNG, GIF, or WebP image up to 5 MB.')],
                ['type' => 'select', 'label' => $this->module->l('Category'), 'name' => 'id_nativeblogprestashop_category', 'options' => [
                    'query' => $categoryOptions,
                    'id' => 'id',
                    'name' => 'name',
                ]],
                ['type' => 'select', 'label' => $this->module->l('Author'), 'name' => 'id_nativeblogprestashop_author', 'options' => [
                    'query' => $authorOptions,
                    'id' => 'id',
                    'name' => 'name',
                ]],
                ['type' => 'switch', 'label' => $this->module->l('Active'), 'name' => 'active', 'is_bool' => true, 'values' => [
                    ['id' => 'active_on', 'value' => true, 'label' => $this->module->l('Yes')],
                    ['id' => 'active_off', 'value' => false, 'label' => $this->module->l('No')],
                ]],
            ],
            'submit' => ['title' => $this->module->l('Save')],
        ];

        // The legacy back-office URL may end in /index.php/ on PrestaShop 9.
        // An index.php-relative form action then incorrectly posts to /index.php/index.php.
        $currentIndex = self::$currentIndex;
        self::$currentIndex = __PS_BASE_URI__ . basename(_PS_ADMIN_DIR_) . '/' . ltrim($currentIndex, '/\\');
        try {
            return parent::renderForm();
        } finally {
            self::$currentIndex = $currentIndex;
        }
    }

    public function processAdd()
    {
        return $this->saveArticle();
    }

    public function processUpdate()
    {
        if ($this->getArticleId() <= 0) {
            $this->errors[] = $this->module->l('The article identifier is missing; the article was not updated.');
            return false;
        }

        return $this->saveArticle();
    }

    public function processDelete()
    {
        $id = (int) Tools::getValue($this->identifier);
        $shopId = (int) $this->context->shop->id;
        if ($id <= 0 || !(int) Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_article_shop`
            WHERE id_nativeblogprestashop_article = ' . $id . ' AND id_shop = ' . $shopId
        )) {
            $this->errors[] = $this->module->l('The article is not assigned to this shop.');
            return false;
        }

        $shopCount = (int) Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_article_shop`
            WHERE id_nativeblogprestashop_article = ' . $id
        );
        if ($shopCount > 1) {
            return Db::getInstance()->delete(
                'nativeblogprestashop_article_shop',
                'id_nativeblogprestashop_article = ' . $id . ' AND id_shop = ' . $shopId
            );
        }

        $coverImage = (string) Db::getInstance()->getValue(
            'SELECT cover_image FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_article`
            WHERE id_nativeblogprestashop_article = ' . $id
        );

        $deleted = Db::getInstance()->delete('nativeblogprestashop_comment', 'id_nativeblogprestashop_article = ' . $id)
            && Db::getInstance()->delete('nativeblogprestashop_article_tag', 'id_nativeblogprestashop_article = ' . $id)
            && Db::getInstance()->delete('nativeblogprestashop_article_lang', 'id_nativeblogprestashop_article = ' . $id)
            && Db::getInstance()->delete('nativeblogprestashop_article_shop', 'id_nativeblogprestashop_article = ' . $id)
            && Db::getInstance()->delete('nativeblogprestashop_article', 'id_nativeblogprestashop_article = ' . $id);
        if ($deleted) {
            return $this->deleteCoverImage($coverImage);
        }

        $this->addDatabaseError('article deletion');
        return false;
    }

    private function saveArticle()
    {
        $id = $this->getArticleId();
        $titles = $this->getMultilingualValue('title');
        $excerpts = $this->getMultilingualValue('excerpt');
        $contents = $this->getMultilingualValue('content');
        $tags = $this->getMultilingualValue('tags');
        $title = $this->getDefaultLanguageValue($titles);
        $content = $this->getDefaultLanguageValue($contents);
        if ($title === '' || trim((string) $content) === '') {
            $this->errors[] = $this->module->l('A title and content are required.');
            return false;
        }

        $slug = Tools::str2url($title);
        if ($slug === '') {
            $this->errors[] = $this->module->l('A valid article title is required.');
            return false;
        }
        $slug = $this->getUniqueSlug($slug, $id);
        $oldCoverImage = $id > 0 ? (string) Db::getInstance()->getValue(
            'SELECT cover_image FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_article`
            WHERE id_nativeblogprestashop_article = ' . $id
        ) : '';
        $newCoverImage = $this->processCoverUpload();
        if ($newCoverImage === false) {
            return false;
        }
        $coverImage = $newCoverImage !== null ? $newCoverImage : $oldCoverImage;

        $now = date('Y-m-d H:i:s');
        $categoryId = (int) Tools::getValue('id_nativeblogprestashop_category');
        $authorId = (int) Tools::getValue('id_nativeblogprestashop_author');
        $data = [
            'slug' => pSQL($slug),
            'cover_image' => $coverImage !== '' ? pSQL($coverImage) : null,
            'id_nativeblogprestashop_category' => $categoryId > 0 ? $categoryId : null,
            'id_nativeblogprestashop_author' => $authorId > 0 ? $authorId : null,
            'date_upd' => pSQL($now),
        ];
        if ($id === 0) {
            $data['date_add'] = pSQL($now);
            if (!Db::getInstance()->insert('nativeblogprestashop_article', $data)) {
                if ($newCoverImage !== null) {
                    $this->deleteCoverImage($newCoverImage);
                }
                $this->addDatabaseError('article');
                return false;
            }
            $id = (int) Db::getInstance()->Insert_ID();
        } elseif (!Db::getInstance()->update('nativeblogprestashop_article', $data, 'id_nativeblogprestashop_article = ' . $id)) {
            if ($newCoverImage !== null) {
                $this->deleteCoverImage($newCoverImage);
            }
            $this->addDatabaseError('article');
            return false;
        }
        if ($newCoverImage !== null && $oldCoverImage !== '' && $oldCoverImage !== $newCoverImage) {
            $this->deleteCoverImage($oldCoverImage);
        } elseif ($coverImage === '' && $oldCoverImage !== '') {
            $this->deleteCoverImage($oldCoverImage);
        }

        if (!Db::getInstance()->delete('nativeblogprestashop_article_lang', 'id_nativeblogprestashop_article = ' . $id)) {
            $this->addDatabaseError('article translations');
            return false;
        }
        foreach (Language::getLanguages(true) as $language) {
            $languageId = (int) $language['id_lang'];
            $translatedTitle = trim((string) (isset($titles[$languageId]) ? $titles[$languageId] : $title));
            $translatedExcerpt = isset($excerpts[$languageId]) ? $excerpts[$languageId] : '';
            $translatedContent = isset($contents[$languageId]) ? $contents[$languageId] : $content;

            // Generate author name from selected author if provided
            $authorName = '';
            if ($authorId > 0) {
                $authorName = (string) Db::getInstance()->getValue(
                    'SELECT CONCAT_WS(" ", firstname, lastname) FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_author_lang`
                    WHERE id_nativeblogprestashop_author = ' . $authorId . ' AND id_lang = ' . $languageId
                );
            } else {
                // Preserve existing author if no author selected
                if ($id > 0) {
                    $authorName = (string) Db::getInstance()->getValue(
                        'SELECT author FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_article_lang`
                        WHERE id_nativeblogprestashop_article = ' . $id . ' AND id_lang = ' . $languageId
                    );
                }
            }

            if (!Db::getInstance()->insert('nativeblogprestashop_article_lang', [
                'id_nativeblogprestashop_article' => $id,
                'id_lang' => $languageId,
                'title' => pSQL($translatedTitle),
                'author' => pSQL($authorName),
                'excerpt' => pSQL((string) $translatedExcerpt, true),
                'content' => pSQL(Tools::purifyHTML((string) $translatedContent), true),
            ])) {
                $this->addDatabaseError('article translation');
                return false;
            }
        }

        if (!Db::getInstance()->delete('nativeblogprestashop_article_shop', 'id_nativeblogprestashop_article = ' . $id . ' AND id_shop = ' . (int) $this->context->shop->id)) {
            $this->addDatabaseError('shop assignment');
            return false;
        }

        if (!Db::getInstance()->insert('nativeblogprestashop_article_shop', [
            'id_nativeblogprestashop_article' => $id,
            'id_shop' => (int) $this->context->shop->id,
            'active' => (int) (bool) Tools::getValue('active'),
        ])) {
            $this->addDatabaseError('shop assignment');
            return false;
        }

        if (!$this->saveArticleTags($id, $tags)) {
            return false;
        }

        return true;
    }

    private function saveArticleTags($articleId, array $tags): bool
    {
        if (!Db::getInstance()->delete('nativeblogprestashop_article_tag', 'id_nativeblogprestashop_article = ' . (int) $articleId)) {
            $this->addDatabaseError('article tags');
            return false;
        }
        foreach (Language::getLanguages(true) as $language) {
            $languageId = (int) $language['id_lang'];
            $rawTags = isset($tags[$languageId]) ? explode(',', (string) $tags[$languageId]) : [];
            foreach ($rawTags as $rawTag) {
                $name = trim($rawTag);
                if ($name === '' || Tools::strlen($name) > 255) {
                    continue;
                }
                $tagSlug = Tools::str2url($name);
                if ($tagSlug === '') {
                    continue;
                }
                $tagId = (int) Db::getInstance()->getValue(
                    'SELECT id_nativeblogprestashop_tag FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_tag`
                    WHERE slug = "' . pSQL($tagSlug) . '"'
                );
                if ($tagId <= 0) {
                    if (!Db::getInstance()->insert('nativeblogprestashop_tag', ['slug' => pSQL($tagSlug)])) {
                        $this->addDatabaseError('tag');
                        return false;
                    }
                    $tagId = (int) Db::getInstance()->Insert_ID();
                }
                $existingTagLanguage = (int) Db::getInstance()->getValue(
                    'SELECT id_nativeblogprestashop_tag FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_tag_lang`
                    WHERE id_nativeblogprestashop_tag = ' . $tagId . ' AND id_lang = ' . $languageId
                );
                if ($existingTagLanguage > 0) {
                    if (!Db::getInstance()->update(
                        'nativeblogprestashop_tag_lang',
                        ['name' => pSQL($name)],
                        'id_nativeblogprestashop_tag = ' . $tagId . ' AND id_lang = ' . $languageId
                    )) {
                        $this->addDatabaseError('tag translation update');
                        return false;
                    }
                } elseif (!Db::getInstance()->insert(
                    'nativeblogprestashop_tag_lang',
                    ['id_nativeblogprestashop_tag' => $tagId, 'id_lang' => $languageId, 'name' => pSQL($name)]
                )) {
                    $this->addDatabaseError('tag translation');
                    return false;
                }
                if (!(int) Db::getInstance()->getValue(
                    'SELECT id_nativeblogprestashop_tag FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_article_tag`
                    WHERE id_nativeblogprestashop_article = ' . (int) $articleId . ' AND id_nativeblogprestashop_tag = ' . $tagId
                ) && !Db::getInstance()->insert('nativeblogprestashop_article_tag', [
                    'id_nativeblogprestashop_article' => (int) $articleId,
                    'id_nativeblogprestashop_tag' => $tagId,
                ])) {
                    $this->addDatabaseError('article tag relation');
                    return false;
                }
            }
        }

        return true;
    }

    private function getMultilingualValue($field)
    {
        $value = Tools::getValue($field);
        $values = is_array($value) ? $value : [];

        foreach (Language::getLanguages(true) as $language) {
            $languageId = (int) $language['id_lang'];
            $languageValue = Tools::getValue($field . '_' . $languageId);
            if ($languageValue !== false && $languageValue !== null) {
                $values[$languageId] = $languageValue;
            }
        }

        if (!is_array($value) && $value !== false && $value !== null && $value !== '') {
            $values[(int) $this->context->language->id] = $value;
        }

        return $values;
    }

    private function getArticleId()
    {
        $id = (int) Tools::getValue($this->identifier);
        if ($id <= 0) {
            $id = (int) Tools::getValue('id_' . $this->table);
        }

        return $id;
    }

    private function getDefaultLanguageValue(array $values)
    {
        $defaultLanguageId = (int) Configuration::get('PS_LANG_DEFAULT');
        $value = isset($values[$defaultLanguageId]) ? $values[$defaultLanguageId] : '';
        if (trim((string) $value) === '') {
            $value = isset($values[(int) $this->context->language->id]) ? $values[(int) $this->context->language->id] : '';
        }
        if (trim((string) $value) === '') {
            foreach ($values as $candidate) {
                if (trim((string) $candidate) !== '') {
                    return trim((string) $candidate);
                }
            }
        }

        return trim((string) $value);
    }

    private function getUniqueSlug($slug, $id)
    {
        $baseSlug = $slug;
        $suffix = 2;
        while ((int) Db::getInstance()->getValue(
            'SELECT id_nativeblogprestashop_article
            FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_article`
            WHERE slug = \'' . pSQL($slug) . '\'
            AND id_nativeblogprestashop_article != ' . (int) $id
        ) > 0) {
            $slug = $baseSlug . '-' . $suffix++;
        }

        return $slug;
    }

    private function processCoverUpload()
    {
        if (!isset($_FILES[self::COVER_FIELD]) || !is_array($_FILES[self::COVER_FIELD])) {
            return null;
        }
        $file = $_FILES[self::COVER_FIELD];
        if ((int) $file['error'] === UPLOAD_ERR_NO_FILE) {
            return null;
        }
        if ((int) $file['error'] !== UPLOAD_ERR_OK || !isset($file['tmp_name'], $file['name'], $file['size']) || (int) $file['size'] > self::COVER_MAX_SIZE) {
            $this->errors[] = $this->module->l('The cover image must be a valid image no larger than 5 MB.');
            return false;
        }
        $extension = Tools::strtolower((string) pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($extension, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
            $this->errors[] = $this->module->l('The cover image must be a JPG, PNG, GIF, or WebP image.');
            return false;
        }
        $imageInfo = @getimagesize($file['tmp_name']);
        $mimeTypes = [
            IMAGETYPE_JPEG => ['mime' => 'image/jpeg', 'extension' => 'jpg'],
            IMAGETYPE_PNG => ['mime' => 'image/png', 'extension' => 'png'],
            IMAGETYPE_GIF => ['mime' => 'image/gif', 'extension' => 'gif'],
            IMAGETYPE_WEBP => ['mime' => 'image/webp', 'extension' => 'webp'],
        ];
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $detectedMime = $finfo ? finfo_file($finfo, $file['tmp_name']) : false;
        if ($finfo) {
            finfo_close($finfo);
        }
        if (!is_array($imageInfo) || !isset($mimeTypes[(int) $imageInfo[2]]) || (string) $imageInfo['mime'] !== $mimeTypes[(int) $imageInfo[2]]['mime'] || $detectedMime !== $mimeTypes[(int) $imageInfo[2]]['mime']) {
            $this->errors[] = $this->module->l('The cover image must be a valid JPG, PNG, GIF, or WebP image.');
            return false;
        }
        try {
            $filename = bin2hex(random_bytes(16)) . '.' . $mimeTypes[(int) $imageInfo[2]]['extension'];
        } catch (Exception $exception) {
            $this->errors[] = $this->module->l('The cover image could not be stored securely.');
            return false;
        }
        $directory = $this->module->getLocalPath() . self::COVER_DIRECTORY;
        if (!is_dir($directory) && !mkdir($directory, 0755, true)) {
            $this->errors[] = $this->module->l('The cover image directory is not available.');
            return false;
        }
        if (!is_writable($directory)) {
            $this->errors[] = $this->module->l('The cover image directory is not writable.');
            return false;
        }
        if (!move_uploaded_file($file['tmp_name'], $directory . $filename)) {
            $this->errors[] = $this->module->l('The cover image could not be saved.');
            return false;
        }

        return $filename;
    }

    private function deleteCoverImage($filename)
    {
        if ($filename === '' || !preg_match('/^[a-f0-9]{32}\.(jpg|png|gif|webp)$/', $filename)) {
            return true;
        }
        $path = $this->module->getLocalPath() . self::COVER_DIRECTORY . $filename;

        return !file_exists($path) || unlink($path);
    }

    private function addDatabaseError($operation)
    {
        $error = Db::getInstance()->getMsgError();
        $message = $this->module->l('The article could not be saved while updating the ') . $operation . '.';
        if ($error !== '') {
            $message .= ' ' . $error;
        }
        $this->errors[] = $message;
    }

}
