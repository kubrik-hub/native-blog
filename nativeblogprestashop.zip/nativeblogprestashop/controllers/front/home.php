<?php
/**
 * Native PrestaShop Blog front controller.
 *
 * @author Kamel Kelkoul
 * @license https://opensource.org/licenses/OSL-3.0 Open Software License 3.0 (OSL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class NativeBlogPrestaShopHomeModuleFrontController extends ModuleFrontController
{
    private const ARTICLES_PER_PAGE = 12;

    public function initContent(): void
    {
        parent::initContent();
        $categorySchemaReady = $this->module->ensureDatabaseSchema();

        $idLang = (int) $this->context->language->id;
        $idShop = (int) $this->context->shop->id;
        $authorId = (int) Tools::getValue('author');
        $categoryPath = trim((string) Tools::getValue('category_path', ''), '/');
        $categoryId = (int) Tools::getValue('category');
        if ($categoryPath !== '') {
            $categoryId = $this->module->getCategoryIdFromPath($categoryPath, $idShop);
            if ($categoryId <= 0) {
                Tools::redirect($this->context->link->getModuleLink($this->module->name, 'home'));

                return;
            }
        }
        $defaultLanguageId = (int) Configuration::get('PS_LANG_DEFAULT');
        $blogTitle = '';
        foreach ([
            Configuration::get('NBPS_TITLE', $idLang, null, $idShop),
            Configuration::get('NBPS_TITLE_' . $idLang, null, null, $idShop),
            Configuration::get('NBPS_TITLE', $defaultLanguageId, null, $idShop),
            Configuration::get('NBPS_TITLE_' . $defaultLanguageId, null, null, $idShop),
            Configuration::get('NBPS_TITLE', null, null, $idShop),
            Configuration::get('NBPS_TITLE'),
        ] as $configuredBlogTitle) {
            if (is_array($configuredBlogTitle)) {
                $configuredBlogTitle = $configuredBlogTitle[$idLang]
                    ?? $configuredBlogTitle[$defaultLanguageId]
                    ?? '';
            }
            $configuredBlogTitle = trim((string) $configuredBlogTitle);
            if ($configuredBlogTitle !== '') {
                $blogTitle = $configuredBlogTitle;
                break;
            }
        }
        if ($blogTitle === '') {
            $blogTitle = 'Blog';
        }
        $categoryTitle = '';
        $categoryTrail = [];
        if ($categoryId > 0 && $categorySchemaReady) {
            $currentCategoryId = $categoryId;
            $visitedCategoryIds = [];
            while ($currentCategoryId > 0 && !isset($visitedCategoryIds[$currentCategoryId])) {
                $visitedCategoryIds[$currentCategoryId] = true;
                $category = Db::getInstance()->getRow(
                    'SELECT c.id_parent,
                        COALESCE(NULLIF(current_lang.name, ""), default_lang.name) AS name
                    FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_category` c
                    INNER JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_category_shop` cs
                        ON cs.id_nativeblogprestashop_category = c.id_nativeblogprestashop_category
                        AND cs.id_shop = ' . $idShop . ' AND cs.active = 1
                    LEFT JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_category_lang` current_lang
                        ON current_lang.id_nativeblogprestashop_category = c.id_nativeblogprestashop_category
                        AND current_lang.id_lang = ' . $idLang . '
                    LEFT JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_category_lang` default_lang
                        ON default_lang.id_nativeblogprestashop_category = c.id_nativeblogprestashop_category
                        AND default_lang.id_lang = ' . (int) Configuration::get('PS_LANG_DEFAULT') . '
                    WHERE c.id_nativeblogprestashop_category = ' . $currentCategoryId
                );
                if (!$category) {
                    break;
                }
                $categoryTrail[] = [
                    'id' => $currentCategoryId,
                    'title' => (string) $category['name'],
                ];
                $currentCategoryId = (int) $category['id_parent'];
            }
            $categoryTrail = array_reverse($categoryTrail);
            if ($categoryTrail) {
                $categoryTitle = (string) $categoryTrail[count($categoryTrail) - 1]['title'];
            }
        }
        $pageTitle = $categoryTitle !== '' ? $categoryTitle : $blogTitle;
        $pageId = $categoryTitle !== ''
            ? 'nativeblogprestashop-category'
            : 'nativeblogprestashop-home';
        $filters = '';
        if ($authorId > 0) {
            $filters .= ' AND a.id_nativeblogprestashop_author = ' . $authorId;
        }
        if ($categoryId > 0) {
            $filters .= ' AND a.id_nativeblogprestashop_category = ' . $categoryId;
        }

        $totalArticles = (int) Db::getInstance()->getValue(
            'SELECT COUNT(DISTINCT a.id_nativeblogprestashop_article)
            FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_article` a
            INNER JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_article_lang` al
                ON al.id_nativeblogprestashop_article = a.id_nativeblogprestashop_article
                AND al.id_lang = ' . $idLang . '
            INNER JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_article_shop` ash
                ON ash.id_nativeblogprestashop_article = a.id_nativeblogprestashop_article
                AND ash.id_shop = ' . $idShop . '
                AND ash.active = 1
                AND (ash.date_publish IS NULL OR ash.date_publish <= NOW())
            WHERE 1 ' . $filters
        );
        $totalPages = max(1, (int) ceil($totalArticles / self::ARTICLES_PER_PAGE));
        $page = max(1, min($totalPages, (int) Tools::getValue('page', 1)));
        $offset = ($page - 1) * self::ARTICLES_PER_PAGE;

        $articles = Db::getInstance()->executeS(
            'SELECT a.id_nativeblogprestashop_article, a.id_nativeblogprestashop_author, a.id_nativeblogprestashop_category,
                a.slug, a.cover_image, a.date_add, al.title,
                COALESCE(NULLIF(CONCAT_WS(" ", au.firstname, au.lastname), ""), al.author) AS author,
                au_base.avatar AS author_avatar, au_base.slug AS author_slug, al.excerpt,
                ash.date_publish, cl.name AS category_name,
                COUNT(DISTINCT CASE WHEN c.approved = 1 THEN c.id_nativeblogprestashop_comment END) AS comment_count,
                COALESCE(AVG(CASE WHEN c.approved = 1 THEN c.grade END), 0) AS average_grade
            FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_article` a
            INNER JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_article_lang` al
                ON al.id_nativeblogprestashop_article = a.id_nativeblogprestashop_article
                AND al.id_lang = ' . $idLang . '
            INNER JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_article_shop` ash
                ON ash.id_nativeblogprestashop_article = a.id_nativeblogprestashop_article
                AND ash.id_shop = ' . $idShop . '
                AND ash.active = 1
                AND (ash.date_publish IS NULL OR ash.date_publish <= NOW())
            LEFT JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_category_lang` cl
                ON cl.id_nativeblogprestashop_category = a.id_nativeblogprestashop_category
                AND cl.id_lang = ' . $idLang . '
            LEFT JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_author_lang` au
                ON au.id_nativeblogprestashop_author = a.id_nativeblogprestashop_author
                AND au.id_lang = ' . $idLang . '
            LEFT JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_author` au_base
                ON au_base.id_nativeblogprestashop_author = a.id_nativeblogprestashop_author
            LEFT JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_comment` c
                ON c.id_nativeblogprestashop_article = a.id_nativeblogprestashop_article
                AND c.id_shop = ' . $idShop . '
            WHERE 1 ' . $filters . '
            GROUP BY a.id_nativeblogprestashop_article, a.id_nativeblogprestashop_author, a.id_nativeblogprestashop_category,
                a.slug, a.cover_image, a.date_add, al.title, al.author,
                au.firstname, au.lastname, au_base.avatar, au_base.slug, al.excerpt, ash.date_publish, cl.name
            ORDER BY COALESCE(ash.date_publish, a.date_add) DESC
            LIMIT ' . self::ARTICLES_PER_PAGE . ' OFFSET ' . $offset
        );
        foreach ($articles as &$article) {
            $article['link'] = $this->context->link->getModuleLink(
                $this->module->name,
                'article',
                ['slug' => $article['slug']]
            );
            $article['average_grade'] = round((float) $article['average_grade'], 1);
            $article['comment_count'] = (int) $article['comment_count'];
            $article['author_id'] = (int) $article['id_nativeblogprestashop_author'];
            $article['category_id'] = (int) $article['id_nativeblogprestashop_category'];
            $article['author'] = trim((string) $article['author']);
            $article['author_display'] = $article['author'] !== ''
                ? $article['author']
                : $this->module->l('Unknown author', 'home');
            $publicationTimestamp = strtotime((string) ($article['date_publish'] ?: $article['date_add']));
            $article['publication_date'] = $publicationTimestamp !== false
                ? date('Y-m-d', $publicationTimestamp)
                : '';
            $article['author_url'] = $article['author_id'] > 0 && (string) $article['author_slug'] !== ''
                ? $this->context->link->getModuleLink($this->module->name, 'author', ['slug' => $article['author_slug']])
                : '';
            $article['category_url'] = $article['category_id'] > 0
                ? $this->module->getCategoryLink($article['category_id'])
                : '';
            $article['cover_url'] = preg_match('/^[a-f0-9]{32}\.(jpg|png|gif|webp)$/', (string) $article['cover_image'])
                && is_file($this->module->getLocalPath() . 'upload/' . $article['cover_image'])
                ? __PS_BASE_URI__ . 'modules/' . $this->module->name . '/upload/' . $article['cover_image']
                : '';
            $article['author_avatar_url'] = preg_match('/^[a-f0-9]{32}\.(jpg|png|gif|webp)$/', (string) $article['author_avatar'])
                && is_file($this->module->getLocalPath() . 'upload/authors/' . $article['author_avatar'])
                ? __PS_BASE_URI__ . 'modules/' . $this->module->name . '/upload/authors/' . $article['author_avatar']
                : '';
        }
        unset($article);

        $baseLinkParams = [];
        if ($authorId > 0) {
            $baseLinkParams['author'] = $authorId;
        }
        if ($categoryId > 0) {
            $baseLinkParams['category'] = $categoryId;
        }
        $pageLink = function (int $targetPage) use ($baseLinkParams, $categoryPath, $authorId, $idShop, $idLang): string {
            $params = $baseLinkParams;
            if ($targetPage > 1) {
                $params['page'] = $targetPage;
            }

            if ($categoryPath !== '') {
                $params = ['category_path' => $categoryPath];
                if ($authorId > 0) {
                    $params['author'] = $authorId;
                }
                if ($targetPage > 1) {
                    $params['page'] = $targetPage;
                }

                return $this->context->link->getPageLink(
                    'module-' . $this->module->name . '-category',
                    null,
                    $idLang,
                    $params,
                    false,
                    $idShop
                );
            }

            return $this->context->link->getModuleLink($this->module->name, 'home', $params);
        };

        $breadcrumbLinks = [
            ['title' => $this->l('Home'), 'url' => $this->context->link->getPageLink('index')],
            ['title' => 'Blog', 'url' => $this->context->link->getModuleLink($this->module->name, 'home')],
        ];
        foreach ($categoryTrail as $category) {
            if ($category['title'] === '') {
                continue;
            }
            $breadcrumbLinks[] = [
                'title' => $category['title'],
                'url' => $this->module->getCategoryLink((int) $category['id']),
            ];
        }

        $this->context->smarty->assign([
            'nativeblogprestashop_title' => $pageTitle,
            'nativeblogprestashop_comments_enabled' => $this->module->isCommentsEnabled(),
            'nativeblogprestashop_page_id' => $pageId,
            'nativeblogprestashop_articles' => $articles,
            'nativeblogprestashop_pagination' => [
                'current_page' => $page,
                'total_pages' => $totalPages,
                'has_previous' => $page > 1,
                'has_next' => $page < $totalPages,
                'previous_url' => $page > 1 ? $pageLink($page - 1) : '',
                'next_url' => $page < $totalPages ? $pageLink($page + 1) : '',
            ],
            'breadcrumb' => ['count' => count($breadcrumbLinks), 'links' => $breadcrumbLinks],
        ]);
        if (method_exists($this, 'setPageTitle')) {
            $this->setPageTitle($pageTitle);
        }
        $this->setTemplate('module:nativeblogprestashop/views/templates/front/home.tpl');
    }
}
