<?php
/**
 * Native PrestaShop Blog article controller.
 *
 * @author Kamel Kelkoul
 * @license https://opensource.org/licenses/OSL-3.0 Open Software License 3.0 (OSL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class NativeBlogPrestaShopArticleModuleFrontController extends ModuleFrontController
{
    private const COMMENTS_PER_PAGE = 5;

    public function initContent(): void
    {
        parent::initContent();
        $this->module->ensureDatabaseSchema();
        $commentsEnabled = $this->module->isCommentsEnabled();
        if ($commentsEnabled && Tools::isSubmit('submitNativeBlogComment')) {
            $this->processComment();
        }
        $slug = Tools::str2url((string) Tools::getValue('slug'));
        $idLang = (int) $this->context->language->id;
        $idShop = (int) $this->context->shop->id;
        $articleTable = _DB_PREFIX_ . 'nativeblogprestashop_article';
        $langTable = _DB_PREFIX_ . 'nativeblogprestashop_article_lang';
        $shopTable = _DB_PREFIX_ . 'nativeblogprestashop_article_shop';
        $article = Db::getInstance()->getRow(
            'SELECT a.*, al.title, COALESCE(NULLIF(CONCAT_WS(" ", au.firstname, au.lastname), ""), al.author) AS author,
                au_base.avatar AS author_avatar, au_base.slug AS author_slug, al.excerpt, al.content, al.meta_title, al.meta_description,
                ash.date_publish, cl.name AS category_name
            FROM `' . bqSQL($articleTable) . '` a
            INNER JOIN `' . bqSQL($langTable) . '` al
                ON al.id_nativeblogprestashop_article = a.id_nativeblogprestashop_article
                AND al.id_lang = ' . $idLang . '
            INNER JOIN `' . bqSQL($shopTable) . '` ash
                ON ash.id_nativeblogprestashop_article = a.id_nativeblogprestashop_article
                AND ash.id_shop = ' . $idShop . '
                AND ash.active = 1
                AND (ash.date_publish IS NULL OR ash.date_publish <= NOW())
            LEFT JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_category_lang` cl
                ON cl.id_nativeblogprestashop_category = a.id_nativeblogprestashop_category
                AND cl.id_lang = ' . $idLang . '
            LEFT JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_author_lang` au
                ON au.id_nativeblogprestashop_author = a.id_nativeblogprestashop_author
                AND au.id_lang = ' . $idLang . '
            LEFT JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_author` au_base
                ON au_base.id_nativeblogprestashop_author = a.id_nativeblogprestashop_author
            WHERE a.slug = \'' . pSQL($slug) . '\''
        );

        if (!$article) {
            Tools::redirect('index.php');
        }
        $publicationTimestamp = strtotime((string) ($article['date_publish'] ?: $article['date_add']));
        $article['publication_date'] = $publicationTimestamp !== false
            ? date('Y-m-d', $publicationTimestamp)
            : '';
        $article['content'] = $this->renderArticleProductMarkers((string) $article['content']);
        $article['cover_url'] = preg_match('/^[a-f0-9]{32}\.(jpg|png|gif|webp)$/', (string) $article['cover_image'])
            && is_file($this->module->getLocalPath() . 'upload/' . $article['cover_image'])
            ? __PS_BASE_URI__ . 'modules/' . $this->module->name . '/upload/' . $article['cover_image']
            : '';
        $article['author_avatar_url'] = preg_match('/^[a-f0-9]{32}\.(jpg|png|gif|webp)$/', (string) $article['author_avatar'])
            && is_file($this->module->getLocalPath() . 'upload/authors/' . $article['author_avatar'])
            ? __PS_BASE_URI__ . 'modules/' . $this->module->name . '/upload/authors/' . $article['author_avatar']
            : '';
        $article['author_id'] = (int) $article['id_nativeblogprestashop_author'];
        $article['category_id'] = (int) $article['id_nativeblogprestashop_category'];
        $article['author_url'] = $article['author_id'] > 0 && (string) $article['author_slug'] !== ''
            ? $this->context->link->getModuleLink($this->module->name, 'author', ['slug' => $article['author_slug']])
            : '';
        $article['category_url'] = $article['category_id'] > 0
            ? $this->module->getCategoryLink($article['category_id'])
            : '';
        $article['tags'] = Db::getInstance()->executeS(
            'SELECT tl.name
            FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_article_tag` at
            INNER JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_tag_lang` tl
                ON tl.id_nativeblogprestashop_tag = at.id_nativeblogprestashop_tag
                AND tl.id_lang = ' . $idLang . '
            WHERE at.id_nativeblogprestashop_article = ' . (int) $article['id_nativeblogprestashop_article'] . '
            ORDER BY tl.name ASC'
        ) ?: [];
        $pageTitle = trim((string) $article['meta_title']) !== '' ? $article['meta_title'] : $article['title'];
        if (method_exists($this, 'setPageTitle')) {
            $this->setPageTitle((string) $pageTitle);
        }
        if (method_exists($this, 'addMetaDescription') && trim((string) $article['meta_description']) !== '') {
            $this->addMetaDescription((string) $article['meta_description']);
        }
        $article['canonical_url'] = $this->context->link->getModuleLink(
            $this->module->name,
            'article',
            ['slug' => $article['slug']]
        );
        $blogUrl = $this->context->link->getModuleLink($this->module->name, 'home');
        $breadcrumbLinks = [
            ['title' => $this->l('Home'), 'url' => $this->context->link->getPageLink('index')],
            ['title' => 'Blog', 'url' => $blogUrl],
        ];
        if ((int) $article['category_id'] > 0 && (string) $article['category_name'] !== '') {
            $breadcrumbLinks[] = [
                'title' => $article['category_name'],
                'url' => $this->module->getCategoryLink((int) $article['category_id']),
            ];
        }
        $breadcrumbLinks[] = ['title' => $article['title'], 'url' => $article['canonical_url']];

        $articleId = (int) $article['id_nativeblogprestashop_article'];
        $commentCount = (int) Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_comment`
            WHERE id_nativeblogprestashop_article = ' . $articleId . '
            AND id_shop = ' . $idShop . ' AND approved = 1'
        );
        $averageGrade = (float) Db::getInstance()->getValue(
            'SELECT AVG(grade) FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_comment`
            WHERE id_nativeblogprestashop_article = ' . $articleId . '
            AND id_shop = ' . $idShop . ' AND approved = 1'
        );
        $averageGrade = round($averageGrade, 1);
        $article['comment_count'] = $commentCount;
        $article['average_grade'] = $averageGrade;

        $totalCommentPages = max(1, (int) ceil($commentCount / self::COMMENTS_PER_PAGE));
        $commentPage = max(1, min($totalCommentPages, (int) Tools::getValue('comment_page', 1)));
        $commentOffset = ($commentPage - 1) * self::COMMENTS_PER_PAGE;
        $comments = Db::getInstance()->executeS(
            'SELECT id_nativeblogprestashop_comment, author_name, title, content, grade, date_add
            FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_comment`
            WHERE id_nativeblogprestashop_article = ' . $articleId . '
            AND id_shop = ' . $idShop . ' AND approved = 1
            ORDER BY date_add DESC
            LIMIT ' . self::COMMENTS_PER_PAGE . ' OFFSET ' . $commentOffset
        ) ?: [];
        $commentPageLink = function (int $targetPage) use ($article): string {
            $params = ['slug' => $article['slug']];
            if ($targetPage > 1) {
                $params['comment_page'] = $targetPage;
            }

            return $this->context->link->getModuleLink($this->module->name, 'article', $params) . '#nativeblog-comments-title';
        };
        $this->context->smarty->assign([
            'nativeblogprestashop_article' => $article,
            'nativeblogprestashop_comments_enabled' => $commentsEnabled,
            'nativeblogprestashop_comments' => $comments,
            'nativeblogprestashop_average_grade' => $averageGrade,
            'nativeblogprestashop_comment_token' => Tools::getToken(false),
            'nativeblogprestashop_comment_error' => $this->context->cookie->__get('nativeblog_comment_error'),
            'nativeblogprestashop_comment_success' => $this->context->cookie->__get('nativeblog_comment_success'),
            'nativeblogprestashop_comment_pagination' => [
                'current_page' => $commentPage,
                'total_pages' => $totalCommentPages,
                'has_previous' => $commentPage > 1,
                'has_next' => $commentPage < $totalCommentPages,
                'previous_url' => $commentPage > 1 ? $commentPageLink($commentPage - 1) : '',
                'next_url' => $commentPage < $totalCommentPages ? $commentPageLink($commentPage + 1) : '',
            ],
            'breadcrumb' => ['count' => count($breadcrumbLinks), 'links' => $breadcrumbLinks],
        ]);
        $this->context->cookie->__unset('nativeblog_comment_error');
        $this->context->cookie->__unset('nativeblog_comment_success');
        $this->setTemplate('module:nativeblogprestashop/views/templates/front/article.tpl');
    }

    private function processComment()
    {
        if (!$this->module->isCommentsEnabled()) {
            return;
        }

        $token = (string) Tools::getValue('nativeblog_comment_token');
        if ($token === '' || !hash_equals((string) Tools::getToken(false), $token)) {
            return $this->setCommentMessage($this->module->l('Invalid security token.', 'article'));
        }
        // Honeypot: a hidden field that must stay empty for a genuine human submission.
        if (trim((string) Tools::getValue('nativeblog_website')) !== '') {
            $this->context->cookie->__set('nativeblog_comment_success', 'Your review was submitted for moderation.');
            $slug = Tools::str2url((string) Tools::getValue('slug'));
            Tools::redirect($this->context->link->getModuleLink($this->module->name, 'article', ['slug' => $slug]));
        }
        $title = trim((string) Tools::getValue('comment_title'));
        $content = trim((string) Tools::getValue('comment_content'));
        $name = trim((string) Tools::getValue('customer_name'));
        $email = trim((string) Tools::getValue('customer_email'));
        $grade = (int) Tools::getValue('criterion');
        if ($this->context->customer->isLogged()) {
            $name = trim((string) $this->context->customer->firstname . ' ' . $this->context->customer->lastname);
            $email = (string) $this->context->customer->email;
        }
        if ($name === '' || Tools::strlen($name) > 64 || $title === '' || Tools::strlen($title) > 64 || $content === '' || Tools::strlen($content) > 5000 || !Validate::isEmail($email) || $grade < 1 || $grade > 5) {
            return $this->setCommentMessage($this->module->l('Please provide a valid name, email, title, review, and rating.', 'article'));
        }
        $slug = Tools::str2url((string) Tools::getValue('slug'));
        $articleId = (int) Db::getInstance()->getValue(
            'SELECT id_nativeblogprestashop_article FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_article`
            WHERE slug = "' . pSQL($slug) . '"'
        );
        if ($articleId <= 0) {
            return $this->setCommentMessage($this->module->l('The article could not be found.', 'article'));
        }
        $guestHash = hash('sha256', ($this->context->customer->isLogged() ? 'customer:' . (int) $this->context->customer->id : 'guest:' . (string) $this->context->cookie->id_guest) . '|' . (int) $this->context->shop->id);
        if ((int) Db::getInstance()->getValue(
            'SELECT id_nativeblogprestashop_comment FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_comment`
            WHERE id_nativeblogprestashop_article = ' . $articleId . ' AND id_shop = ' . (int) $this->context->shop->id . ' AND guest_hash = "' . pSQL($guestHash) . '"'
        )) {
            return $this->setCommentMessage($this->module->l('You have already reviewed this article.', 'article'));
        }
        $approved = 0;
        if (!Db::getInstance()->insert('nativeblogprestashop_comment', [
            'id_nativeblogprestashop_article' => $articleId,
            'id_shop' => (int) $this->context->shop->id,
            'id_customer' => $this->context->customer->isLogged() ? (int) $this->context->customer->id : null,
            'guest_hash' => pSQL($guestHash),
            'author_name' => pSQL($name),
            'author_email' => pSQL($email),
            'title' => pSQL($title),
            'content' => pSQL($content, true),
            'grade' => $grade,
            'approved' => $approved,
            'date_add' => date('Y-m-d H:i:s'),
        ])) {
            return $this->setCommentMessage($this->module->l('Your review could not be submitted.', 'article'));
        }
        $this->context->cookie->__set('nativeblog_comment_success', 'Your review was submitted for moderation.');
        Tools::redirect($this->context->link->getModuleLink($this->module->name, 'article', ['slug' => $slug]));
    }

    private function setCommentMessage($message)
    {
        $this->context->cookie->__set('nativeblog_comment_error', $message);
    }

    private function renderArticleProductMarkers(string $content): string
    {
        $rendered = preg_replace_callback(
            '~(?:<p(?:\s[^>]*)?>\s*)?\[nbps:products\s+type="(new|specials|bestsellers|featured)"\s+limit="([1-9][0-9]*)"\](?:\s*</p>)?~i',
            function (array $matches): string {
                return $this->renderArticleProductBlock($matches[1], (int) $matches[2]);
            },
            $content
        );
        if ($rendered === null) {
            return $content;
        }

        $rendered = preg_replace_callback(
            '~(?:<p(?:\s[^>]*)?>\s*)?\[nbps:product\s+id="([1-9][0-9]*)"\](?:\s*</p>)?~i',
            function (array $matches): string {
                return $this->renderArticleProductBlock('product', 1, (int) $matches[1]);
            },
            $rendered
        );

        return $rendered === null ? $content : $rendered;
    }

    private function renderArticleProductBlock(string $type, int $limit, int $productId = 0): string
    {
        $limit = max(1, $limit);
        $products = [];
        $idLang = (int) $this->context->language->id;
        $rawProducts = [];

        if ($type === 'featured') {
            if (!Module::isInstalled('ps_featuredproducts') || !Module::isEnabled('ps_featuredproducts')) {
                return '';
            }
            $featuredCategory = new Category(
                (int) Configuration::get('HOME_FEATURED_CAT'),
                $idLang,
                (int) $this->context->shop->id
            );
            if (!Validate::isLoadedObject($featuredCategory) || !$featuredCategory->active) {
                return '';
            }

            $searchProvider = new \PrestaShop\PrestaShop\Adapter\Category\CategoryProductSearchProvider(
                $this->context->getTranslator(),
                $featuredCategory
            );
            $searchContext = new \PrestaShop\PrestaShop\Core\Product\Search\ProductSearchContext($this->context);
            $query = new \PrestaShop\PrestaShop\Core\Product\Search\ProductSearchQuery();
            $query->setResultsPerPage($limit)->setPage(1);
            if (Configuration::get('HOME_FEATURED_RANDOMIZE')) {
                $query->setSortOrder(\PrestaShop\PrestaShop\Core\Product\Search\SortOrder::random());
            } else {
                $query->setSortOrder(new \PrestaShop\PrestaShop\Core\Product\Search\SortOrder('product', 'position', 'asc'));
            }
            $rawProducts = $searchProvider->runQuery($searchContext, $query)->getProducts();
        } else {
            if ($type === 'new') {
                $rawProducts = Product::getNewProducts($idLang, 0, $limit, false, 'date_add', 'DESC');
            } elseif ($type === 'specials') {
                $rawProducts = Product::getPricesDrop($idLang, 0, $limit, false, 'date_add', 'DESC');
            } elseif ($type === 'bestsellers') {
                $rawProducts = ProductSale::getBestSales($idLang, 0, $limit);
            } else {
                $product = new Product($productId, false, $idLang, (int) $this->context->shop->id);
                $rawProducts = Validate::isLoadedObject($product) && (bool) $product->active
                    ? [['id_product' => $productId]]
                    : [];
            }

        }

        if (is_array($rawProducts) && $rawProducts) {
            $assembler = new ProductAssembler($this->context);
            $presenterFactory = new ProductPresenterFactory($this->context);
            $presentationSettings = $presenterFactory->getPresentationSettings();
            $presenter = new \PrestaShop\PrestaShop\Adapter\Presenter\Product\ProductListingPresenter(
                new \PrestaShop\PrestaShop\Adapter\Image\ImageRetriever($this->context->link),
                $this->context->link,
                new \PrestaShop\PrestaShop\Adapter\Product\PriceFormatter(),
                new \PrestaShop\PrestaShop\Adapter\Product\ProductColorsRetriever(),
                $this->context->getTranslator()
            );
            $assembleInBulk = method_exists($assembler, 'assembleProducts');
            if ($assembleInBulk) {
                $rawProducts = $assembler->assembleProducts($rawProducts);
            }
            foreach (array_slice($rawProducts, 0, $limit) as $rawProduct) {
                $products[] = $presenter->present(
                    $presentationSettings,
                    $assembleInBulk ? $rawProduct : $assembler->assembleProduct($rawProduct),
                    $this->context->language
                );
            }
        }

        if (!$products) {
            return '';
        }

        $titles = [
            'new' => $this->module->l('New products', 'article'),
            'specials' => $this->module->l('On-sale products', 'article'),
            'bestsellers' => $this->module->l('Best sellers', 'article'),
            'featured' => $this->module->l('Featured products', 'article'),
            'product' => '',
        ];
        $this->context->smarty->assign([
            'nativeblogprestashop_product_block_title' => $titles[$type] ?? '',
            'nativeblogprestashop_products' => $products,
        ]);

        return $this->module->fetch('module:nativeblogprestashop/views/templates/front/article-products.tpl');
    }

}
