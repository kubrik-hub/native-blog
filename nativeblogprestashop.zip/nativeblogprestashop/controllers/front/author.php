<?php
/**
 * Native PrestaShop Blog author archive controller.
 *
 * @author Kamel Kelkoul
 * @license https://opensource.org/licenses/OSL-3.0 Open Software License 3.0 (OSL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class NativeBlogPrestaShopAuthorModuleFrontController extends ModuleFrontController
{
    private const ARTICLES_PER_PAGE = 12;

    public function initContent(): void
    {
        parent::initContent();

        $idLang = (int) $this->context->language->id;
        $idShop = (int) $this->context->shop->id;
        $slug = Tools::str2url((string) Tools::getValue('slug'));
        $author = Db::getInstance()->getRow(
            'SELECT a.id_nativeblogprestashop_author, a.avatar, al.firstname, al.lastname, al.hobbies
            FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_author` a
            INNER JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_author_lang` al
                ON al.id_nativeblogprestashop_author = a.id_nativeblogprestashop_author
                AND al.id_lang = ' . $idLang . '
            INNER JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_author_shop` ash
                ON ash.id_nativeblogprestashop_author = a.id_nativeblogprestashop_author
                AND ash.id_shop = ' . $idShop . ' AND ash.active = 1
            WHERE a.slug = \'' . pSQL($slug) . '\''
        );
        if (!$author) {
            Tools::redirect($this->context->link->getModuleLink($this->module->name, 'home'));
        }

        $authorId = (int) $author['id_nativeblogprestashop_author'];
        $totalArticles = (int) Db::getInstance()->getValue(
            'SELECT COUNT(DISTINCT a.id_nativeblogprestashop_article)
            FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_article` a
            INNER JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_article_lang` al
                ON al.id_nativeblogprestashop_article = a.id_nativeblogprestashop_article
                AND al.id_lang = ' . $idLang . '
            INNER JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_article_shop` ash
                ON ash.id_nativeblogprestashop_article = a.id_nativeblogprestashop_article
                AND ash.id_shop = ' . $idShop . ' AND ash.active = 1
                AND (ash.date_publish IS NULL OR ash.date_publish <= NOW())
            WHERE a.id_nativeblogprestashop_author = ' . $authorId
        );
        $totalPages = max(1, (int) ceil($totalArticles / self::ARTICLES_PER_PAGE));
        $page = max(1, min($totalPages, (int) Tools::getValue('page', 1)));
        $offset = ($page - 1) * self::ARTICLES_PER_PAGE;
        $articles = Db::getInstance()->executeS(
            'SELECT a.id_nativeblogprestashop_article, a.id_nativeblogprestashop_category, a.slug,
                a.cover_image, a.date_add, al.title, al.excerpt, ash.date_publish,
                cl.name AS category_name,
                COUNT(DISTINCT CASE WHEN c.approved = 1 THEN c.id_nativeblogprestashop_comment END) AS comment_count,
                COALESCE(AVG(CASE WHEN c.approved = 1 THEN c.grade END), 0) AS average_grade
            FROM `' . _DB_PREFIX_ . 'nativeblogprestashop_article` a
            INNER JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_article_lang` al
                ON al.id_nativeblogprestashop_article = a.id_nativeblogprestashop_article
                AND al.id_lang = ' . $idLang . '
            INNER JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_article_shop` ash
                ON ash.id_nativeblogprestashop_article = a.id_nativeblogprestashop_article
                AND ash.id_shop = ' . $idShop . ' AND ash.active = 1
                AND (ash.date_publish IS NULL OR ash.date_publish <= NOW())
            LEFT JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_category_lang` cl
                ON cl.id_nativeblogprestashop_category = a.id_nativeblogprestashop_category
                AND cl.id_lang = ' . $idLang . '
            LEFT JOIN `' . _DB_PREFIX_ . 'nativeblogprestashop_comment` c
                ON c.id_nativeblogprestashop_article = a.id_nativeblogprestashop_article
                AND c.id_shop = ' . $idShop . '
            WHERE a.id_nativeblogprestashop_author = ' . $authorId . '
            GROUP BY a.id_nativeblogprestashop_article, a.id_nativeblogprestashop_category,
                a.slug, a.cover_image, a.date_add, al.title, al.excerpt, ash.date_publish, cl.name
            ORDER BY COALESCE(ash.date_publish, a.date_add) DESC
            LIMIT ' . self::ARTICLES_PER_PAGE . ' OFFSET ' . $offset
        ) ?: [];
        foreach ($articles as &$article) {
            $article['link'] = $this->context->link->getModuleLink($this->module->name, 'article', ['slug' => $article['slug']]);
            $article['publication_date'] = date('Y-m-d', strtotime((string) ($article['date_publish'] ?: $article['date_add'])));
            $article['average_grade'] = round((float) $article['average_grade'], 1);
            $article['comment_count'] = (int) $article['comment_count'];
            $article['cover_url'] = preg_match('/^[a-f0-9]{32}\.(jpg|png|gif|webp)$/', (string) $article['cover_image'])
                && is_file($this->module->getLocalPath() . 'upload/' . $article['cover_image'])
                ? __PS_BASE_URI__ . 'modules/' . $this->module->name . '/upload/' . $article['cover_image']
                : '';
            $article['category_url'] = (int) $article['id_nativeblogprestashop_category'] > 0
                ? $this->module->getCategoryLink((int) $article['id_nativeblogprestashop_category'])
                : '';
        }
        unset($article);

        $author['display_name'] = trim($author['firstname'] . ' ' . $author['lastname']);
        $author['avatar_url'] = preg_match('/^[a-f0-9]{32}\.(jpg|png|gif|webp)$/', (string) $author['avatar'])
            && is_file($this->module->getLocalPath() . 'upload/authors/' . $author['avatar'])
            ? __PS_BASE_URI__ . 'modules/' . $this->module->name . '/upload/authors/' . $author['avatar']
            : '';
        $blogUrl = $this->context->link->getModuleLink($this->module->name, 'home');
        $pageLink = function (int $targetPage) use ($slug): string {
            $params = ['slug' => $slug];
            if ($targetPage > 1) {
                $params['page'] = $targetPage;
            }

            return $this->context->link->getModuleLink($this->module->name, 'author', $params);
        };
        $this->context->smarty->assign([
            'nativeblogprestashop_author' => $author,
            'nativeblogprestashop_comments_enabled' => $this->module->isCommentsEnabled(),
            'nativeblogprestashop_articles' => $articles,
            'nativeblogprestashop_pagination' => [
                'current_page' => $page,
                'total_pages' => $totalPages,
                'has_previous' => $page > 1,
                'has_next' => $page < $totalPages,
                'previous_url' => $page > 1 ? $pageLink($page - 1) : '',
                'next_url' => $page < $totalPages ? $pageLink($page + 1) : '',
            ],
            'breadcrumb' => [
                'count' => 3,
                'links' => [
                    ['title' => $this->l('Home'), 'url' => $this->context->link->getPageLink('index')],
                    ['title' => (string) Configuration::get('NBPS_TITLE'), 'url' => $blogUrl],
                    ['title' => $author['display_name'], 'url' => $this->context->link->getModuleLink($this->module->name, 'author', ['slug' => $slug])],
                ],
            ],
        ]);
        if (method_exists($this, 'setPageTitle')) {
            $this->setPageTitle($author['display_name']);
        }
        $this->setTemplate('module:nativeblogprestashop/views/templates/front/author.tpl');
    }
}
